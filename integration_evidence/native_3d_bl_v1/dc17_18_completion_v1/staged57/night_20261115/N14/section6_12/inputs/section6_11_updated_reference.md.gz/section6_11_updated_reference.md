### 6.11 One more print-only measurement: M26, the wall lane census (2026-11-17, 08:00; user decision of 2026-11-17)

Purpose: the user accepted the DEFINITION of design part 8.5ab (D section 5.12,
revision 2.3; copy D again with its SHA256). Do not implement 8.5ab. The reviewer
needs two numbers for its text: how many wall commits a rank can make alone.

Item N15. Print only, under `options.timings`, in the census of N12
(`CNativeLaneCensus3D.hpp` and its call places).

1. When, to add no full run:
   - if N14 is released before the end of phase C of the cut: in the same build as N14;
   - if not: as one commit before the G5 full run of the end of phase C. That run gives
     the numbers. If that G5 run fails and the one diagnosis pass does not name another
     part: revert N15 first and repeat G5 one time.
2. Population: the commits of the class local + wall of N12, quality stage only.
3. For each such commit, from data that the commit place has (`old`, `fresh`, the
   edits of `BoundaryParameterState::Changes` for this proposal, the coverage delta,
   the ladder kind). Let e = the count of erased wall points and i = the count of
   inserted wall points of these edits:
   a. `link_local`: each wall face on each wall vertex of `old`
      (`BoundaryParameterState::FacesOnVertex`) is a face of a cell of this rank;
   b. the class:
      - S = `SameSkin` true, no parameter edit, empty coverage delta;
      - W1 = not S, e <= 1 and i <= 1 (one wall point added, moved or removed, or a
        wall reconnection with no point change);
      - W2M = not S, e = i >= 2, and `old` and `fresh` have the same count of wall
        faces (wall points moved only);
      - W2O = each other commit;
   c. for class W1 with i = 1: `first_proof` = the exact orientation of the inserted
      point against each wall face of `old` that is not a wall face of `fresh` is not
      negative (the sign rule of your M6b code).
4. One line for each rank at the stage exit:
   `NATIVE3D_WALL_LANE_CENSUS rank= commits= class_s= class_w1= class_w2m= class_w2o= w1_kind0= w1_kind1= w1_kind2= w2m_kind1= w1_link_local= w2m_link_local= w1_first_proof= w1_link_local_first_proof= seconds_s= seconds_w1= seconds_w2m= seconds_w2o=`
   (`seconds` = the busy seconds of the slots of these commits, the clock of N12).
   `commits` must be equal to the `commits` of the N12 row local + wall, and the four
   classes must sum to it.
4a. One more number, for the cost of the join of 8.5ab. In `Directory::PrepareParameters`,
   for the call `parameters->Prepare` on the union of the edits of all ranks: the count
   of calls, the seconds (a local clock, only under `options.timings`; no new timer
   operation), the count of edits and the count of faces. One line for each rank at
   the stage exit: `NATIVE3D_WALL_PREPARE rank= stage= calls= seconds= edits= faces=`.
5. No decision reads these values. No new timer operation, no new field in `Session`,
   `CellState` or a row that travels (each `NATIVE3D_TIMER_SUMMARY` row keeps
   `fixedstorage=4120`).
6. Gates: identical results. G1 by identity; G2 and GQ with all old integer rows
   equal; the six files of the full run of item 1 equal to the references.
7. Report: one table for each event (6 ranks), and for the sums: the share of S, of W1
   with `link_local`, of W1 with `link_local` and `first_proof`, and of W2M with
   `link_local`, in commits and in seconds; and the rows of item 4a.

