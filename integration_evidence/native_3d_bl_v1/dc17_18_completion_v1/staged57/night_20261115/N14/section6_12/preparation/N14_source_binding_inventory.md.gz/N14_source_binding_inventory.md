# N14 source-binding inventory (preparation only)

Read-only source binding for N14 as changed by section 6.12. No implementation/draft is included. No production, test, policy, pinned helper, or existing evidence file was changed; no build/test/run was started. The live CUT B2 G1 job was not touched.

## Read inputs and source snapshot

| File | SHA256 |
|---|---|
| Archived `section6_12/inputs/NIGHT_WORK_ORDER.md` (includes 6.10 and 6.12) | `0c446a618cda84b707a66d27551bdd8344db1166206811ee3fa84c0ec9432464` |
| `section6_12/inputs/section6_12_user_order.md` | `4a34e41ef943d9bfa4b5d75790b04a7263c61f046434538e032db44ef87720e6` |
| `section6_12/inputs/IMPLEMENTATION_8_3_8_4.md` (I, including B1/B2 gates) | `40a2cf607454dc86d33824bc867ef65d64c739fe360e78bc485cc08af5d9a557` |
| Current `Common/src/adaptation/CNativeEngine3D.cpp` snapshot | `ffcb292b4639128c26495f7df44a4b63b9c61b0df62222547f4b4ad253ba9020` |
| `Common/src/adaptation/CNativeBoundary3D.cpp` | `359c502bd84de723f11ccf7d873fe89d4ec21016d3e9c6967c7250af49972dac` |
| `Common/include/adaptation/CNativeBoundary3D.hpp` | `6ff3a90de05efd059ace65b8e775e9792f0d31d0cd670a612a8469cb3b6638ae` |
| `Common/src/adaptation/native_engine3d/EngineTrial.cpp` | `717634a514b169f383cf3e88ecc6cbc10783dab3babb76c69ea7a3b249341fe5` |
| `Common/include/adaptation/CNativeWallDiagnostics3D.hpp` | `9cc513ea95f34fee5d6ad44c345e339bfdb5fecd5d86a49ed84d76185bd04fda` |
| `Common/include/adaptation/CNativeWallGeometryLaw3D.hpp` | `79eb840a398e91a45586e78750544b767c5f1eb682f829289acf228b907cf72d` |
| `Common/src/adaptation/CNativeWallGeometryLaw3D.cpp` | `6671e88472352d35cd8f95366fdeba3b22c87a2fe861955ddb0f9e0b986636e6` |

The requested 6.10 item 3a/e/f, corrected by 6.12, and I’s B1/B2 gates were read. 6.12 supersedes 6.10(b/c/d): the condition is strict split-point lift, computed once before primary validation; purpose remains at least 689 accepted splits in both G3 runs; print-only counters/report remain as specified. N15 is intended for the same build if N14 is released before the cut’s phase-C boundary. N14 is prepared, not released, and may start only after the specified user release.

## Current primary split and point binding

Current `Adapt` locations (absolute lines for the source hash above):

- `evaluate_candidate` contains `guarded_geometry` (4329 onward), `geometric_change` (4351), the primary split block (4499–4526), and `validate_private` (4796). The primary validation is `approved = validate_private(...)` at 4858, with `choice.geometric ? MetricChange::GeometryRefine : construction_kind`.
- The non-coarsening, non-repair primary branch creates `point` at 4505: new ID `maximum_node + 1 + node_offset`; position is the binary64 cast of the long-double endpoint midpoint. If `composition`, `point.p` is replaced with `splitPosition` at 4507.
- Primary calls: `SplitEdge` at 4508, then `InsertEdgeCavity` at 4510 if the guarded result was false. When both fail, and the edge is physical with composition and a central point available, the local `point.p` is set to `centralPosition` at 4515 and the same operator pair is retried at 4516/4518. Thus the successful call’s chord-position input can be the initial midpoint, `splitPosition`, or this central fallback. The persistent `point` local is the actual input used by the successful final call.
- Both operators take `Node point` **by value** (`CNativeBoundary3D.hpp:271,278`). `SplitEdge` projects its private copy (`CNativeBoundary3D.cpp:1573`) before creating children; `InsertEdgeCavity` projects its private copy for a declared wall facet (`:1634`). Neither mutates Adapt’s `point`. The projected/placed point is represented by `point.id` in `fresh.cells`; its coordinates can be looked up there. This provides the two coordinates needed for the lift without a wall-face search.
- `guarded_geometry` wraps raw operator success with validity gates (surface/first-height preservation, `HeightCheck`, boundary replacement) and records geometry/wall diagnostics. Adapt stores only this guarded bool in `approved`; it does not retain a separate raw-operator-success bool. A required-split classification should be based on the successful primary candidate that reaches primary validation, not on a raw operator return whose guards rejected it.
- The existing later lookup `for (... fresh.cells ...) if (node.id == point.id) point = node` is at 5944, after primary validation, later joint/repair opportunities, and reservation/clearance work. It cannot supply the required pre-validation chord point; it also overwrites the caller’s chord-position `point` with the new wall node. The fresh-node lookup for the lift must therefore occur before the primary `validate_private` call if N14 is released.

## Guidance validation and exclusions

- In `validate_private`, the first guidance call is at 4802: unless `merit_first`, it calls `geometric_change(candidate, selection.geometry_repairs ? GeometryRepair : kind)`. This is the primary validation’s relevant call. The second in-lambda call at 4831 is guarded by `valid && merit_first`; `merit_first` requires `!surface_target`, so it is unreachable under N14’s surface-target condition. There is another `geometric_change` at 4412 in `validate_metric_vector`, outside the primary `validate_private` validation.
- For the geometry-queue primary call at 4858, the supplied `kind` is `GeometryRefine`. `validate_private`’s `effective` at 4810 only substitutes a kind when `kind == Repair`; for this primary it remains `GeometryRefine`. `EngineTrial::MetricTrial` (EngineTrial.cpp:35–57) rejects missing geometry progress only when `kind == GeometryRepair` (surface target). Thus the N14 required case may set `geometric_progress=false` (“not known”) while still proceeding as `GeometryRefine`. The `selection.geometry_repairs` conditional at 4802 can pass `GeometryRepair` into the guidance check; it is distinct from the effective metric kind at 4810.
- N14’s condition is strictly: `surface_target && curved`; not coarsening and not repairing; `choice.geometric`; successful fresh node with identity `point.id`; and squared Euclidean lift strictly greater than `options.surface_tolerance²`. Differences and sum of squares are `long double`; equality is false. No A1 law call and no wall-face search. The bool is computed once after successful primary split and before the primary validation, then used only to bypass the guidance check there. Do not add fields to `CellState`, traveling `Choice`, `Session`, or timer enum. The joint and repair paths retain their existing validation.
- Joint/repair paths are separate: placement `validate_private` at 4975; strip/joint validation at 5269; joint topology branches (`RefitWallSplit`, `ReconstructWallSplit`, `ReconstructSplitPatch`) run only downstream of `!approved` (joint selection at 4862; timed operators around 5415–5450; `validate_joint` 5432–5435). Further repair validations are at 5681, 5735, 5802, and 5811. Do not test the lift there. The secondary `SplitEdge`/`InsertEdgeCavity` calls at 5251–5252 operate on a joint `star` patch and are not the primary pair.

## 5488d1f1b5 by-symbol restoration map

Commit `5488d1f1b5` touches these relevant production/test symbols and paths:

- `Common/src/adaptation/CNativeEngine3D.cpp`: `Selection` law-weighted geometry queue scoring; wire `WallFaceWeights`/law-face observations through selection construction; primary/source and accepted-split observation call sites; removal of the entry `PrintWallLawCensus(..., "entry", ...)` call. Current snapshot has `WallFaceEdgeWeights` use at 1086 and `ObserveSource`/split-origin wiring at 4888/6120, but still has the entry census call at 1545. Preserve the 5488 behavior by symbol, including removal of that entry call; do not transplant old line-number hunks onto the cut.
- `Common/include/adaptation/CNativeWallGeometryLaw3D.hpp` and `Common/src/adaptation/CNativeWallGeometryLaw3D.cpp`: `WallFaceWeights` and `WallFaceEdgeWeights` API/implementation, using three supported estimates or whole-face fallback.
- `Common/include/adaptation/CNativeWallDiagnostics3D.hpp`: `PatchSource`, law-face/split/source counters, and `NATIVE3D_WALL_SOURCE` / law-selection reporting.
- Tests: `UnitTests/Common/adaptation/CNativeAffineReference_tests.cpp` includes `UnitTests/Common/adaptation/fixtures/native_wall_law_b2_tests.inc` (weights/fallback and source-counter tests).

The commit also changed AGENTS and added evidence; those are not restoration targets for this task. This inventory is not a whole connected N14/N15 source check; the existing N4 source check and the later designated source check govern.

## Gate/report facts carried forward

- N14 retains the 6.10 3a restoration by symbol, G1/G2/GQ/G3 and no-BL safeguards from I gates 1, 2, 4, 5; G3 purpose is at least 689 accepted splits at exit in each of two runs. 6.12 G3 identity/validity terms and 6.8 census-call rule remain controlling.
- 6.10 item 3f report rows remain, adjusted for the new condition and 6.12 counters: the 6.6 item 4 list, required/checked split counters, new wall-face bound observations at `Selection::Add`, `NATIVE3D_WALL_FRAME`, `NATIVE3D_WALL_SOURCE`, and `guidance_seconds`.

