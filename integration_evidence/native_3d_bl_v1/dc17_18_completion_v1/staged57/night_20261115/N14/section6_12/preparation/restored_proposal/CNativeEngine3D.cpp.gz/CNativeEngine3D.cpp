/*!
 * \file CNativeEngine3D.cpp
 * \brief Incremental frozen-target selection and distributed private planar refinement/coarsening.
 * Copyright 2012-2026, SU2 Contributors (cf. AUTHORS.md).
 * SU2 is free software under the GNU Lesser General Public License, version 2.1 or later.
 */
#include "../../include/adaptation/CNativeEngine3D.hpp"
#include "../../include/adaptation/CNativeMetricTransport3D.hpp"
#include "../../include/adaptation/CNativeOptimize3D.hpp"
#include "../../include/adaptation/CNativeRegionField3D.hpp"
#include "../../include/adaptation/CNativePointConstruction3D.hpp"
#include "../../include/adaptation/CNativeCurvedAtlas3D.hpp"
#include "../../include/adaptation/CNativeGeometryBackend3D.hpp"
#include "../../include/adaptation/CNativeGenerationProgress3D.hpp"
#include "../../include/adaptation/CNativePartition3D.hpp"
#include "../../include/adaptation/CNativeImport3D.hpp"
#include "../../include/adaptation/CNativeTimerTree3D.hpp"
#include "../../include/adaptation/CNativeD9Profile3D.hpp"
#include "../../include/adaptation/CNativeWallDiagnostics3D.hpp"
#include "../../include/adaptation/CNativeWallGeometryLaw3D.hpp"
#include "../../include/adaptation/CNativeLaneCensus3D.hpp"
#include "../../include/adaptation/CNativeRuntimeProfile3D.hpp"
#include <chrono>
#include <cmath>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <unordered_map>
#include <ctime>
#include <set>
#include <sstream>
#include <iomanip>
#include <tuple>
#include <stdexcept>
#include <type_traits>
#include <optional>
namespace SU2Native3D {
AdaptationRequirements MakeAdaptationRequirements(const PlanarReference& geometry, bool composition,
                                                  const EngineOptions& options) {
  AdaptationRequirements result;
  result.size.controls = options.requirement_size;
  result.size.composition_present = composition;
  result.geometry.mapped = geometry.Mapped();
  result.geometry.entity_geometry = geometry.EntityGeometry();
  result.geometry.curved = !geometry.ExtensionComponents().empty();
  result.geometry.tolerance = options.surface_tolerance;
  if (const auto* policy = geometry.Mobility()) {
    result.features.policy_present = true;
    result.features.features = policy->features.size();
    result.features.corners = policy->corners.size();
    std::set<Id> roots;
    for (const auto& sheet : policy->sheets) roots.insert(sheet.second);
    result.features.sheets = roots.size();
    result.features.angle = policy->angle;
  }
  result.walls.first_heights = &options.wall_heights;
  result.walls.region_policies = &options.region_walls;
  result.walls.height_tolerance = options.wall_heights.tolerance;
  result.budgets = {options.maximum_work, options.maximum_seconds, options.memory_ceiling, options.job_memory_limit};
  return result;
}

void PrintAdaptationRequirements(const AdaptationRequirements& r, int rank, std::ostream& out) {
  const auto precision = out.precision();
  out << std::setprecision(17) << "NATIVE3D_REQUIREMENTS rank=" << rank << " hmin=" << r.size.controls.hmin
      << " hmax=" << r.size.controls.hmax << " ARmax=" << r.size.controls.armax << " hgrad=" << r.size.controls.hgrad
      << " complexity=" << r.size.controls.complexity << " composition_present=" << r.size.composition_present
      << " mapped=" << r.geometry.mapped << " entity_geometry=" << r.geometry.entity_geometry
      << " curved=" << r.geometry.curved << " tolerance=" << r.geometry.tolerance
      << " policy_present=" << r.features.policy_present << " features=" << r.features.features
      << " corners=" << r.features.corners << " sheets=" << r.features.sheets << " angle=" << r.features.angle
      << " height_tolerance=" << r.walls.height_tolerance << " maximum_work=" << r.budgets.maximum_work
      << " maximum_seconds=" << r.budgets.maximum_seconds << " memory_ceiling=" << r.budgets.memory_ceiling
      << " job_memory_limit=" << r.budgets.job_memory_limit << " wall_rows=";
  std::set<int> markers;
  for (const auto& wall : *r.walls.first_heights) markers.insert(wall.first);
  for (const auto& region : *r.walls.region_policies) markers.insert(region.first);
  bool first = true;
  for (const int marker : markers) {
    if (!first) out << ';';
    first = false;
    const auto height = r.walls.first_heights->find(marker);
    const auto region = r.walls.region_policies->find(marker);
    const double h0 = height != r.walls.first_heights->end() ? height->second : region->second.height;
    const double growth =
        region != r.walls.region_policies->end() ? region->second.growth : std::numeric_limits<double>::quiet_NaN();
    const double thickness =
        region != r.walls.region_policies->end() ? region->second.thickness : std::numeric_limits<double>::quiet_NaN();
    out << marker << ':' << h0 << ',' << growth << ',' << thickness;
  }
  out << '\n';
  out.precision(precision);
}

namespace {
namespace wall_diagnostics = SU2NativeWallDiagnostics3D;
namespace lane_census = SU2NativeLaneCensus3D;

// Face-edge incidences deliberately include an edge once for each owned physical face.
void PrintWallLawCensus(const Owned& cells, const PlanarReference& geometry, double tau, int rank, const char* boundary,
                        bool enabled) {
  const auto* parameters = geometry.Parameters();
  if (!enabled || !parameters || !parameters->EntityGeometry()) return;
  SU2NativeTiming3D::Scope timer(SU2NativeTiming3D::Operation::Census);
  const auto started = std::chrono::steady_clock::now();
  size_t faces = 0, incidences = 0, need = 0, unsupported = 0;
  double max_ratio = 0;
  for (const auto& row : cells) {
    for (unsigned opposite = 0; opposite < 4; ++opposite) {
      const auto& binding = row.second.physical[opposite];
      if (!binding.present) continue;
      ++faces;
      std::array<unsigned, 3> vertices{};
      unsigned count = 0;
      for (unsigned k = 0; k < 4; ++k)
        if (k != opposite) vertices[count++] = k;
      for (unsigned k = 0; k < 3; ++k) {
        ++incidences;
        const auto estimate = EstimateWallEdge(*parameters, row.second.cell.v[vertices[k]],
                                               row.second.cell.v[vertices[(k + 1) % 3]], binding.facet);
        if (!estimate.supported) {
          ++unsupported;
          continue;
        }
        need += EstimateSaysNeed(estimate, tau);
        max_ratio = std::max(max_ratio, estimate.value / (.75 * tau));
      }
    }
  }
  const double seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - started).count();
  std::cout << "NATIVE3D_WALL_LAW rank=" << rank << " boundary=" << boundary << " faces=" << faces
            << " edge_incidences=" << incidences << " need_incidences=" << need
            << " unsupported_incidences=" << unsupported << " max_ratio=" << max_ratio << " seconds=" << seconds
            << '\n';
}
// First-failure precedence from I.B0; only labels an already rejected guidance check.
wall_diagnostics::GuidanceCause WallGuidanceCause(bool complete, bool finite, bool needs_progress, bool progress) {
  if (!complete) return wall_diagnostics::GuidanceCause::Incomplete;
  if (!finite) return wall_diagnostics::GuidanceCause::Nonfinite;
  if (needs_progress && !progress) return wall_diagnostics::GuidanceCause::NoProgress;
  return wall_diagnostics::GuidanceCause::AfterAbove;
}

// Attribute existing bound work without issuing or resetting geometry queries.
struct D9QueryScope {
  SU2NativeD9::Data* data = nullptr;
  const SU2NativeGeometry::MappedFacetReference* authority = nullptr;
  SU2NativeGeometry::MappedFacetReference::GeometryStats before{};
  SU2NativeD9::Clock::time_point start{};
  int phase = -1;
  SU2NativeD9::Site site;
  D9QueryScope(SU2NativeD9::Site value, const PlanarReference* geometry) : site(value) {
    phase = SU2NativeD9::Phase();
    if (phase < 0 || !geometry || !geometry->Parameters()) return;
    data = SU2NativeD9::active;
    authority = &geometry->Parameters()->Geometry();
    before = authority->GeometryStatsSnapshot();
    start = SU2NativeD9::Clock::now();
  }
  ~D9QueryScope() {
    if (!data) return;
    const auto seconds = SU2NativeD9::Seconds(start);
    const auto after = authority->GeometryStatsSnapshot();
    auto& row = data->queries[size_t(phase)][size_t(site)];
    ++row.scopes;
    row.direct += after.direct_calls - before.direct_calls;
    row.upper += after.upper_calls - before.upper_calls;
    row.classify += after.classification_calls - before.classification_calls;
    row.magnitude += after.magnitude_calls - before.magnitude_calls;
    row.limit += after.limit_calls - before.limit_calls;
    row.memo_direct += after.memo_direct_hits - before.memo_direct_hits;
    row.memo_union += after.memo_union_hits - before.memo_union_hits;
    row.work += after.upper_work - before.upper_work;
    row.direct_seconds += after.direct_seconds - before.direct_seconds;
    row.upper_seconds += after.upper_seconds - before.upper_seconds;
    row.seconds += seconds;
  }
};
// A successful separation is only a necessary geometry-error rejection, never admission.
bool CollapseOutsideTolerance(const Patch& old,Id removed,Id retained,const PlanarReference& geometry,double tolerance) {
  const auto* state=geometry.Parameters();
  if(!state || !state->Mobility().identity || !(std::isfinite(tolerance)&&tolerance>0))return false;
  const auto local=old.parameters.find(removed);
  const auto* point=local==old.parameters.end()?state->Find(removed):&local->second;
  if(!point)return false;
  auto* budget=geometry.AtlasReservation();
  if(!budget)throw std::runtime_error("Native collapse geometry screen lacks atlas reservation.");
  SU2NativeGeometry::NativeMappedGeometryBackend3D backend(state->Authority(),state->Mobility());
  SU2NativeGeometry::GeometryEvaluation evaluation;std::string reason;
  if(!backend.Evaluate(point->binding,std::nullopt,evaluation,*budget,reason))throw std::runtime_error(reason);
  const double threshold=std::nextafter(tolerance+evaluation.realization_error,INFINITY);
  if(!std::isfinite(threshold))return false;
  auto position=[&](Id id,Point& value) {
    const auto p=old.parameters.find(id);if(p!=old.parameters.end()){value=p->second.node.p;return true;}
    for(const auto& cell:old.cells)for(const auto& node:cell.v)if(node.id==id){value=node.p;return true;}
    return false;
  };
  bool any=false;const std::array<Point,3> sample{{evaluation.point,evaluation.point,evaluation.point}};
  for(const auto& face:old.surface) {
    const bool has_removed=std::find(face.v.begin(),face.v.end(),removed)!=face.v.end();
    const bool has_retained=std::find(face.v.begin(),face.v.end(),retained)!=face.v.end();
    if(has_removed && has_retained)continue;
    std::array<Point,3> triangle;
    for(unsigned i=0;i<3;++i)if(!position(face.v[i]==removed?retained:face.v[i],triangle[i]))return false;
    any=true;if(!SU2NativeGeometry::SourceFacesSeparated(sample,triangle,threshold))return false;
  }
  return any;
}
using Clock = std::chrono::steady_clock;
/*! Retain legacy counters while adding exclusive service rows to the active F3 ledger. */
class Timer {
 public:
  /*! Start both counters only when the existing timings flag permits clocks. */
  Timer(double& value, bool enabled, double* parent=nullptr,
        SU2NativeTiming3D::Operation operation = SU2NativeTiming3D::Operation::Unattributed) : value(value), enabled(enabled), parent(parent) { if (enabled) {
      start = Clock::now();
      scope.emplace(operation);
    }
  }
  /*! Label an existing legacy service that has no parent-subtraction counter. */
  Timer(double& value, bool enabled, SU2NativeTiming3D::Operation operation)
      : Timer(value, enabled, nullptr, operation) {}
  ~Timer() { if (enabled) {const auto elapsed=std::chrono::duration<double>(Clock::now()-start).count();value+=elapsed;if(parent)*parent-=elapsed;} }
 private:
  double& value;
  bool enabled;
  double* parent;  // Keep a nested scope exclusive when its parent is also reported as a phase.
  Clock::time_point start;
  std::optional<SU2NativeTiming3D::Scope> scope;
};
/*! Direct collectives bypass World: name their wall time without changing its legacy counters. */
template <class T>
T TimedAllreduce(T value, CPassiveComm::Op operation, CPassiveComm::Communicator communicator) {
  SU2NativeTiming3D::Scope communication_timer(SU2NativeTiming3D::Operation::Communication);
  return CPassiveComm::Allreduce(value, operation, communicator);
}

class CpuTimer {
 public:
  CpuTimer(double& value, bool enabled) : value(value), enabled(enabled) { if (enabled) start=std::clock(); }
  ~CpuTimer() { if (enabled) value += double(std::clock()-start)/CLOCKS_PER_SEC; }
 private:
  double& value;
  bool enabled;
  std::clock_t start;
};
template <class M> size_t MapBytes(const M& m) {
  return transfer_memory::Mul(m.size(), sizeof(typename M::value_type) + 4 * sizeof(void*));
}
Face Key(Face f) { std::sort(f.begin(), f.end()); return f; }
std::array<Face, 4> Faces(const Cell& c) {
  const auto& v = c.v;
  return {{{v[1].id,v[2].id,v[3].id}, {v[0].id,v[3].id,v[2].id},
           {v[0].id,v[1].id,v[3].id}, {v[0].id,v[2].id,v[1].id}}};
}
constexpr size_t AtlasScratchBytes=16u<<20;
void RetainPhysicalCoverage(Patch& patch) {
  std::set<Face> faces;std::set<Edge> edges;
  for(auto face:patch.surface){std::rotate(face.v.begin(),std::min_element(face.v.begin(),face.v.end()),face.v.end());faces.insert(face.v);
    for(unsigned k=0;k<3;++k){Edge edge{face.v[k],face.v[(k+1)%3]};std::sort(edge.begin(),edge.end());edges.insert(edge);}}
  for(auto it=patch.coverage.faces.begin();it!=patch.coverage.faces.end();)if(!faces.count(it->first))it=patch.coverage.faces.erase(it);else ++it;
  for(auto it=patch.coverage.traces.begin();it!=patch.coverage.traces.end();)if(!edges.count(it->first))it=patch.coverage.traces.erase(it);else ++it;
}
Patch GeometryPatch(const Imported& imported,const PlanarReference* geometry=nullptr) {
  Patch patch;
  for (const auto& row : imported.cells) {
    patch.cells.push_back(row.cell);
    const auto faces = Faces(row.cell);
    for (size_t i = 0; i < 4; ++i) if (row.physical[i].present) patch.surface.push_back({faces[i],row.physical[i].facet});
  }
  if(geometry)geometry->ExportParameters(patch);
  return patch;
}
bool Same(Point a, Point b) { return a.x==b.x && a.y==b.y && a.z==b.z; }
/*! Keep the owned-face buffers inside the existing event reservation until certification ends. */
struct ProofStorage {
  SU2NativeGeometry::AtlasBudget& budget;
  size_t caller;
  ProofStorage(SU2NativeGeometry::AtlasBudget& value, size_t extra) : budget(value), caller(value.caller_bytes) {
    const auto live = transfer_memory::Add(caller, extra);
    if (live == SIZE_MAX || live > budget.maximum_bytes)
      throw std::length_error("Owned face proof exceeds storage admission.");
    budget.caller_bytes = live;
    budget.peak_bytes = std::max(budget.peak_bytes, live);
  }
  ~ProofStorage() { budget.caller_bytes = caller; }
};
/*! Combine the disjoint owned-face reverse proofs before the unchanged entity proof. */
void ProveOwnedSurface(World& world, const Owned& working, const PlanarReference& geometry,
                       SU2NativeGeometry::AtlasBudget& budget, EngineStats& stats) {
  const auto& state = *geometry.Parameters();
  std::vector<SurfaceFace> faces;
  std::vector<double> bounds;
  CLocalFailure failure;
  std::optional<ProofStorage> storage;
  try {
    storage.emplace(budget, transfer_memory::Add(transfer_memory::Mul(working.size(), 8 * sizeof(SurfaceFace)),
        transfer_memory::Mul(state.Geometry().Reference().Facets().size(), 2 * sizeof(double))));
    for (const auto& row : working) {
      const auto cell_faces = Faces(row.second.cell);
      for (unsigned i = 0; i < 4; ++i)
        if (row.second.physical[i].present) faces.push_back({cell_faces[i], row.second.physical[i].facet});
    }
    bounds = state.OwnedFaceReverseBounds(faces, budget);
  } catch (const std::exception& error) {
    failure.Set(2, 0, error.what());
  }
  const auto elected = world.elect(failure);
  if (elected.any) throw std::runtime_error(elected.message);
  stats.final_proof_faces = faces.size();
  stats.final_proof_surface_faces = state.Surface().size();
  if (world.reduce(uint64_t(faces.size()), CPassiveComm::Op::SUM) != state.Surface().size())
    throw std::runtime_error("Owned wall-face proof does not cover the complete working surface exactly once.");
  for (auto& bound : bounds) bound = world.reduce(bound, CPassiveComm::Op::MAX);
  for (const auto& row : state.GeometryCertificates(budget, true, &bounds))
    if (!row.second.within_tolerance)
      throw std::runtime_error("Complete working surface does not meet the prescribed two-sided geometry tolerance.");
}
/*! Report the ownership spike with live payload sizes; this is not a memory admission model. */
void ReportOwnershipMemory(const World& world, const char* boundary, size_t pending = 0, size_t outgoing = 0,
                           size_t records = 0) {
  SU2NativeTiming3D::Scope timer(SU2NativeTiming3D::Operation::Output);
  std::cout << "NATIVE3D_OWNERSHIP_MEMORY rank=" << world.rank << " boundary=" << boundary
            << " current_rss=" << CurrentRSS3D() << " process_peak_rss=" << ProcessPeakRSS3D()
            << " max_exchange_work_bytes=" << world.max_exchange_work_bytes << " bytes_sent=" << world.bytes_sent
            << " pending_bytes=" << pending << " outgoing_bytes=" << outgoing << " record_bytes=" << records << '\n';
}
bool DonorCap(const std::string& reason) {
  return reason=="Original donor import exceeds patch budget." || reason=="Original donor union exceeds patch budget.";
}
// Requested altitude and normal footprint are optimization deficits; unresolved geometry is not.
double HeightScore(const Patch& patch,const WallHeights& heights,const PlanarReference& geometry) {
  if(heights.empty())return INFINITY;
  FirstHeightReport report;std::string reason;
  if(CheckFirstHeight(patch,heights,geometry,report,reason))return INFINITY;
  if(!report.measured || report.reference_clearance_failures || report.missing_cells)return -INFINITY;
  const double deficit=std::max(report.maximum_relative_error/heights.tolerance-1.,-3*report.minimum_barycentric);
  return 1/(1+std::max(deficit,2e-6));
}
using RepairFeature = std::pair<unsigned,std::array<Id,3>>;
bool SameSkin(const Patch& old,const Patch& fresh) {
  const auto before=Incidence(old.cells).Boundary();
  if(before!=Incidence(fresh.cells).Boundary())return false;
  std::map<Id,Point> a,b;
  for(const auto& cell:old.cells)for(auto n:cell.v)a.emplace(n.id,n.p);
  for(const auto& cell:fresh.cells)for(auto n:cell.v)b.emplace(n.id,n.p);
  for(const auto& face:before)for(Id id:face)if(!Same(a.at(id),b.at(id)))return false;
  return true;
}
struct Choice {
  Edge edge{};EdgeMeasure measure;bool active=false;Feature feature;bool geometric=false;
  long double priority_score=0;Id priority_cell=0;unsigned reservation_priority=0;
  uint64_t repair_epoch=0;
  bool fair_repair=false;
};
struct CellQualityFlag {Id cell=0;bool q_bad=false,j_bad=false;};
struct FixedMetricPoint {
  Id cell=0;int owner=0;Point point;Tensor baseline;
  template<class S>void Fields(S& s){s(cell,owner,point,baseline);}
};
struct FixedMetricReading {
  uint64_t sample=0;Id cell=0;int owner=0;Tensor current;
  template<class S>void Fields(S& s){s(sample,cell,owner,current);}
};
void AccountQualityChurn(const Patch& old,const Patch& fresh,const std::vector<CellQualityFlag>& before,
                        const std::vector<CellQualityFlag>& after,QualityRepairStats& stats) {
  if(before.size()!=old.cells.size()||after.size()!=fresh.cells.size()) {
    stats.unmeasured_churn+=old.cells.size()+fresh.cells.size();return;
  }
  using Key=std::array<std::array<double,3>,4>;
  auto key=[](const Cell& cell){Key out;for(unsigned i=0;i<4;++i)out[i]={cell.v[i].p.x,cell.v[i].p.y,cell.v[i].p.z};
    std::sort(out.begin(),out.end());return out;};
  std::map<Key,std::array<bool,2>> prior;
  for(size_t i=0;i<old.cells.size();++i) {
    if(before[i].cell!=old.cells[i].id||!prior.emplace(key(old.cells[i]),std::array<bool,2>{{before[i].q_bad,before[i].j_bad}}).second) {
      stats.unmeasured_churn+=old.cells.size()+fresh.cells.size();return;
    }
  }
  QualityRepairStats change;
  for(size_t i=0;i<fresh.cells.size();++i) {
    if(after[i].cell!=fresh.cells[i].id){stats.unmeasured_churn+=old.cells.size()+fresh.cells.size();return;}
    const auto found=prior.find(key(fresh.cells[i]));
    if(found==prior.end()) {
      change.q_created+=after[i].q_bad;change.q_introduced+=after[i].q_bad;
      change.j_created+=after[i].j_bad;change.j_introduced+=after[i].j_bad;
    } else {
      change.q_removed+=found->second[0]&&!after[i].q_bad;change.q_created+=!found->second[0]&&after[i].q_bad;
      change.j_removed+=found->second[1]&&!after[i].j_bad;change.j_created+=!found->second[1]&&after[i].j_bad;
      prior.erase(found);
    }
  }
  for(const auto& row:prior) {
    change.q_removed+=row.second[0];change.q_retired+=row.second[0];
    change.j_removed+=row.second[1];change.j_retired+=row.second[1];
  }
  stats.q_removed+=change.q_removed;stats.q_created+=change.q_created;stats.j_removed+=change.j_removed;stats.j_created+=change.j_created;
  stats.q_retired+=change.q_retired;stats.q_introduced+=change.q_introduced;
  stats.j_retired+=change.j_retired;stats.j_introduced+=change.j_introduced;
}
struct ProposalKey {
  Feature feature;int rank=0;size_t slot=0;bool geometric=false;double score=0;Id cell=0;uint64_t epoch=0;
  bool fair_repair=false;
  template<class S> void Fields(S& s){s(feature,rank,slot,geometric,score,cell,epoch,fair_repair);}
};
struct RepairReceipt {
  Feature feature;bool accepted=false;unsigned disposition=4;
  template<class S> void Fields(S& s){s(feature,accepted,disposition);}
};
template<class S>void CachedScalar(S& s,long double& value) {
  if(!std::isfinite(value))throw std::logic_error("Nonfinite migrated cache scalar.");
  int exponent=0;bool negative=std::signbit(value);
  std::array<long double,4> words{{std::frexp(std::abs(value),&exponent),0,0,0}};
  s(exponent,negative);OriginalWeights3D(s,words);value=std::ldexp(words[0],exponent);if(negative)value=-value;
}
class Selection {
 public:
  enum class Lane {Surface,Interior};
  bool split_lanes=false;
  Lane lane=Lane::Surface;
  Selection(bool coarsening, bool repairing, const PlanarReference& geometry, EngineStats& stats, bool timings,
            double tolerance, const WallHeights& heights, bool quality_only, bool surface_planning = false,
            wall_diagnostics::Counters* wall_counters = nullptr)
      : coarsening(coarsening),
        track_repairs(repairing),
        repair_event(repairing),
        quality_only(quality_only),
        surface_planning(surface_planning),
        geometry(geometry),
        stats(stats),
        timings(timings),
        tolerance(tolerance),
        heights(heights),
        wall_counters(wall_counters) {}
  bool coarsening, track_repairs, repair_event, prune_collapses = false, track_splits = false;
  const bool quality_only;
  const bool surface_planning;
  bool size_repairs=false,geometry_repairs=false;
  const PlanarReference& geometry;
  EngineStats& stats;
  bool timings;
  double tolerance;
  const WallHeights& heights;
  wall_diagnostics::Counters* wall_counters;
  std::set<std::tuple<long double,Id,Edge>> geometry_queue;
  std::map<Edge,long double> geometry_split_priorities;
  bool geometry_priority_mode=false;
  long double GeometryPriority(long double raw,Edge edge)const {
    if(!geometry_priority_mode)return raw;
    const auto found=geometry_split_priorities.find(edge);
    return found!=geometry_split_priorities.end()&&found->second>1 ? found->second : raw/(1+raw);
  }
  size_t GeometryPriorityBytes()const {
    return transfer_memory::Mul(geometry_queue.size(),sizeof(std::pair<const Edge,long double>)+4*sizeof(void*));
  }
  void PrioritizeGeometrySplits(Clock::time_point started,double maximum_seconds) {
    geometry_split_priorities.clear();geometry_priority_mode=true;
    auto pending=std::move(geometry_queue);geometry_queue.clear();
    while(!pending.empty()) {
      auto entry=pending.extract(pending.begin());const auto edge=std::get<2>(entry.value());
      if(!geometry_split_priorities.count(edge)&&
          (!maximum_seconds||std::chrono::duration<double>(Clock::now()-started).count()<maximum_seconds)) {
        const auto& measured=edges.at(edge).measure;
        Timer timer(stats.geometry_guidance_seconds,timings, SU2NativeTiming3D::Operation::GeometryBound);++stats.geometry_guidance_trials;
        const auto prediction=PredictGeometrySplit(edge,{measured.a,measured.b},geometry,tolerance);
        stats.geometry_guidance_faces+=prediction.evaluated_faces;
        const bool better=prediction.complete&&prediction.before>0&&prediction.after<prediction.before*(1-1e-12L);
        geometry_split_priorities.emplace(edge,better?1+(prediction.before-prediction.after)/prediction.before:-1.L);
      }
      const auto id=std::get<1>(entry.value());const auto& row=cells.at(id);
      const auto found=std::find(row.edges.begin(),row.edges.end(),edge);
      if(found==row.edges.end())throw std::logic_error("Geometry priority lost its versioned edge.");
      std::get<0>(entry.value())=-GeometryPriority(row.geometry_scores[found-row.edges.begin()],edge);
      geometry_queue.insert(std::move(entry));
    }
  }
  std::set<std::pair<long double,Edge>> surface_queue;
  // One construction generation contains the edges present at its entry, including edges of
  // cells whose metric has not been progressively seeded yet. Publications cannot extend it.
  std::set<Edge> construction_frontier;
  struct History {uint64_t age=0,round=0;unsigned disposition=0;};
  std::map<Edge,History> edge_history;
  void Note(Edge edge,unsigned disposition) {
    std::sort(edge.begin(),edge.end());const auto found=edge_history.find(edge);
    if(found!=edge_history.end()){found->second.round=stats.rounds;found->second.disposition=disposition;}
  }
  void RefreshHistory(bool generation) {
    for(auto it=edge_history.begin();it!=edge_history.end();) {
      const auto edge=edges.find(it->first);
      if(edge==edges.end()||edge->second.measure.length<=MaximumMetricEdge)it=edge_history.erase(it);else ++it;
    }
    for(const auto& edge:edges)if(edge.second.measure.length>MaximumMetricEdge) {
      auto& history=edge_history[edge.first];if(generation)++history.age;
    }
  }
  long double Priority(long double length) const { return coarsening ? length : -length; }
  bool Candidate(long double length) const {
    return coarsening ? length < CoarseningMetricEdge : length > MaximumMetricEdge;
  }
  void Queue(Edge edge, long double length, bool insert) {
    if (repair_event || !Candidate(length)) return;
    for (unsigned i=0; i<(coarsening ? 2u : 1u); ++i) {
      Edge key=edge; std::sort(key.begin(),key.end());
      const auto value=std::make_pair(Priority(length),edge);
      auto& destination=split_lanes&&!coarsening&&edges.at(key).physical_users ? surface_queue : queue;
      const auto erased=queue.erase(value)+surface_queue.erase(value);
      if(surface_planning&&insert&&!edges.at(key).physical_users){std::swap(edge[0],edge[1]);continue;}
      const auto blocked=blocked_edges.find(edge[1]);
      if(insert && blocked!=blocked_edges.end() && blocked->second.count(edge[0])) {
        // Measuring another unchanged cell cannot reopen a rejected direction; Touch owns reactivation.
        queue.erase({Priority(length),edge});++stats.blocked_queue_skips;
      } else if(insert && !construction_frontier.count(edge))queue.erase({Priority(length),edge});
      else if (insert && prune_collapses && edges.at(key).forbidden[i])
        stats.collapse_filtered += erased;
      else if (insert) destination.insert(value);
      std::swap(edge[0],edge[1]);
    }
  }
  size_t invalid = 0, construction_invalid = 0, quality_invalid = 0, unmeasured_shape = 0, repair_bytes = 0;
  struct EdgeState { EdgeMeasure measure; size_t users = 0,physical_users=0; std::array<size_t,2> forbidden{}; };
  struct CellDebt {
    long double q=0,j=0,size=0,height=0,geometry=0;
    bool q_measured=false,j_measured=false,height_measured=false,geometry_measured=true,height_unresolved=false;
    bool q_bad=false,j_bad=false,size_bad=false,height_bad=false;
    template<class S>void Fields(S& s) {
      CachedScalar(s,q);CachedScalar(s,j);CachedScalar(s,size);CachedScalar(s,height);CachedScalar(s,geometry);
      s(q_measured,j_measured,height_measured,geometry_measured,height_unresolved,q_bad,j_bad,size_bad,height_bad);
    }
  };
  StageProgress debt;
  bool progress_consistent=true,census_started=false;
  struct CellState { uint64_t version=0; CellDebt debt;double q_value=0,j_value=0;std::array<Edge, 6> edges{}; std::array<unsigned char,6> forbidden{};std::array<bool,6> physical{}; std::array<Id,4> vertices{}; std::array<long double,6> geometry_scores{}; bool valid = false,target_valid=false,geometry_invalid=false,construction_valid=false,quality_valid=false,shape_measured=false;
    bool surface=false,near_feature=false,feature_known=false;
    unsigned char geometry_types=0,geometry_excess_bin=0;
    template<class S>void Fields(S& s) {
      s(version,debt,q_value,j_value,edges,forbidden,physical,vertices);
      for(auto& x:geometry_scores)CachedScalar(s,x);
      s(valid,target_valid,geometry_invalid,construction_valid,quality_valid,shape_measured);
      s(surface,near_feature,feature_known,geometry_types,geometry_excess_bin);
    }
  };
  struct CachedRow {
    Id id=0;CellState state;std::array<long double,6> lengths{};
    std::array<uint64_t,14> repair_epochs{};uint16_t repair_active=0,repair_blocked=0;
    template<class S>void Fields(S& s){s(id,state);for(auto& x:lengths)CachedScalar(s,x);s(repair_epochs,repair_active,repair_blocked);}
  };
  std::map<Id,CellState> cells;
  std::map<Edge,EdgeState> edges;
  std::set<std::pair<long double,Edge>> queue;
  std::map<Id,std::set<Id>> vertex_cells, blocked_edges;
  size_t vertex_links=0, blocked_links=0;
  std::map<Id,std::vector<RepairFeature>> cell_repairs;
  struct RepairDemand { size_t users=0;uint64_t epoch=0;bool blocked=false; };
  uint64_t repair_epoch=0;
  std::map<RepairFeature,RepairDemand> repair_users;
  std::set<std::pair<uint64_t,RepairFeature>> repair_queue;
  std::map<Id,long double> repair_cell_severity;
  std::map<RepairFeature,long double> repair_severity;
  std::set<std::pair<long double,RepairFeature>> repair_severity_queue;
  std::set<RepairFeature> repair_zero;
  size_t Bytes() const {
    return transfer_memory::Add(MapBytes(cells),MapBytes(edges),MapBytes(queue),MapBytes(surface_queue),MapBytes(edge_history),MapBytes(construction_frontier),MapBytes(cell_repairs),MapBytes(repair_users),MapBytes(repair_queue),MapBytes(repair_cell_severity),MapBytes(repair_severity),MapBytes(repair_severity_queue),MapBytes(repair_zero),repair_bytes,
        MapBytes(geometry_queue),MapBytes(geometry_split_priorities),MapBytes(vertex_cells),MapBytes(blocked_edges),transfer_memory::Mul(transfer_memory::Add(vertex_links,blocked_links),sizeof(Id)+4*sizeof(void*)));
  }
  long double RepairWeight(const CellState& row) const {
    // Cached local required debt steers search; only the complete distributed transaction certifies the feature.
    const auto& d=row.debt;long double weight=0;
    if(surface_planning)return d.size+d.geometry+(row.geometry_invalid||d.size_bad?1.L:0.L);
    if(d.q_measured)weight+=d.q;else if(!row.quality_valid)weight+=1;
    if(d.j_measured)weight+=d.j;else if(!row.quality_valid)weight+=1;
    if(!heights.empty())weight+=d.height+(d.height_unresolved||d.height_bad?1.L:0.L);
    if(size_repairs)weight+=d.size+(d.size_bad?1.L:0.L);
    if(geometry_repairs)weight+=d.geometry+(!d.geometry_measured||row.geometry_invalid?1.L:0.L);
    if(!std::isfinite(weight)||weight<0)throw std::logic_error("Nonfinite native repair severity.");
    return weight>0?weight:1.L;
  }
  void AddRepairSeverity(const RepairFeature& key,long double value) {
    if(!std::isfinite(value)||value<0)throw std::logic_error("Invalid native repair severity contribution.");
    auto& total=repair_severity[key];
    if(repair_users.at(key).users)repair_severity_queue.erase({-total,key});
    total+=value;
    if(!std::isfinite(total))throw std::logic_error("Nonfinite native repair severity sum.");
    const auto& demand=repair_users.at(key);
    if(demand.users&&!demand.blocked)repair_severity_queue.insert({-total,key});
  }
  void RemoveRepairSeverity(const RepairFeature& key,long double value) {
    const auto found=repair_severity.find(key);if(found==repair_severity.end())throw std::logic_error("Missing native repair severity.");
    auto& total=found->second;repair_severity_queue.erase({-total,key});
    total=std::max(0.L,total-value);
  }
  void UpdateRepairWeight(Id id,const CellState& row) {
    const auto found=cell_repairs.find(id);if(found==cell_repairs.end())return;
    const long double prior=repair_cell_severity.at(id),fresh=RepairWeight(row);
    if(prior==fresh)return;
    for(const auto& key:found->second)RemoveRepairSeverity(key,prior);
    for(const auto& key:found->second)AddRepairSeverity(key,fresh);
    repair_cell_severity[id]=fresh;
  }
  void Account(const CellState& row,bool add) {
    const auto count=[&](size_t& total,size_t value){if(add)total+=value;else total-=value;};
    const auto& d=row.debt;const long double sign=add?1.L:-1.L;
    count(debt.q_measured_cells,d.q_measured);count(debt.j_measured_cells,d.j_measured);
    count(debt.shape_measured_cells,d.q_measured && d.j_measured);
    count(debt.height_measured_cells,d.height_measured);count(debt.geometry_measured_cells,d.geometry_measured);
    count(debt.height_unresolved_cells,d.height_unresolved);
    count(debt.q_bad_cells,d.q_bad);count(debt.j_bad_cells,d.j_bad);count(debt.size_bad_cells,d.size_bad);
    count(debt.height_bad_cells,d.height_bad);count(debt.geometry_bad_cells,row.geometry_invalid);
    debt.q_hinge_squared+=sign*d.q;debt.j_hinge_squared+=sign*d.j;
    debt.size_hinge_squared+=sign*d.size;debt.height_hinge_squared+=sign*d.height;
    debt.geometry_excess_squared+=sign*d.geometry;
  }
  bool RequestedWall(const OwnedCell& owned)const {
    if(heights.empty())return false;
    return std::any_of(owned.physical.begin(),owned.physical.end(),[&](const FacetBinding& f) {
      return f.present && heights.count(geometry.Get(f.facet).marker);
    });
  }
  // Demand coverage only: unmeasured volume rows remain unknown in the public full-mesh census.
  std::array<size_t,3> SurfaceCensus(const Owned& owned)const {
    std::array<size_t,3> count{}; // required, current measured, current geometry measured
    for(const auto& item:owned)if(RequestedWall(item.second)) {
      ++count[0];const auto found=cells.find(item.first);
      if(found!=cells.end()&&found->second.version==item.second.version) {
        ++count[1];count[2]+=found->second.debt.geometry_measured;
      }
    }
    return count;
  }
  StageProgress Progress(size_t owned)const {
    StageProgress result=progress_consistent?debt:StageProgress{};
    result.cache_consistent=progress_consistent;result.owned_cells=owned;
    result.measured_cells=progress_consistent?cells.size():0;
    result.invalid_cells=progress_consistent?invalid:0;
    result.construction_invalid_cells=progress_consistent?construction_invalid:0;
    result.quality_invalid_cells=progress_consistent?quality_invalid:0;
    result.remaining_edges=queue.size()+surface_queue.size()+geometry_queue.size();result.remaining_repairs=repair_queue.size();
    result.unmeasured_cells=owned-result.measured_cells;
    result.shape_unmeasured_cells=owned-result.shape_measured_cells;
    result.height_requested=!heights.empty();result.surface_error_requested=!geometry.ExtensionComponents().empty();
    result.height_unmeasured_cells=result.height_requested?owned-result.height_measured_cells:0;
    result.geometry_unmeasured_cells=owned-result.geometry_measured_cells;
    result.census_complete=result.measured_cells==owned && progress_consistent && census_started;
    result.shape_complete=result.shape_measured_cells==owned && progress_consistent && census_started;
    result.height_complete=(!result.height_requested || !result.height_unmeasured_cells) && progress_consistent;
    result.geometry_complete=!result.geometry_unmeasured_cells && progress_consistent;
    result.complete=result.census_complete && result.shape_complete && result.height_complete && result.geometry_complete;
    // Incremental subtraction can leave round-off below zero after a large number of updates.
    result.q_hinge_squared=std::max(0.L,result.q_hinge_squared);result.j_hinge_squared=std::max(0.L,result.j_hinge_squared);
    result.size_hinge_squared=std::max(0.L,result.size_hinge_squared);result.height_hinge_squared=std::max(0.L,result.height_hinge_squared);
    result.geometry_excess_squared=std::max(0.L,result.geometry_excess_squared);
    return result;
  }
  bool Diagnose(const OwnedCell& owned,CellDiagnostic& out)const {
    out={};const auto found=cells.find(owned.cell.id);
    if(!progress_consistent||found==cells.end()||found->second.version!=owned.version)return false;
    const auto& row=found->second;const auto& d=row.debt;
    out.q_measured=d.q_measured;out.j_measured=d.j_measured;out.geometry_measured=d.geometry_measured;
    out.q=row.q_value;out.J=row.j_value;out.geometry_excess_l2=double(std::sqrt(std::max(0.L,d.geometry)));
    out.q_bad=d.q_bad;out.j_bad=d.j_bad;out.geometry_bad=row.geometry_invalid;out.size_bad=d.size_bad;
    out.height_bad=d.height_bad;out.height_unresolved=d.height_unresolved;out.surface=row.surface;
    out.near_feature=row.near_feature;out.feature_known=row.feature_known;out.edges=row.edges;
    for(size_t i=0;i<6;++i){const auto edge=edges.find(row.edges[i]);if(edge==edges.end())return false;out.lengths[i]=edge->second.measure.length;}
    const auto repairs=cell_repairs.find(owned.cell.id);
    if(repairs!=cell_repairs.end())for(const auto& key:repairs->second) {
      if(out.repair_count==out.repairs.size())return false;
      const auto demand=repair_users.find(key);if(demand==repair_users.end())return false;
      out.repairs[out.repair_count++]={Feature{key.second,key.first},demand->second.epoch,demand->second.blocked};
    }
    out.cache_valid=true;return true;
  }
  Choice Best(bool repairing) const {
    if (repairing) {
      if (repair_queue.empty()) return {};
      const auto& oldest=*repair_queue.begin();const auto& key=oldest.second;
      Choice choice; choice.active=true; choice.feature={key.second,key.first};choice.repair_epoch=oldest.first;choice.fair_repair=true;return choice;
    }
    if ((!split_lanes||coarsening||lane==Lane::Surface) && !geometry_queue.empty()) {
      const auto key=std::get<2>(*geometry_queue.begin());
      return {key,edges.at(key).measure,true,{},true,std::get<0>(*geometry_queue.begin()),std::get<1>(*geometry_queue.begin())};
    }
    const auto& active=split_lanes&&!coarsening&&lane==Lane::Surface ? surface_queue : queue;
    if (active.empty()) return {};
    const auto key = active.begin()->second;
    Edge canonical=key; std::sort(canonical.begin(),canonical.end());
    return {key,edges.at(canonical).measure,true,{},false,Priority(edges.at(canonical).measure.length)};
  }
  std::vector<Choice> RepairBatch(const Owned& working,size_t limit,bool& oversized) const {
    oversized=false;std::vector<Choice> result;if(!limit||repair_queue.empty())return result;
    auto feature_cells=[&](const RepairFeature& key,std::vector<Id>& ids,std::set<Id>& vertices,bool& too_large) {
      const auto count=key.first;const auto& feature=key.second;
      if(count<1||count>3)throw std::logic_error("Invalid native repair feature.");
      const std::set<Id>* seed=nullptr;
      for(unsigned i=0;i<count;++i) {
        const auto found=vertex_cells.find(feature[i]);if(found==vertex_cells.end())return;
        if(!seed||found->second.size()<seed->size())seed=&found->second;
      }
      size_t scanned=0;
      for(Id id:*seed) {
        if(++scanned>MaximumDirectoryScan){too_large=true;return;}
        const auto found=working.find(id);if(found==working.end())throw std::logic_error("Repair star lost an owned cell.");
        const auto& cell=found->second.cell;bool contains=true;
        for(unsigned i=0;i<count;++i)contains=contains&&std::any_of(cell.v.begin(),cell.v.end(),[&](Node node){return node.id==feature[i];});
        if(!contains)continue;
        ids.push_back(id);for(const auto& node:cell.v)vertices.insert(node.id);
        if(ids.size()>MaximumCavityCells){too_large=true;return;}
      }
    };
    auto make_choice=[&](const RepairFeature& key,uint64_t epoch,bool fair) {
      Choice choice;choice.active=true;choice.feature={key.second,key.first};choice.repair_epoch=epoch;
      choice.fair_repair=fair;if(!fair)choice.priority_score=-repair_severity.at(key);return choice;
    };
    const auto oldest=*repair_queue.begin();const auto first=make_choice(oldest.second,oldest.first,true);
    std::vector<Id> first_cells;std::set<Id> used;bool first_oversized=false;
    feature_cells(oldest.second,first_cells,used,first_oversized);
    if(first_oversized){oversized=true;result.push_back(first);return result;}
    result.push_back(first);std::set<RepairFeature> selected{oldest.second};size_t scanned=0;
    for(const auto& priority:repair_severity_queue) {
      if(result.size()>=limit||scanned++>=MaximumDirectoryScan)break;
      const auto& key=priority.second;if(selected.count(key))continue;
      const auto demand=repair_users.find(key);
      if(demand==repair_users.end()||!demand->second.users||demand->second.blocked)continue;
      Choice choice=make_choice(key,demand->second.epoch,false);
      std::vector<Id> star_cells;std::set<Id> star_vertices;bool star_oversized=false;
      feature_cells(key,star_cells,star_vertices,star_oversized);if(star_oversized)continue;
      bool disjoint=true;for(Id vertex:star_vertices)disjoint=disjoint&&!used.count(vertex);
      if(!disjoint)continue;
      result.push_back(choice);selected.insert(key);used.insert(star_vertices.begin(),star_vertices.end());
    }
    return result;
  }
  std::vector<Choice> Batch(const Owned& working, size_t limit) {
    std::vector<Choice> result;
    std::set<Id> used;
    size_t scanned=0;
    const auto& active=split_lanes&&!coarsening&&lane==Lane::Surface ? surface_queue : queue;
    for (auto it=active.begin();it!=active.end() && result.size()<limit && scanned++<MaximumDirectoryScan;) {
      const auto edge=(it++)->second;
      Edge canonical=edge; std::sort(canonical.begin(),canonical.end());
      const Choice choice{edge,edges.at(canonical).measure,true,{}};
      if (FilterCollapse(choice,working)) continue;
      const auto& star=vertex_cells.at(coarsening ? edge[1] : edge[0]);
      std::set<Id> vertices;
      bool disjoint=true, oversized=false;
      size_t cells=0, scanned_star=0;
      for (Id id:star) {
        if (++scanned_star>MaximumDirectoryScan) { oversized=true; break; }
        const auto& cell=working.at(id).cell;
        if (!coarsening && std::none_of(cell.v.begin(),cell.v.end(),[&](Node node){return node.id==edge[1];})) continue;
        if (++cells>MaximumCavityCells) { oversized=true; break; }
        for (auto node:cell.v) {
          vertices.insert(node.id);
          disjoint=disjoint && !used.count(node.id);
        }
      }
      if (oversized) { result.push_back(choice); break; }  // Complete-star admission reports the cap.
      // Local disjointness only reduces redundant proposals; reservation admits the complete remote stars.
      if (disjoint) { result.push_back(choice); used.insert(vertices.begin(),vertices.end()); }
    }
    return result;
  }
  void Cached(const Cell& cell, std::map<Edge,EdgeMeasure>& values) const {
    for (size_t i=0; i<4; ++i) for (size_t j=i+1; j<4; ++j) {
      const Edge key{std::min(cell.v[i].id,cell.v[j].id),std::max(cell.v[i].id,cell.v[j].id)};
      const auto found=edges.find(key);
      if (found!=edges.end()) values.emplace(key,found->second.measure);
    }
  }
  void Block(Edge edge, Feature feature, bool repairing) {
    if (repairing) { Service(feature,false);return; }
    Note(edge,4);
    ServiceEdge(edge);
    Edge canonical=edge;std::sort(canonical.begin(),canonical.end());
    const auto it = edges.find(canonical);
    if(it!=edges.end()){queue.erase({Priority(it->second.measure.length),edge});surface_queue.erase({Priority(it->second.measure.length),edge});}
    // Rejection can reach an owner before progressive measurement discovers its edge.
    if (coarsening || track_splits) {
      const bool inserted=blocked_edges[edge[1]].insert(edge[0]).second;
      blocked_links+=inserted;stats.blocked_unmeasured+=inserted && it==edges.end();
    }
    if (track_splits && !coarsening) blocked_links+=blocked_edges[edge[0]].insert(edge[1]).second;
  }
  void Forget(Edge edge) {
    const auto found=blocked_edges.find(edge[1]);
    if (found==blocked_edges.end()) return;
    blocked_links-=found->second.erase(edge[0]);
    if (found->second.empty()) blocked_edges.erase(found);
  }
  void TouchRepairSupport(const std::array<Id,4>& vertices) {
    // Only a tetrahedron containing the whole feature changes its complete imported star.
    for(unsigned mask=1;mask<15;++mask) {
      RepairFeature key{};
      for(unsigned i=0;i<4;++i)if(mask&(1u<<i))key.second[key.first++]=vertices[i];
      const auto found=repair_users.find(key);
      if(found==repair_users.end() || !found->second.users || !found->second.blocked)continue;
      auto& demand=found->second;demand.blocked=false;demand.epoch=repair_epoch;
      repair_queue.insert({demand.epoch,key});repair_severity_queue.insert({-repair_severity.at(key),key});
    }
  }
  void Touch(Id vertex) {
    const auto found=blocked_edges.find(vertex);
    if (found==blocked_edges.end()) return;
    auto reactivated=std::move(found->second);
    blocked_links-=reactivated.size();blocked_edges.erase(found);
    for (Id retained:reactivated) {
      Edge edge{retained,vertex}, key=edge; std::sort(key.begin(),key.end());
      const auto measured=edges.find(key);
      if (measured==edges.end())continue;
      if(!coarsening && !geometry.ExtensionComponents().empty()) {
        const auto star=vertex_cells.find(vertex);
        if(star!=vertex_cells.end())for(Id id:star->second) {
          const auto& row=cells.at(id);
          for(size_t k=0;k<row.edges.size();++k)if(row.edges[k]==key && row.geometry_scores[k]>0)
            if(construction_frontier.count(key))stats.geometry_reactivated+=geometry_queue.insert({-GeometryPriority(row.geometry_scores[k],key),id,key}).second;
        }
      }
      if(!Candidate(measured->second.measure.length))continue;
      const auto direction=retained==key[0] ? 0u : 1u;
      if (prune_collapses && measured->second.forbidden[direction]) continue;
      if (!coarsening) edge=key;
      if(!construction_frontier.count(edge))continue;
      const auto count=queue.size()+surface_queue.size();Queue(key,measured->second.measure.length,true);
      const bool inserted=queue.size()+surface_queue.size()>count;
      if (coarsening) stats.collapse_reactivated+=inserted;
    }
  }
  bool FilterCollapse(const Choice& choice, const Owned& working) {
    if (!coarsening || !prune_collapses || !choice.active) return false;
    if(!geometry.ContractionAllowed(choice.edge[1],choice.edge[0])) {
      Block(choice.edge,{},false);++stats.collapse_filtered;++stats.collapse_constraint_filtered;return true;
    }
    const auto star=vertex_cells.find(choice.edge[1]);
    if (star==vertex_cells.end()) throw std::logic_error("Missing native 3D local collapse star.");
    const Point apex=choice.edge[0]<choice.edge[1] ? choice.measure.a : choice.measure.b;
    {
      Timer timer(stats.collapse_geometry_seconds,timings, SU2NativeTiming3D::Operation::GeometryBound);
      size_t scanned=0;
      for (Id id:star->second) {
        if (++scanned>MaximumDirectoryScan) break;
        const auto& row=working.at(id);
        if (std::any_of(row.cell.v.begin(),row.cell.v.end(),[&](Node n){return n.id==choice.edge[0];})) continue;
        if (LeavesFacet(row,choice.edge[1],apex)) {
          Block(choice.edge,{},false); ++stats.collapse_filtered; return true;
        }
        if(CollapseConstraintViolation(row,choice.edge[1],{choice.edge[0],apex},geometry,tolerance,heights)) {
          Block(choice.edge,{},false);++stats.collapse_filtered;++stats.collapse_constraint_filtered;return true;
        }
      }
    }
    Timer timer(stats.collapse_orientation_seconds,timings, SU2NativeTiming3D::Operation::Topology);
    size_t scanned=0;
    for (Id id:star->second) {
      if (++scanned>MaximumDirectoryScan) break;
      auto v=working.at(id).cell.v;
      if (std::any_of(v.begin(),v.end(),[&](Node n){return n.id==choice.edge[0];})) continue;
      for (auto& node:v) if (node.id==choice.edge[1]) node={choice.edge[0],apex};
      ++stats.collapse_orientation_checks;
      if (!(Orientation(v[0].p,v[1].p,v[2].p,v[3].p)>0)) {
        // Surface planning may repair connectivity before contracting; all final validity checks remain.
        if(surface_planning && !geometry.ExtensionComponents().empty())return false;
        Block(choice.edge,{},false); ++stats.collapse_orientation_filtered; return true;
      }
    }
    return false;
  }
  void Drop(Id id) {
    const auto found = cells.find(id);
    if (found==cells.end()) throw std::logic_error("Missing native 3D cached cell removal.");
    Account(found->second,false);
    invalid -= !found->second.valid;
    construction_invalid -= !found->second.construction_valid;
    quality_invalid -= !found->second.quality_valid;
    unmeasured_shape -= !found->second.shape_measured;
    for(size_t i=0;i<6;++i)geometry_queue.erase({-GeometryPriority(found->second.geometry_scores[i],found->second.edges[i]),id,found->second.edges[i]});
    for (Id vertex:found->second.vertices) {
      auto& star=vertex_cells.at(vertex);
      vertex_links-=star.erase(id);
      if (star.empty()) vertex_cells.erase(vertex);
    }
    RemoveRepairs(id);
    for (size_t slot=0;slot<found->second.edges.size();++slot) {
      const auto key=found->second.edges[slot];
      auto& state = edges.at(key);
      Queue(key,state.measure.length,false);
      state.physical_users-=found->second.physical[slot];
      for (unsigned direction=0;direction<2;++direction)
        state.forbidden[direction]-=bool(found->second.forbidden[slot] & (1u<<direction));
      if (--state.users==0) { Forget(key); Forget({key[1],key[0]}); edges.erase(key); }
      else Queue(key,state.measure.length,true);
    }
    cells.erase(found);
  }
  void RemoveRepairs(Id id) {
    const auto it=cell_repairs.find(id);if(it==cell_repairs.end())return;
    repair_bytes-=transfer_memory::Bytes(it->second);
    // Preserve waiting age and rejection state through transient zero-user counts until the publication completes.
    const long double weight=repair_cell_severity.at(id);
    for(const auto& key:it->second) {
      RemoveRepairSeverity(key,weight);
      auto& demand=repair_users.at(key);
      if(--demand.users==0)repair_zero.insert(key);
      else if(!demand.blocked)repair_severity_queue.insert({-repair_severity.at(key),key});
    }
    repair_cell_severity.erase(id);
    cell_repairs.erase(it);
  }
  void UpdateRepairs(const Cell& cell,const CellState& row) {
    if(!track_repairs)return;
    const bool needed=surface_planning?!row.construction_valid:quality_only?(!row.quality_valid || (geometry_repairs && row.geometry_invalid) || (size_repairs && row.debt.size_bad)):!row.valid;
    if(needed&&!cell_repairs.count(cell.id))AddRepairs(cell,quality_only && size_repairs && row.quality_valid && !geometry_repairs);
    else if(!needed&&cell_repairs.count(cell.id))RemoveRepairs(cell.id);
  }
  void ChangePhase(bool improvement,const Owned& working,const std::shared_ptr<const FrozenMetricIdentity>& identity) {
    geometry_split_priorities.clear();geometry_priority_mode=false;
    size_repairs=geometry_repairs=false;
    track_repairs=repair_event=improvement;prune_collapses=false;queue.clear();surface_queue.clear();geometry_queue.clear();construction_frontier.clear();
    for(auto& item:cells) {
      auto& row=item.second;const auto found=working.find(item.first);
      if(found==working.end()||found->second.version!=row.version)throw std::logic_error("Phase census lost a versioned owned row.");
      const auto& cell=found->second.cell;
      for(unsigned i=0;i<4;++i)if(cell.v[i].id!=row.vertices[i])throw std::logic_error("Phase census changed owned vertices without a version.");
      for(const auto& edge:row.edges) {const auto& cached=edges.at(edge).measure;const Node *a=nullptr,*b=nullptr;
        for(const auto& node:cell.v){if(node.id==edge[0])a=&node;if(node.id==edge[1])b=&node;}
        if(!a||!b||!cached.Reusable(a->p,b->p,identity))throw std::logic_error("Phase census changed edge coordinates or field without a version.");}
      const bool before=row.valid;invalid-=!before;
      row.target_valid=improvement&&!surface_planning ? (!row.debt.size_bad&&row.quality_valid) : !row.debt.size_bad;
      row.valid=row.target_valid&&!row.geometry_invalid;invalid+=!row.valid;
      UpdateRepairs(found->second.cell,row);UpdateRepairWeight(item.first,row);
    }
    FinishRepairs();
    if(!improvement) {
      SeedFrontier(working);
      for(const auto& row:edges)Queue(row.first,row.second.measure.length,true);
      if(!coarsening)for(const auto& item:cells)for(size_t i=0;i<6;++i){const auto edge=item.second.edges[i];const auto blocked=blocked_edges.find(edge[1]);
        if(item.second.geometry_scores[i]>0 && construction_frontier.count(edge) && (blocked==blocked_edges.end()||!blocked->second.count(edge[0])))
          geometry_queue.insert({-GeometryPriority(item.second.geometry_scores[i],edge),item.first,edge});}
    }
  }
  void EnableSizeRepairs(const Owned& working) {
    size_repairs=true;
    for(const auto& row:working){UpdateRepairs(row.second.cell,cells.at(row.first));UpdateRepairWeight(row.first,cells.at(row.first));}
    FinishRepairs();
  }
  void EnableGeometryRepairs(const Owned& working) {
    size_repairs=false;geometry_repairs=true;
    for(const auto& row:working){UpdateRepairs(row.second.cell,cells.at(row.first));UpdateRepairWeight(row.first,cells.at(row.first));}
    FinishRepairs();
  }
  void ClassifyFeatures(const Cell& cell,CellState& row) const {
    const auto* parameters=geometry.Parameters();const auto* mobility=geometry.Mobility();
    row.near_feature=false;
    row.feature_known=parameters&&mobility&&mobility->identity;
    if(row.feature_known)try {
      for(const auto& node:cell.v) {
        const auto* point=parameters->Find(node.id);
        if(point&&parameters->Geometry().MobilityDimension(point->binding,*mobility)<2)row.near_feature=true;
      }
    }catch(const std::exception&){row.feature_known=row.near_feature=false;}
  }
  void RefreshQuality(const OwnedCell& owned,const PatchMetric& metric,bool valid,bool quality_valid,
                      const FirstHeightReport* height,bool height_valid,const std::shared_ptr<const FrozenMetricIdentity>& identity) {
    auto& row=cells.at(owned.cell.id);if(row.version!=owned.version)throw std::logic_error("Quality refresh found stale owned version.");
    ClassifyFeatures(owned.cell,row);
    if(metric.edges.size()!=6||!std::isfinite(metric.maximum_length))throw std::invalid_argument("Incomplete quality refresh edge measurements.");
    for(const auto& key:row.edges){const auto measured=metric.edges.find(key);if(measured==metric.edges.end())throw std::logic_error("Quality refresh omitted cached edge.");
      const auto& prior=edges.at(key).measure;const auto& fresh=measured->second;
      if(!prior.Reusable(fresh.a,fresh.b,identity)||!fresh.Reusable(prior.a,prior.b,identity)||prior.length!=fresh.length)
        throw std::logic_error("Quality refresh changed cached edge certificate.");}
    Account(row,false);invalid-=!row.valid;quality_invalid-=!row.quality_valid;unmeasured_shape-=!row.shape_measured;
    auto& d=row.debt;auto hinge=[](long double x){return std::max(0.L,x);};
    row.shape_measured=metric.shape_measured;row.quality_valid=quality_valid;
    row.q_value=metric.shape_measured?metric.minimum_mean_ratio:0;row.j_value=metric.shape_measured?metric.minimum_scaled_jacobian:0;
    d.q_measured=metric.shape_measured&&std::isfinite(metric.minimum_mean_ratio);d.j_measured=metric.shape_measured&&std::isfinite(metric.minimum_scaled_jacobian);
    d.q=d.j=0;d.q_bad=d.j_bad=false;
    if(d.q_measured){const auto r=hinge(1.L-static_cast<long double>(metric.minimum_mean_ratio)/MinimumMeanRatio);d.q=r*r;d.q_bad=metric.minimum_mean_ratio<MinimumMeanRatio;}
    if(d.j_measured){const auto r=hinge(1.L-static_cast<long double>(metric.minimum_scaled_jacobian)/MinimumScaledJacobian);d.j=r*r;d.j_bad=metric.minimum_scaled_jacobian<MinimumScaledJacobian;}
    d.height=0;d.height_measured=d.height_bad=d.height_unresolved=false;
    if(height&&!heights.empty()){d.height_measured=height->measured&&std::isfinite(height->maximum_relative_error)&&std::isfinite(height->minimum_barycentric);
      d.height_bad=!height_valid;d.height_unresolved=!d.height_measured||height->missing_cells||height->reference_clearance_failures;
      if(d.height_measured){const auto r=hinge(static_cast<long double>(height->maximum_relative_error)/heights.tolerance-1.L),f=hinge(-3.L*height->minimum_barycentric);d.height=r*r+f*f;}}
    row.target_valid=valid;row.valid=valid&&!row.geometry_invalid;Account(row,true);invalid+=!row.valid;quality_invalid+=!row.quality_valid;unmeasured_shape+=!row.shape_measured;
    UpdateRepairs(owned.cell,row);UpdateRepairWeight(owned.cell.id,row);FinishRepairs();
  }
  void EnableCollapseFilter() {
    prune_collapses=true;
    for (const auto& row:edges) Queue(row.first,row.second.measure.length,true);
  }
  bool LeavesFacet(const OwnedCell& owned, Id removed, Point retained) {
    if(geometry.Mobility())return false; // Original chart seams are not physical constraints; full-star remapping proves replacement.
    for (size_t face=0;face<4;++face) {
      if (!owned.physical[face].present || owned.cell.v[face].id==removed) continue;
      ++stats.collapse_geometry_checks;
      if (!geometry.Contains(owned.physical[face].facet,retained)) return true;
    }
    return false;
  }
  unsigned char Forbidden(const OwnedCell& owned, Edge edge) {
    if (!coarsening) return 0;
    Timer timer(stats.collapse_geometry_seconds,timings, SU2NativeTiming3D::Operation::GeometryBound);
    unsigned char blocked=0;
    for (unsigned direction=0;direction<2;++direction) {
      const Id retained=edge[direction], removed=edge[1-direction];
      Point point{};
      for (auto node:owned.cell.v) if (node.id==retained) point=node.p;
      if (LeavesFacet(owned,removed,point)) blocked|=1u<<direction;
    }
    return blocked;
  }
  void Add(const OwnedCell& owned, const PatchMetric& metric, bool valid, bool quality_valid, const std::string& reason,
           const FirstHeightReport* height=nullptr,bool height_valid=true) {
    D9QueryScope d9_query(SU2NativeD9::Site::Census, &geometry);
    const auto& cell=owned.cell;
    if (metric.edges.size()!=6 || !std::isfinite(metric.maximum_length))
      throw std::runtime_error(reason.empty()?"Incomplete native 3D initial/updated metric measurement.":reason);
    CellState row; row.version=owned.version;row.valid=row.target_valid=valid;row.shape_measured=metric.shape_measured;row.quality_valid=quality_valid;
    row.surface=std::any_of(owned.physical.begin(),owned.physical.end(),[](const FacetBinding& face){return face.present;});
    const auto* parameters=geometry.Parameters();
    if(metric.shape_measured)ClassifyFeatures(cell,row);
    row.construction_valid=metric.maximum_length<=MaximumMetricEdge;
    auto hinge=[](long double value){return std::max(0.L,value);};
    auto& d=row.debt;
    row.q_value=metric.shape_measured?metric.minimum_mean_ratio:0;row.j_value=metric.shape_measured?metric.minimum_scaled_jacobian:0;
    d.q_measured=metric.shape_measured && std::isfinite(metric.minimum_mean_ratio);
    d.j_measured=metric.shape_measured && std::isfinite(metric.minimum_scaled_jacobian);
    if(d.q_measured) {
      const auto r=hinge(1.L-static_cast<long double>(metric.minimum_mean_ratio)/MinimumMeanRatio);d.q=r*r;
      d.q_bad=metric.minimum_mean_ratio<MinimumMeanRatio;
    }
    if(d.j_measured) {
      const auto r=hinge(1.L-static_cast<long double>(metric.minimum_scaled_jacobian)/MinimumScaledJacobian);d.j=r*r;
      d.j_bad=metric.minimum_scaled_jacobian<MinimumScaledJacobian;
    }
    d.size_bad=metric.maximum_length>MaximumMetricEdge;
    for(const auto& edge:metric.edges) {
      if(surface_planning) {
        bool requested=false;
        for(unsigned f=0;f<4;++f)if(owned.physical[f].present&&heights.count(geometry.Get(owned.physical[f].facet).marker)&&
            cell.v[f].id!=edge.first[0]&&cell.v[f].id!=edge.first[1])requested=true;
        if(!requested)continue;
      }
      const auto r=hinge(edge.second.length/MaximumMetricEdge-1.L);d.size+=r*r;
    }
    if(height && !heights.empty()) {
      d.height_measured=height->measured && std::isfinite(height->maximum_relative_error) && std::isfinite(height->minimum_barycentric);
      d.height_bad=!height_valid;
      d.height_unresolved=!d.height_measured || height->missing_cells || height->reference_clearance_failures;
      if(d.height_measured) {
        const auto r=hinge(static_cast<long double>(height->maximum_relative_error)/heights.tolerance-1.L);
        const auto f=hinge(-3.L*height->minimum_barycentric);d.height=r*r+f*f;
      }
    }
    std::map<Edge,long double> geometry_scores;
    if (!geometry.ExtensionComponents().empty()) {
      const auto faces=Faces(cell);
      for(size_t slot=0;slot<4;++slot)if(owned.physical[slot].present) {
        if(surface_planning&&!heights.count(geometry.Get(owned.physical[slot].facet).marker))continue;
        std::array<Point,3> triangle{};
        for(size_t i=0;i<3;++i)for(auto n:cell.v)if(n.id==faces[slot][i])triangle[i]=n.p;
        const double error=geometry.SurfaceDeviation(owned.physical[slot].facet,triangle,SU2NativeGeometry::SurfaceQueryNeed::Magnitude());
        const auto allowed=tolerance;
        if(surface_planning && wall_counters)
          wall_counters->ObserveMeasuredFace(faces[slot],owned.physical[slot].facet,error,tolerance);
        if(std::isfinite(error)) {
          const auto excess=hinge(static_cast<long double>(error)-allowed);d.geometry+=excess*excess;
        } else d.geometry_measured=false;
        if(error<=allowed)continue;
        unsigned type=0;const Id facet=owned.physical[slot].facet;
        const auto analytic=geometry.Analytic().find(facet);
        if(analytic!=geometry.Analytic().end())type=unsigned(analytic->second.kind);
        else if(geometry.Affine().count(facet))type=5;
        else if(parameters&&parameters->Geometry().Curves().count(facet))type=6;
        row.geometry_types|=static_cast<unsigned char>(1u<<type);
        unsigned bin=5;
        if(std::isfinite(error)&&allowed>0) {
          const auto excess=static_cast<long double>(error)/allowed-1;
          bin=excess<.01L?0:excess<.1L?1:excess<1?2:excess<10?3:4;
        }
        row.geometry_excess_bin=std::max(row.geometry_excess_bin,static_cast<unsigned char>(bin));
        row.valid=false;row.geometry_invalid=true;
        WallFaceWeights law_weights;
        if (surface_planning && std::isfinite(error)) {
          std::array<WallEdgeEstimate, 3> estimates{};
          if (parameters) {
            size_t edge = 0;
            for (size_t i = 0; i < 3; ++i)
              for (size_t j = i + 1; j < 3; ++j)
                estimates[edge++] =
                    EstimateWallEdge(*parameters, {faces[slot][i], triangle[i]}, {faces[slot][j], triangle[j]}, facet);
          }
          law_weights = WallFaceEdgeWeights(estimates);
          if (wall_counters) wall_counters->ObserveLawFace(law_weights.weighted);
        }
        size_t face_edge = 0;
        for (size_t i = 0; i < 3; ++i)
          for (size_t j = i + 1; j < 3; ++j, ++face_edge) {
            const auto a = triangle[i], b = triangle[j];
            const Edge key{std::min(faces[slot][i], faces[slot][j]), std::max(faces[slot][i], faces[slot][j])};
            if (!std::isfinite(error)) continue;
            const long double excess = static_cast<long double>(error) - allowed;
            const long double x = static_cast<long double>(b.x) - a.x, y = static_cast<long double>(b.y) - a.y,
                              z = static_cast<long double>(b.z) - a.z;
            // Queue current geometry demand; the selected complete star owns projection and progress validation.
            if (surface_planning)
              geometry_scores[key] += excess * excess * (x * x + y * y + z * z) * law_weights.factors[face_edge];
            else
              geometry_scores[key] += excess * excess * (x * x + y * y + z * z);
          }
      }
    }
    if(!d.geometry_measured)d.geometry=0;
    for (size_t i=0;i<4;++i) {
      row.vertices[i]=cell.v[i].id;
      vertex_links+=vertex_cells[row.vertices[i]].insert(cell.id).second;
    }
    size_t slot=0;
    for (const auto& measured : metric.edges) {
      const auto key=measured.first;
      row.geometry_scores[slot]=geometry_scores[key];
      const auto blocked=blocked_edges.find(key[1]);
      if(!coarsening && construction_frontier.count(key) && row.geometry_scores[slot]>0 &&
          (blocked==blocked_edges.end() || !blocked->second.count(key[0])))
        geometry_queue.insert({-GeometryPriority(row.geometry_scores[slot],key),cell.id,key});
      auto inserted=edges.emplace(key,EdgeState{measured.second,0});
      auto& state=inserted.first->second;
      Queue(key,state.measure.length,false);
      if (!Same(state.measure.a,measured.second.a) || !Same(state.measure.b,measured.second.b) ||
          state.measure.length!=measured.second.length)
        throw std::logic_error("Inconsistent native 3D frozen edge measurement.");
      row.forbidden[slot]=Candidate(measured.second.length) ? Forbidden(owned,key) : 0;
      for (unsigned direction=0;direction<2;++direction)
        state.forbidden[direction]+=bool(row.forbidden[slot] & (1u<<direction));
      bool physical=false;for(unsigned face=0;face<4;++face)if(owned.physical[face].present &&
          (!surface_planning||heights.count(geometry.Get(owned.physical[face].facet).marker)) &&
          cell.v[face].id!=key[0] && cell.v[face].id!=key[1])physical=true;
      state.physical_users+=physical;row.physical[slot]=physical;
      ++state.users; row.edges[slot++]=key;
      Queue(key,state.measure.length,true);
    }
    row.construction_valid=row.construction_valid && !row.geometry_invalid;
    const auto inserted=cells.emplace(cell.id,std::move(row));
    if (!inserted.second) throw std::logic_error("Duplicate native 3D cached cell.");
    Account(inserted.first->second,true);
    invalid += !inserted.first->second.valid;
    construction_invalid += !inserted.first->second.construction_valid;
    quality_invalid += !inserted.first->second.quality_valid;
    unmeasured_shape += !inserted.first->second.shape_measured;
    UpdateRepairs(cell,inserted.first->second);
  }
  void AddRepairs(const Cell& cell,bool length_only=false) {
    auto& repairs=cell_repairs[cell.id];
    if (!repairs.empty()) throw std::logic_error("Duplicate native 3D repair queue seed.");
    if(!length_only)for (auto node:cell.v) repairs.push_back({1,{node.id,0,0}});
    for (auto edge:cells.at(cell.id).edges)
      if(!length_only || edges.at(edge).measure.length>MaximumMetricEdge)repairs.push_back({2,{edge[0],edge[1],0}});
    if(!length_only)for (auto face:Faces(cell)) repairs.push_back({3,Key(face)});
    for (auto key:repairs) {
      const auto inserted=repair_users.emplace(key,RepairDemand{0,repair_epoch,false});
      auto& demand=inserted.first->second;
      if(demand.users++==0 && !demand.blocked)repair_queue.insert({demand.epoch,key});
    }
    const long double weight=RepairWeight(cells.at(cell.id));repair_cell_severity[cell.id]=weight;
    for(const auto& key:repairs)AddRepairSeverity(key,weight);
    repair_bytes=transfer_memory::Add(repair_bytes,transfer_memory::Bytes(repairs));
  }
  void Service(Feature feature,bool accepted) {
    const RepairFeature key{feature.count,feature.vertices};
    const auto found=repair_users.find(key);if(found==repair_users.end())return;
    auto& demand=found->second;repair_queue.erase({demand.epoch,key});repair_severity_queue.erase({-repair_severity.at(key),key});
    demand.epoch=repair_epoch;demand.blocked=!accepted;
    if(accepted && demand.users){repair_queue.insert({demand.epoch,key});repair_severity_queue.insert({-repair_severity.at(key),key});}
  }
  void FinishRepairs() {
    for(const auto& key:repair_zero) {
      const auto found=repair_users.find(key);
      if(found!=repair_users.end() && !found->second.users) {
        repair_queue.erase({found->second.epoch,key});repair_severity_queue.erase({-repair_severity.at(key),key});
        repair_severity.erase(key);repair_users.erase(found);
      }
    }
    repair_zero.clear();
  }
  bool HasCoarseningDemand()const {
    for(const auto& edge:edges)if(Candidate(edge.second.measure.length))for(unsigned direction=0;direction<2;++direction) {
      const auto retained=edge.first[direction],removed=edge.first[1-direction];
      const auto blocked=blocked_edges.find(removed);
      if(!edge.second.forbidden[direction] && (blocked==blocked_edges.end() || !blocked->second.count(retained)))return true;
    }
    return false;
  }
  void SeedFrontier(const Owned& working) {
    for(const auto& row:working)for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j) {
      Edge edge{row.second.cell.v[i].id,row.second.cell.v[j].id};std::sort(edge.begin(),edge.end());
      construction_frontier.insert(edge);
      if(coarsening){std::swap(edge[0],edge[1]);construction_frontier.insert(edge);}
    }
  }
  bool ServiceEdge(Edge edge) {
    const bool serviced=construction_frontier.erase(edge);
    const auto direction=edge;std::sort(edge.begin(),edge.end());
    const auto measured=edges.find(edge);
    if(measured!=edges.end()){queue.erase({Priority(measured->second.measure.length),direction});surface_queue.erase({Priority(measured->second.measure.length),direction});}
    const auto star=vertex_cells.find(edge[0]);
    if(star!=vertex_cells.end())for(Id id:star->second) {
      const auto& row=cells.at(id);
      for(size_t slot=0;slot<row.edges.size();++slot)if(row.edges[slot]==edge)
        geometry_queue.erase({-GeometryPriority(row.geometry_scores[slot],edge),id,edge});
    }
    return serviced;
  }
  size_t ServiceClaimedVertex(Id vertex) {
    // Full old/new vertex claims retire every edge whose paired-face prediction could have changed.
    const auto star=vertex_cells.find(vertex);if(star==vertex_cells.end())return 0;
    size_t serviced=0;
    for(Id id:star->second) {
      const auto& row=cells.at(id);
      if(!coarsening) {
        for(const auto& edge:row.edges)if(construction_frontier.count(edge)&&
            (!split_lanes||edges.at(edge).physical_users)){Note(edge,3);serviced+=ServiceEdge(edge);}
      } else {
        // Every collapse of this neighboring point imports a star containing the committed vertex.
        for(Id removed:row.vertices) {
          const auto& neighbors=vertex_cells.at(removed);
          for(Id neighbor:neighbors)for(Id retained:cells.at(neighbor).vertices)
            if(retained!=removed && construction_frontier.count({retained,removed}))serviced+=ServiceEdge({retained,removed});
        }
      }
    }
    return serviced;
  }
  void Restore(const OwnedCell& owned,const CachedRow& record,const std::shared_ptr<const FrozenMetricIdentity>& identity) {
    const auto& row=record.state;const auto& cell=owned.cell;
    if(record.id!=cell.id || row.version!=owned.version)throw std::logic_error("Migrated selection version mismatch.");
    for(unsigned i=0;i<4;++i) {
      if(row.vertices[i]!=cell.v[i].id)throw std::logic_error("Migrated selection vertex mismatch.");
      vertex_links+=vertex_cells[row.vertices[i]].insert(cell.id).second;
    }
    if(!cells.emplace(cell.id,row).second)throw std::logic_error("Duplicate migrated selection row.");
    for(unsigned i=0;i<6;++i) {
      const auto edge=row.edges[i];Point a{},b{};bool has_a=false,has_b=false;
      for(auto node:cell.v){if(node.id==edge[0]){a=node.p;has_a=true;}if(node.id==edge[1]){b=node.p;has_b=true;}}
      if(!has_a||!has_b||!(record.lengths[i]>0))throw std::logic_error("Invalid migrated edge certificate.");
      auto inserted=edges.emplace(edge,EdgeState{EdgeMeasure{a,b,record.lengths[i],identity},0});auto& e=inserted.first->second;
      if(!e.measure.Reusable(a,b,identity)||e.measure.length!=record.lengths[i])throw std::logic_error("Migrated edge certificates disagree.");
      e.physical_users+=row.physical[i];++e.users;
      for(unsigned d=0;d<2;++d)e.forbidden[d]+=bool(row.forbidden[i]&(1u<<d));
    }
    Account(row,true);invalid+=!row.valid;construction_invalid+=!row.construction_valid;
    quality_invalid+=!row.quality_valid;unmeasured_shape+=!row.shape_measured;
  }
  static std::array<RepairFeature,14> RepairKeys(const CellState& row) {
    std::array<RepairFeature,14> keys{};unsigned at=0;
    for(Id vertex:row.vertices)keys[at++]={1,{vertex,0,0}};
    for(const auto& edge:row.edges)keys[at++]={2,{edge[0],edge[1],0}};
    for(unsigned opposite=0;opposite<4;++opposite) {
      Face face{};unsigned k=0;for(unsigned i=0;i<4;++i)if(i!=opposite)face[k++]=row.vertices[i];
      keys[at++]={3,Key(face)};
    }
    return keys;
  }
  void SaveRepairState(CachedRow& record)const {
    const auto found=cell_repairs.find(record.id);if(found==cell_repairs.end())return;
    const auto keys=RepairKeys(record.state);size_t saved=0;
    for(unsigned i=0;i<keys.size();++i) {
      if(std::find(found->second.begin(),found->second.end(),keys[i])==found->second.end())continue;
      const auto& demand=repair_users.at(keys[i]);
      if(!demand.users||demand.epoch>repair_epoch)throw std::logic_error("Invalid phase repair history.");
      record.repair_active|=uint16_t(1u<<i);record.repair_epochs[i]=demand.epoch;
      if(demand.blocked)record.repair_blocked|=uint16_t(1u<<i);
      ++saved;
    }
    if(saved!=found->second.size())throw std::logic_error("Incomplete phase repair history.");
  }
  void RestoreRepairState(const std::vector<CachedRow>& records) {
    if(!cell_repairs.empty()||!repair_users.empty()||!repair_zero.empty())
      throw std::logic_error("Phase repair history must restore into an empty queue.");
    for(const auto& record:records) {
      if((record.repair_active&~uint16_t(0x3fff)) || (record.repair_blocked&~record.repair_active))
        throw std::logic_error("Invalid migrated repair masks.");
      const auto& row=cells.at(record.id);
      const bool needed=track_repairs&&(surface_planning?!row.construction_valid:quality_only?(!row.quality_valid || (geometry_repairs&&row.geometry_invalid) ||
          (size_repairs&&row.debt.size_bad)):!row.valid);
      if(bool(record.repair_active)!=needed)throw std::logic_error("Migration changed required repair support.");
      if(!needed)continue;
      const auto keys=RepairKeys(row);auto& repairs=cell_repairs[record.id];repairs.reserve(keys.size());
      const auto weight=RepairWeight(row);repair_cell_severity.emplace(record.id,weight);
      for(unsigned i=0;i<keys.size();++i) {
        if(!(record.repair_active&(1u<<i)))continue;
        if(record.repair_epochs[i]>repair_epoch)throw std::logic_error("Migrated repair epoch is in the future.");
        repairs.push_back(keys[i]);
        const bool blocked=record.repair_blocked&(1u<<i);
        auto& demand=repair_users.emplace(keys[i],RepairDemand{0,record.repair_epochs[i],blocked}).first->second;
        ++demand.users;
        demand.epoch=std::min(demand.epoch,record.repair_epochs[i]);
        demand.blocked=demand.blocked&&blocked;
        auto& severity=repair_severity[keys[i]];severity+=weight;
        if(!std::isfinite(severity))throw std::logic_error("Nonfinite migrated repair severity.");
      }
      repair_bytes=transfer_memory::Add(repair_bytes,transfer_memory::Bytes(repairs));
    }
    // A merged feature stays unavailable only if every prior contributor rejected its unchanged support.
    for(const auto& row:repair_users) {
      const auto& demand=row.second;
      if(!demand.users)throw std::logic_error("Missing migrated repair history.");
      if(!demand.blocked){repair_queue.insert({demand.epoch,row.first});repair_severity_queue.insert({-repair_severity.at(row.first),row.first});}
    }
  }
  void SwapState(Selection& other) noexcept {
    cells.swap(other.cells);edges.swap(other.edges);queue.swap(other.queue);surface_queue.swap(other.surface_queue);
    geometry_queue.swap(other.geometry_queue);geometry_split_priorities.swap(other.geometry_split_priorities);
    std::swap(geometry_priority_mode,other.geometry_priority_mode);
    construction_frontier.swap(other.construction_frontier);edge_history.swap(other.edge_history);
    vertex_cells.swap(other.vertex_cells);blocked_edges.swap(other.blocked_edges);cell_repairs.swap(other.cell_repairs);
    repair_users.swap(other.repair_users);repair_queue.swap(other.repair_queue);
    repair_cell_severity.swap(other.repair_cell_severity);repair_severity.swap(other.repair_severity);
    repair_severity_queue.swap(other.repair_severity_queue);repair_zero.swap(other.repair_zero);
    std::swap(vertex_links,other.vertex_links);std::swap(blocked_links,other.blocked_links);std::swap(repair_bytes,other.repair_bytes);
    std::swap(invalid,other.invalid);std::swap(construction_invalid,other.construction_invalid);
    std::swap(quality_invalid,other.quality_invalid);std::swap(unmeasured_shape,other.unmeasured_shape);
    std::swap(debt,other.debt);std::swap(progress_consistent,other.progress_consistent);std::swap(census_started,other.census_started);
  }
  void Reset(bool improvement) {
    geometry_split_priorities.clear();geometry_priority_mode=false;
    cells.clear();edges.clear();queue.clear();surface_queue.clear();geometry_queue.clear();construction_frontier.clear();edge_history.clear();vertex_cells.clear();
    cell_repairs.clear();repair_users.clear();repair_queue.clear();repair_cell_severity.clear();
    repair_severity.clear();repair_severity_queue.clear();repair_zero.clear();
    invalid=construction_invalid=quality_invalid=unmeasured_shape=repair_bytes=vertex_links=0;
    debt={};progress_consistent=true;census_started=false;
    track_repairs=repair_event=improvement;prune_collapses=false;
  }
};
struct BlockedEdge {
  Edge edge{}; Feature feature;
  template <class S> void Fields(S& s) { s(edge,feature); }
};
void FieldCounts(EngineStats& stats, const FrozenField& field) {
  const auto& f=field.Statistics();
  stats.field_requests+=f.requests; stats.field_hits+=f.hits; stats.field_misses+=f.misses;
  // Edge-only construction can fail before any point query.
  stats.field_invalid_queries+=f.invalid_queries; stats.field_failures+=f.failures+f.edge_failures; stats.field_evictions+=f.evictions;
  stats.field_compositions+=f.compositions;
  stats.donor_hint_tests+=f.donor_hint_tests;stats.donor_hint_hits+=f.donor_hint_hits;
  stats.field_edges+=f.edge_requests;
  stats.edge_separated+=f.kernel.segment_separated;
  stats.field_build_seconds+=f.build_seconds; stats.field_query_seconds+=f.query_seconds;
  stats.field_cache_seconds+=f.cache_seconds; stats.field_search_seconds+=f.search_seconds;
  stats.field_interpolation_seconds+=f.interpolation_seconds; stats.field_composition_seconds+=f.composition_seconds;
  stats.edge_seconds+=f.edge_seconds; stats.edge_search_seconds+=f.edge_search_seconds;
  stats.edge_trace_seconds+=f.edge_trace_seconds; stats.edge_integral_seconds+=f.edge_integral_seconds;
  stats.edge_geometry_seconds+=f.edge_geometry_seconds; stats.edge_composition_seconds+=f.edge_composition_seconds;
}
struct FieldAccounting {
  EngineStats& stats;
  const FrozenField& field;
  // Keep attempted queries when surrounding metric/topology checks throw.
  ~FieldAccounting() { FieldCounts(stats,field); }
};
struct HeightPolicyRow {
  int marker=0;double height=0,growth=0,thickness=0;
  template<class S>void Fields(S& s){s(marker,height,growth,thickness);}
};
struct OptimizationOperations {
  uint64_t moves=0,insertions=0,collapses=0,swaps=0;
  uint64_t boundary_stars=0,boundary_reused=0,boundary_candidates=0,boundary_validity=0,boundary_shape=0,boundary_edge=0,boundary_geometry=0;
  uint64_t boundary_move_contexts=0,boundary_prepared_trials=0;
  uint64_t boundary_guidance=0,boundary_guidance_faces=0,boundary_guidance_reused_faces=0,boundary_guidance_early=0,boundary_upper=0,boundary_moves=0;long double boundary_debt=0;double boundary_seconds=0;
  uint64_t interior_stars=0,interior_reused=0,interior_candidates=0,interior_validity=0,interior_shape=0,interior_edge=0,interior_geometry=0;
  uint64_t interior_guidance=0,interior_upper=0,interior_moves=0;long double interior_debt=0;double interior_seconds=0;
};
bool OptimizedRepairPatch(const Patch& old,Id first,Id first_node,const RegionMetric& target,
                          Patch& fresh,std::string& reason,size_t& work,bool preserve_vertices,
                          const PlanarReference& geometry,const WallHeights& heights,double surface_tolerance,
                          OptimizationOperations& operations,double maximum_seconds) {
  operations={};
  Owned local;std::map<Face,Id> physical;for(const auto& f:old.surface)physical.emplace(Key(f.v),f.facet);
  for(auto c:old.cells){c.id=local.size();OwnedCell row;row.cell=c;const auto faces=Faces(c);
    for(unsigned k=0;k<4;++k){const auto found=physical.find(Key(faces[k]));if(found!=physical.end())row.physical[k]={true,found->second};}
    local.emplace(c.id,row);}
  auto parameters=geometry.PrivateParameters(old);
  OptimizeOptions options;options.maximum_work=work;options.maximum_seconds=maximum_seconds;options.cache_entries=8*MaximumReplacementCells;
  options.boundary=false;options.smoothing=!preserve_vertices;options.collapses=!preserve_vertices;
  options.geometry=parameters?parameters.get():&geometry;options.wall_heights=heights;options.surface_tolerance=surface_tolerance;
  OptimizeReport report;Id node=first_node,cell=local.size();
  const bool changed=OptimizeMetricMesh(local,target,node,cell,options,report);
  operations.moves=report.moves;operations.insertions=report.shell_insertions+report.neighbourhood_insertions+report.length_insertions;
  operations.collapses=report.collapses+report.boundary_collapses;operations.swaps=report.edge_removals+report.length_removals+report.face_swaps+report.boundary_flips;
  operations.boundary_stars=report.boundary_stars_searched;operations.boundary_reused=report.boundary_stars_reused;operations.boundary_candidates=report.boundary_candidates;
  operations.boundary_validity=report.boundary_rejected_validity;operations.boundary_shape=report.boundary_rejected_shape;operations.boundary_edge=report.boundary_rejected_edge;operations.boundary_geometry=report.boundary_rejected_geometry;
  operations.boundary_guidance=report.boundary_guidance_calls;operations.boundary_upper=report.boundary_upper_queries;operations.boundary_moves=report.boundary_moves;
  operations.boundary_move_contexts=report.boundary_move_contexts;operations.boundary_prepared_trials=report.boundary_prepared_trials;
  operations.boundary_guidance_faces=report.boundary_guidance_faces;operations.boundary_guidance_reused_faces=report.boundary_guidance_reused_faces;operations.boundary_guidance_early=report.boundary_guidance_early_rejections;
  operations.boundary_debt=report.boundary_debt_reduction;operations.boundary_seconds=report.boundary_seconds;
  operations.interior_stars=report.interior_stars_searched;operations.interior_reused=report.interior_stars_reused;operations.interior_candidates=report.interior_candidates;
  operations.interior_validity=report.interior_rejected_validity;operations.interior_shape=report.interior_rejected_shape;operations.interior_edge=report.interior_rejected_edge;operations.interior_geometry=report.interior_rejected_geometry;
  operations.interior_guidance=report.interior_guidance_calls;operations.interior_upper=report.interior_upper_queries;operations.interior_moves=report.interior_moves;
  operations.interior_debt=report.interior_debt_reduction;operations.interior_seconds=report.interior_seconds;
  if(report.trials>work)throw std::logic_error("Native repair optimizer exceeded its work reservation.");
  if(node-first_node>report.trials)throw std::logic_error("Native repair optimizer exceeded its node reservation.");
  work=report.trials;
  if(!changed){reason="Native3D cavity optimizer found no admissible quality/length change ("+report.stop+").";return false;}
  if(local.size()>MaximumReplacementCells){reason="Native3D cavity optimizer exceeds replacement admission.";return false;}
  Patch proposal;proposal.parameters=old.parameters;proposal.coverage=old.coverage;
  for(const auto& p:report.parameters)proposal.parameters.insert_or_assign(p.first,p.second);
  for(const auto& row:local){auto c=row.second.cell;c.id=first+proposal.cells.size();proposal.cells.push_back(c);
    const auto faces=Faces(c);for(unsigned k=0;k<4;++k)if(row.second.physical[k].present)proposal.surface.push_back({faces[k],row.second.physical[k].facet});}
  for(const auto& row:report.coverage.faces)proposal.coverage.faces.insert_or_assign(row.first,row.second);
  for(const auto& row:report.coverage.traces)proposal.coverage.traces.insert_or_assign(row.first,row.second);
  RetainPhysicalCoverage(proposal);
  auto final_parameters=options.geometry->PrivateParameters(proposal);
  if(final_parameters)final_parameters->ExportParameters(proposal);
  std::map<Face,Face> expected;
  for(auto face:Incidence(old.cells).Boundary())if(!physical.count(Key(face)))expected.emplace(Key(face),face);
  for(auto face:proposal.surface){std::rotate(face.v.begin(),std::min_element(face.v.begin(),face.v.end()),face.v.end());expected.emplace(Key(face.v),face.v);}
  std::vector<Face> skin;for(const auto& f:expected)skin.push_back(f.second);
  if(!ValidatePrescribedInterface(old.cells,proposal.cells,skin,reason))return false;
  fresh=std::move(proposal);
  return true;
}
struct RestoreAdmission {
  ShapeAdmission previous = GetShapeAdmission();
  ~RestoreAdmission() { SetShapeAdmission(previous); }
};
struct RestoreBudgetWindow {
  SU2NativeGeometry::AtlasBudget* budget;
  size_t caller, bytes, bits, maximum_work;
  ~RestoreBudgetWindow() {
    if (budget) {
      budget->caller_bytes = caller;
      budget->maximum_bytes = bytes;
      budget->maximum_integer_bits = bits;
      budget->maximum_work = maximum_work;
    }
  }
};
struct GenerationDebt {
  double edges = 0, geometry = 0, maximum = 0;
  bool geometry_complete = false;
};
struct CoarseningCheckpoint {
  Owned cells;
  std::unique_ptr<BoundaryParameterState> parameters;
  std::unique_ptr<Directory> directory;
  std::map<Id, std::set<Id>> blocked;
  std::set<Edge> edges, attempted;
  std::set<Id> changed;
  size_t blocked_links = 0, global_cells = 0, collapses = 0, splits = 0;
  bool valid = false, trial = false;
  size_t Bytes() const {
    return transfer_memory::Add(MapBytes(cells), MapBytes(blocked), MapBytes(edges), MapBytes(attempted),
                                MapBytes(changed), transfer_memory::Mul(blocked_links, sizeof(Id) + 4 * sizeof(void*)),
                                parameters ? parameters->ResidentBytes() : 0,
                                directory ? transfer_memory::Add(sizeof(Directory), directory->ResidentBytes()) : 0);
  }
};
struct RepairProposal {
  Choice choice;
  Dependencies dependencies;
  Imported imported;
  Patch old, fresh;
  Node point;
  MetricDiagnosis certified;
  OptimizationOperations optimization;
  bool chosen = false, approved = false, coordinate_only = false, moved = false, repair_approved = false,
       cavity_inserted = false;
  bool optimization_approved = false, geometric_progress = false, capture = false, capture_selected = false;
  Id first_cell = 0, first_node = 0;
  size_t optimizer_work = 0;
  unsigned ladder = 3;
  std::vector<CellQualityFlag> old_flags, fresh_flags;
  std::string rejection;
};

// Keep setup ownership private to the original translation unit and namespace.
#include "native_engine3d/EngineSetup.cpp"
#include "native_engine3d/EngineControl.cpp"
#include "native_engine3d/EngineCensus.cpp"
#include "native_engine3d/EngineQueues.cpp"
#include "native_engine3d/EngineExchange.cpp"
#include "native_engine3d/EngineCommit.cpp"
#include "native_engine3d/EngineOwnership.cpp"
#include "native_engine3d/EngineRound.cpp"
#include "native_engine3d/EngineSlot.cpp"
#include "native_engine3d/EngineContext.cpp"
#include "native_engine3d/EngineTrial.cpp"
#include "native_engine3d/EngineReports.cpp"

EngineResult Adapt(World& world, const Owned& accepted, const std::vector<DonorCell>& original,
                   const PlanarReference& accepted_geometry, MetricComposition composition, EngineOptions options, MetricChange intent, bool bidirectional=false,
                   BoundaryMetric surface_target={}) {
  EngineSetup setup;
  SetShapeAdmission(ShapeAdmission::ValidityOnly);
  using Phase=EnginePhase;
  ContextValue phase_lifetime(setup.control_prefix.phase, Phase::Construction);
  auto& phase = phase_lifetime.Get();
  auto& timer_session = setup.timer_session.emplace(
      options.timings, "native_engine", world.rank, world.size,
      surface_target ? SU2NativeTiming3D::Phase::Surface : SU2NativeTiming3D::Phase::Construction);
  if (timer_session.Owns())
    options.caller_bytes = transfer_memory::Add(options.caller_bytes, SU2NativeTiming3D::Session::ReservedBytes());
  setup.d9_profile.emplace(options.timings, world.rank);
  auto& wall_counters = setup.wall_counters.emplace(options.timings && bool(surface_target));
  auto& lane_counters = setup.lane_counters.emplace(options.timings);
  ContextValue region_rebuilt_lifetime(setup.control_prefix.region_rebuilt, false);
  auto& region_rebuilt = region_rebuilt_lifetime.Get();
  ContextValue improvement_changed_lifetime(setup.control_prefix.improvement_changed, false);
  auto& improvement_changed = improvement_changed_lifetime.Get();
  ContextValue construction_changed_lifetime(setup.control_prefix.construction_changed, false);
  auto& construction_changed = construction_changed_lifetime.Get();
  ContextValue construction_handoff_progress_lifetime(setup.control_prefix.construction_handoff_progress, false);
  auto& construction_handoff_progress = construction_handoff_progress_lifetime.Get();
  ContextValue construction_generation_changed_lifetime(setup.control_prefix.construction_generation_changed, false);
  auto& construction_generation_changed = construction_generation_changed_lifetime.Get();
  ContextValue metric_cleanup_lifetime(setup.control_prefix.metric_cleanup, false);
  auto& metric_cleanup = metric_cleanup_lifetime.Get();
  ContextValue metric_cleanup_tried_lifetime(setup.control_prefix.metric_cleanup_tried, false);
  auto& metric_cleanup_tried = metric_cleanup_tried_lifetime.Get();
  ContextValue phase_start_round_lifetime(setup.control_prefix.phase_start_round, 0);
  auto& phase_start_round = phase_start_round_lifetime.Get();
  if(options.stage_observer)options.caller_bytes=transfer_memory::Add(options.caller_bytes,options.stage_observer_bytes);
  ContextValue started_lifetime(setup.control_prefix.started, Clock::now());
  const auto& started = started_lifetime.Get();
  ContextValue started_cpu_lifetime(setup.control_prefix.started_cpu, options.timings ? std::clock() : std::clock_t{});
  const auto& started_cpu = started_cpu_lifetime.Get();
  auto& private_parameters = setup.private_parameters.emplace();
  auto& private_geometry = setup.private_geometry.emplace();
  auto& local_atlas_budget = setup.local_atlas_budget.emplace();
  auto& atlas_budget=options.shared_geometry_budget?*options.shared_geometry_budget:local_atlas_budget;
  ContextValue atlas_work_initial_lifetime(setup.control_prefix.atlas_work_initial, atlas_budget.work);
  const auto& atlas_work_initial = atlas_work_initial_lifetime.Get();
  auto& restore_budget = setup.restore_budget.emplace();
  restore_budget.budget = options.shared_geometry_budget;
  restore_budget.caller = atlas_budget.caller_bytes;
  restore_budget.bytes = atlas_budget.maximum_bytes;
  restore_budget.bits = atlas_budget.maximum_integer_bits;
  restore_budget.maximum_work = atlas_budget.maximum_work;
  auto& atlas_geometry = setup.atlas_geometry.emplace();
  auto& target_geometry_lease = setup.target_geometry_lease.emplace();
  ContextValue atlas_scratch_lifetime(setup.control_prefix.atlas_scratch,
                                      std::max(AtlasScratchBytes, options.geometry_workspace_bytes));
  const auto& atlas_scratch = atlas_scratch_lifetime.Get();
  if(!options.shared_geometry_budget && std::isfinite(options.maximum_seconds) && options.maximum_seconds>0)
    atlas_budget.within_time=[started,maximum=options.maximum_seconds] {
      return std::chrono::duration<double>(Clock::now()-started).count()<maximum;
    };
  const SU2NativeGeometry::BoundaryCoverage no_coverage;
  ContextValue parameter_failure_lifetime(setup.control_prefix.parameter_failure);
  auto& parameter_failure = parameter_failure_lifetime.Get();
  ContextValue parameter_bound_lifetime(setup.control_prefix.parameter_bound, 0);
  auto& parameter_bound = parameter_bound_lifetime.Get();
  const unsigned mapped=accepted_geometry.Mapped();
  const auto mapped_low=TimedAllreduce(mapped,CPassiveComm::Op::MIN,world.comm),mapped_high=TimedAllreduce(mapped,CPassiveComm::Op::MAX,world.comm);
  if(mapped_low!=mapped_high)parameter_failure.Set(1,0,"Native3D parameter geometry mode differs across workers.");
  if(mapped)try {
    const auto* parameters=accepted_geometry.Parameters();
    // Stage clones are boundary-only and admitted once, never per transaction. Private overlays are bounded.
    parameter_bound=transfer_memory::Add(options.caller_bytes,accepted_geometry.ResidentBytes(),
        transfer_memory::Mul(parameters->ResidentBytes(),2),atlas_scratch,MapBytes(accepted),transfer_memory::Bytes(original));
    if(parameter_bound==SIZE_MAX || parameter_bound>options.memory_ceiling)throw std::length_error("Native boundary parameter stage exceeds storage admission.");
    private_parameters=std::make_shared<BoundaryParameterState>(*parameters);
    private_geometry=accepted_geometry.WithParameterState(private_parameters);
    options.caller_bytes=transfer_memory::Add(options.caller_bytes,atlas_scratch);
    if(private_parameters->Mobility().identity||!private_parameters->Coverage().faces.empty()||!private_parameters->Coverage().traces.empty()) {
      atlas_budget.caller_bytes=parameter_bound-atlas_scratch;atlas_budget.maximum_bytes=options.memory_ceiling;
      // Half holds the nested planner/reconstruction arithmetic arrays; half holds correspondence records.
      size_t low=0,high=AtlasScratchBytes*8;
      while(low<high){const size_t bits=low+(high-low+1)/2;
        if(transfer_memory::Mul(2,SU2NativeGeometry::CurvedAtlasWorkspaceBytes(bits))<=AtlasScratchBytes/2)low=bits;else high=bits-1;}
      if(!low)throw std::length_error("Native3D atlas integer workspace has no admitted capacity.");atlas_budget.maximum_integer_bits=low;
      atlas_geometry=private_geometry->WithAtlasReservation(atlas_budget);
    }
  }catch(const std::exception& e){parameter_failure.Set(3,0,e.what());}
  if(mapped_high) {
    const auto failure=world.elect(parameter_failure);
    if(failure.any){EngineResult rejected;rejected.reason=failure.message;rejected.stats.stop=EngineStop::Failure;rejected.stats.maximum_work_bytes=parameter_bound;return rejected;}
  }
  const auto& geometry=atlas_geometry?*atlas_geometry:private_geometry?*private_geometry:accepted_geometry;
  EngineContext context(setup, world, accepted, original, geometry, composition, options, intent, bidirectional,
                        surface_target);
  auto& control = context.control;
  if (options.timings)
    PrintAdaptationRequirements(MakeAdaptationRequirements(geometry, bool(composition), options), world.rank, std::cout);
  ContextValue parameter_setup_lifetime(
      control.parameter_setup, options.timings ? std::chrono::duration<double>(Clock::now() - started).count() : 0);
  const auto& parameter_setup = parameter_setup_lifetime.Get();
  const bool curved=!geometry.ExtensionComponents().empty();
  ContextValue standalone_coarsening_lifetime(control.standalone_coarsening, intent == MetricChange::Coarsen);
  const auto& standalone_coarsening = standalone_coarsening_lifetime.Get();
  ContextValue coarsening_lifetime(control.coarsening, standalone_coarsening || bidirectional);
  auto& coarsening = coarsening_lifetime.Get();
  ContextValue repairing_lifetime(control.repairing, false);
  auto& repairing = repairing_lifetime.Get();
  ContextValue construction_kind_lifetime(control.construction_kind,
                                          coarsening ? MetricChange::Coarsen : MetricChange::Refine);
  auto& construction_kind = construction_kind_lifetime.Get();
  ContextValue tracked_bytes_begin_lifetime(control.tracked_bytes_begin, world.bytes_sent);
  const auto& tracked_bytes_begin = tracked_bytes_begin_lifetime.Get();
  ContextValue tracked_calls_begin_lifetime(control.tracked_calls_begin, world.collective_calls);
  const auto& tracked_calls_begin = tracked_calls_begin_lifetime.Get();
  ContextValue tracked_seconds_begin_lifetime(control.tracked_seconds_begin, world.collective_seconds);
  const auto& tracked_seconds_begin = tracked_seconds_begin_lifetime.Get();
  ContextValue election_calls_begin_lifetime(control.election_calls_begin, world.election_collective_calls);
  const auto& election_calls_begin = election_calls_begin_lifetime.Get();
  ContextValue election_seconds_begin_lifetime(control.election_seconds_begin, world.election_collective_seconds);
  const auto& election_seconds_begin = election_seconds_begin_lifetime.Get();
  ContextValue geometry_authority_lifetime(control.geometry_authority,
                                           geometry.Parameters() ? &geometry.Parameters()->Geometry() : nullptr);
  auto& geometry_authority = geometry_authority_lifetime.Get();
  ContextValue geometry_begin_lifetime(control.geometry_begin,
                                       geometry_authority ? geometry_authority->GeometryStatsSnapshot()
                                                          : SU2NativeGeometry::MappedFacetReference::GeometryStats{});
  const auto& geometry_begin = geometry_begin_lifetime.Get();
  ContextValue result_lifetime(control.result);
  auto& result = result_lifetime.Get();
  auto& stats=result.stats;stats.bidirectional=bidirectional;stats.parameter_setup_seconds=parameter_setup;stats.initialization_seconds=parameter_setup;stats.maximum_work_bytes=parameter_bound;
  ContextValue working_lifetime(context.ownership.working);
  auto& working = working_lifetime.Get();
  ContextValue selection_lifetime(context.census.selection, coarsening, repairing, geometry, stats,
                                  options.timings, options.surface_tolerance, options.wall_heights,
                                  bidirectional, bool(surface_target), &wall_counters);
  auto& selection = selection_lifetime.Get();
  selection.split_lanes=bidirectional;
  ContextValue construction_claims_lifetime(context.exchange.construction_claims, bidirectional);
  auto& construction_claims = construction_claims_lifetime.Get();
  ContextValue edge_progress_lifetime(context.census.edge_progress);
  auto& edge_progress = edge_progress_lifetime.Get();
  ContextValue edge_census_round_lifetime(context.census.edge_census_round, UINT64_MAX);
  auto& edge_census_round = edge_census_round_lifetime.Get();

  ContextValue generation_window_lifetime(control.generation_window);
  auto& generation_window = generation_window_lifetime.Get();
  ContextValue generation_window_count_lifetime(control.generation_window_count, 0);
  auto& generation_window_count = generation_window_count_lifetime.Get();
  ContextValue retired_edges_lifetime(context.census.retired_edges);
  auto& retired_edges = retired_edges_lifetime.Get();
  ContextValue campaign_edges_lifetime(context.census.campaign_edges);
  auto& campaign_edges = campaign_edges_lifetime.Get();
  ContextValue inactive_blocked_edges_lifetime(context.queues.inactive_blocked_edges);
  auto& inactive_blocked_edges = inactive_blocked_edges_lifetime.Get();
  ContextValue inactive_blocked_links_lifetime(context.queues.inactive_blocked_links, 0);
  auto& inactive_blocked_links = inactive_blocked_links_lifetime.Get();
  ContextValue length_blocks_dirty_lifetime(context.queues.length_blocks_dirty, std::array<bool, 2>{{false, false}});
  auto& length_blocks_dirty = length_blocks_dirty_lifetime.Get();
  ContextValue field_identity_lifetime(context.census.field_identity);
  auto& field_identity = field_identity_lifetime.Get();
  // Joint split feasibility depends on neighboring vertex stars, even when the edge itself is unchanged.
  selection.track_splits=bool(composition) || curved;
  // Every adaptation can enter quality improvement; rejected repair support must be invalidated
  // even for flat, uncomposed refinement/repair events.
  ContextValue directory_lifetime(context.exchange.directory,
                                  std::make_unique<Directory>(world, true, geometry.Parameters()));
  auto& directory = directory_lifetime.Get();
  ContextValue source_lifetime(context.exchange.source, world, working, options.timings);
  auto& source = source_lifetime.Get();
  ContextValue checkpoint_lifetime(control.checkpoint);
  auto& checkpoint = checkpoint_lifetime.Get();
  ContextValue retired_directory_lifetime(context.exchange.retired_directory);
  auto& retired_directory = retired_directory_lifetime.Get();
  ContextValue accepted_bytes_lifetime(control.accepted_bytes, MapBytes(accepted));
  auto& accepted_bytes = accepted_bytes_lifetime.Get();
  ContextValue initial_lifetime(context.census.initial);
  auto& initial = initial_lifetime.Get();
  ContextValue eligible_extensions_lifetime(context.census.eligible_extensions);
  auto& eligible_extensions = eligible_extensions_lifetime.Get();
  ContextValue seed_slot_lifetime(context.census.seed_slot, 0);
  auto& seed_slot = seed_slot_lifetime.Get();
  auto scope_census_complete=[&]() {
    if(!surface_target)return selection.Progress(working.size()).census_complete;
    if(!selection.progress_consistent||!selection.census_started)return false;
    const auto count=selection.SurfaceCensus(working);return count[0]==count[1];
  };
  auto refresh_surface_census=[&]() {
    if(!surface_target)return;
    const auto count=selection.SurfaceCensus(working);
    stats.surface_demand_required_cells=count[0];
    stats.surface_demand_measured_cells=selection.progress_consistent?count[1]:0;
    stats.surface_demand_census_complete=selection.progress_consistent&&selection.census_started&&count[0]==count[1];
    stats.surface_demand_geometry_complete=stats.surface_demand_census_complete&&count[0]==count[2];
  };
  ContextValue private_repair_lifetime(context.exchange.private_repair, false);
  auto& private_repair = private_repair_lifetime.Get();
  ContextValue private_optimizer_allowance_lifetime(control.private_optimizer_allowance, 0);
  auto& private_optimizer_allowance = private_optimizer_allowance_lifetime.Get();
  ContextValue batch_bytes_lifetime(control.batch_bytes, 0);
  auto& batch_bytes = batch_bytes_lifetime.Get();
  ContextValue diagnostic_bytes_lifetime(control.diagnostic_bytes,
                                         transfer_memory::Add(16384, transfer_memory::Mul(world.size, 4096)));
  const auto& diagnostic_bytes = diagnostic_bytes_lifetime.Get();
  ContextValue fixed_metric_points_lifetime(control.fixed_metric_points);
  auto& fixed_metric_points = fixed_metric_points_lifetime.Get();
  ContextValue fixed_metric_cells_lifetime(control.fixed_metric_cells);
  auto& fixed_metric_cells = fixed_metric_cells_lifetime.Get();fixed_metric_cells.fill(UINT64_MAX);
  ContextValue fixed_metric_initialized_lifetime(control.fixed_metric_initialized, false);
  auto& fixed_metric_initialized = fixed_metric_initialized_lifetime.Get();
  ContextValue fixed_metric_available_lifetime(control.fixed_metric_available, false);
  auto& fixed_metric_available = fixed_metric_available_lifetime.Get();
  ContextValue batch_changed_lifetime(context.commit.batch_changed);
  auto& batch_changed = batch_changed_lifetime.Get();
  ContextValue batch_touched_lifetime(context.commit.batch_touched);
  auto& batch_touched = batch_touched_lifetime.Get();
  ContextValue batch_supports_lifetime(context.commit.batch_supports);
  auto& batch_supports = batch_supports_lifetime.Get();
  auto coalesce=[&](std::vector<Choice>& choices) {
    const bool collapse=coarsening && !curved && !composition;
    const bool concurrent_refine=(repairing || (!coarsening && (curved || composition || selection.split_lanes)) || (bidirectional && coarsening)) && options.candidate_batch>1;
    if(world.size==1 || (!repairing && !collapse && !concurrent_refine))return true;
    const auto feature=[&](const Choice& c){return repairing?c.feature:Feature{{c.edge[0],c.edge[1],0},2};};
    // Replicated vertex/edge/face demands are one proposal; directed collapses retain distinct endpoints.
    const auto scratch=transfer_memory::Mul(transfer_memory::Mul(world.size,MaximumCandidateBatch),
        8*sizeof(ProposalKey)+8*sizeof(void*));
    if(!context.exchange.Admit(context, scratch))return false;
    CLocalFailure failure;std::vector<std::vector<ProposalKey>> to;
    try {
      if(choices.size()>MaximumCandidateBatch)throw std::logic_error("Native edge proposal table exceeds its bound.");
      std::vector<ProposalKey> local;
      for(size_t i=0;i<choices.size();++i)local.push_back({feature(choices[i]),world.rank,i,choices[i].geometric,
          double(choices[i].priority_score),choices[i].priority_cell,choices[i].repair_epoch,choices[i].fair_repair});
      to.assign(world.size,local);
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;bool admitted=false;
    auto all=world.exchange(to,&admitted,options.memory_ceiling,
        transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),scratch));
    if(!admitted){result.reason="Native edge proposal exchange exceeds storage.";return false;}
    try {
      if(all.size()>std::numeric_limits<unsigned>::max())throw std::logic_error("Native edge proposal ordering exceeds its bound.");
      for(const auto& key:all)
        if(key.rank<0 || key.rank>=world.size || key.slot>=MaximumCandidateBatch || key.feature.count<1 || key.feature.count>3 || !std::isfinite(key.score))
          throw std::logic_error("Invalid native edge proposal identity/priority.");
      for(const auto& key:all)for(unsigned i=0;i<key.feature.count;++i)for(unsigned j=i+1;j<key.feature.count;++j)
        if(key.feature.vertices[i]==key.feature.vertices[j])throw std::logic_error("Repeated native proposal feature vertex.");
      // Demand priority precedes ownership; this score orders search, never certifies a mesh.
      std::sort(all.begin(),all.end(),[&](const auto& a,const auto& b) {
        if(repairing) {
          if(a.fair_repair!=b.fair_repair)return a.fair_repair;
          if(a.fair_repair && a.epoch!=b.epoch)return a.epoch<b.epoch;
          if(a.score!=b.score)return a.score<b.score;
          if(a.epoch!=b.epoch)return a.epoch<b.epoch;
        }
        return std::make_tuple(!a.geometric,a.score,a.cell,a.feature.count,a.feature.vertices,a.rank,a.slot)<
               std::make_tuple(!b.geometric,b.score,b.cell,b.feature.count,b.feature.vertices,b.rank,b.slot);
      });
      std::vector<Choice> unique;
      for(size_t i=0;i<choices.size();++i) {
        const auto owner=std::find_if(all.begin(),all.end(),[&](const auto& key){const auto f=feature(choices[i]);return key.feature.count==f.count && key.feature.vertices==f.vertices;});
        if(owner==all.end())throw std::logic_error("Missing native edge proposal.");
        if(owner->rank!=world.rank || owner->slot!=i)++stats.proposal_duplicates;
        else {
          if(repairing && !concurrent_refine && owner!=all.begin())continue;
          if(concurrent_refine || repairing)choices[i].reservation_priority=unsigned(owner-all.begin());
          if(repairing)choices[i].repair_epoch=owner->epoch;
          unique.push_back(choices[i]);
        }
      }
      choices.swap(unique);
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    return context.exchange.Vote(context, failure);
  };
  auto service_frontier=[&](Feature feature,bool active,bool accepted,
                            const std::array<RepairReceipt,MaximumCandidateBatch>* extra=nullptr,size_t count=0,unsigned disposition=4) {
    // Only the bounded elected frontier is replicated, never the resident demand queues.
    const bool certify_support=coarsening && !repairing && checkpoint.valid;
    const auto scratch=transfer_memory::Add(transfer_memory::Mul(world.size,sizeof(std::vector<RepairReceipt>)),
        transfer_memory::Mul(transfer_memory::Mul(world.size,MaximumCandidateBatch+1),4*sizeof(RepairReceipt)));
    if(!context.exchange.Admit(context, transfer_memory::Add(scratch,
        certify_support ? transfer_memory::Mul(transfer_memory::Mul(world.size,MaximumCandidateBatch+1),sizeof(Edge)+4*sizeof(void*)) : 0)))return false;
    CLocalFailure failure;std::vector<std::vector<RepairReceipt>> to;
    try {
      if(count>MaximumCandidateBatch || (count && !extra))throw std::logic_error("Native frontier receipt list exceeds its bound.");
      to.resize(world.size);
      for(auto& bucket:to) {
        if(active)bucket.push_back({feature,accepted,disposition});
        for(size_t i=0;i<count;++i)bucket.push_back(extra->at(i));
      }
    }
    catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    bool admitted=false;
    auto receipts=world.exchange(to,&admitted,options.memory_ceiling,
        transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),scratch));
    if(!admitted){result.reason="Native repair service receipts exceed storage budget.";return false;}
    try {
      if(receipts.size()>transfer_memory::Mul(world.size,MaximumCandidateBatch+1))throw std::logic_error("Native repair service receipts exceed frontier bound.");
      if(certify_support)std::sort(receipts.begin(),receipts.end(),[](const auto& a,const auto& b) {
        return std::tie(a.feature.count,a.feature.vertices,a.accepted)<std::tie(b.feature.count,b.feature.vertices,b.accepted);
      });
      for(const auto& receipt:receipts)
        if(receipt.feature.count<1 || receipt.feature.count>3 || (!repairing && receipt.feature.count!=2))
          throw std::logic_error("Invalid native repair service receipt.");
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(certify_support && !context.exchange.Vote(context, failure))return false;
    for(const auto& receipt:receipts) {
      if(!certify_support && failure.Failed())break;
      const bool checkpoint_support=certify_support &&
          !world.maximum(checkpoint.changed.count(receipt.feature.vertices[1])!=0);
      try {
        if(checkpoint_support) {
          const Edge edge{receipt.feature.vertices[0],receipt.feature.vertices[1]};auto key=edge;std::sort(key.begin(),key.end());
          if(checkpoint.edges.count(key))checkpoint.attempted.insert(edge);
        }
        if(repairing)selection.Service(receipt.feature,receipt.accepted);
        else {
          if(receipt.feature.count!=2)throw std::logic_error("Invalid native construction service receipt.");
          selection.Note({receipt.feature.vertices[0],receipt.feature.vertices[1]},receipt.accepted?5:receipt.disposition);
          selection.ServiceEdge({receipt.feature.vertices[0],receipt.feature.vertices[1]});
        }
      }catch(const std::exception& e){failure.Set(2,0,e.what());}
      // Every rank reaches the next receipt support vote even after a local allocation failure.
      if(certify_support && !context.exchange.Vote(context, failure))return false;
    }
    return certify_support || context.exchange.Vote(context, failure);
  };
  ContextValue last_rejection_lifetime(control.last_rejection);
  auto& last_rejection = last_rejection_lifetime.Get();
  ContextValue diagnostic_rejections_lifetime(control.diagnostic_rejections);
  auto& diagnostic_rejections = diagnostic_rejections_lifetime.Get();
  ContextValue diagnostic_sequence_lifetime(control.diagnostic_sequence, 0);
  auto& diagnostic_sequence = diagnostic_sequence_lifetime.Get();
  constexpr size_t diagnostic_rejection_limit=64;
  if(options.stage_observer && options.stage_observer_bytes>=diagnostic_rejection_limit*sizeof(RejectionDiagnostic)+(size_t(64)<<10))
    diagnostic_rejections.reserve(diagnostic_rejection_limit);
  ContextValue progress_at_window_lifetime(control.progress_at_window, 0);
  auto& progress_at_window = progress_at_window_lifetime.Get();
  ContextValue attempted_at_window_lifetime(control.attempted_at_window, 0);
  auto& attempted_at_window = attempted_at_window_lifetime.Get();
  ContextValue deferred_at_window_lifetime(control.deferred_at_window, 0);
  auto& deferred_at_window = deferred_at_window_lifetime.Get();
  ContextValue observe_rejections_lifetime(
      control.observe_rejections, world.maximum(bool(options.rejected_trial) || bool(options.transaction_observer)));
  const auto& observe_rejections = observe_rejections_lifetime.Get();
  ContextValue observe_state_lifetime(control.observe_state, world.maximum(bool(options.rejected_state)));
  const auto& observe_state = observe_state_lifetime.Get();
  ContextValue observe_stage_lifetime(control.observe_stage, world.maximum(bool(options.stage_observer)));
  const auto& observe_stage = observe_stage_lifetime.Get();
  ContextValue stage_storage_admitted_lifetime(control.stage_storage_admitted, false);
  auto& stage_storage_admitted = stage_storage_admitted_lifetime.Get();
  ContextValue stage_observer_failed_lifetime(control.stage_observer_failed, false);
  auto& stage_observer_failed = stage_observer_failed_lifetime.Get();
  ContextValue construction_entry_reported_lifetime(control.construction_entry_reported, false);
  auto& construction_entry_reported = construction_entry_reported_lifetime.Get();
  auto generation_census=[&]() {
    const auto extra=transfer_memory::Mul(selection.edges.size(),sizeof(EdgeProgressSample)+sizeof(Selection::History)+sizeof(Edge)+4*sizeof(void*));
    if(!context.exchange.Admit(context, extra))return false;
    CLocalFailure failure;std::vector<EdgeProgressSample> samples;
    try {
      selection.RefreshHistory(false);samples.reserve(selection.edges.size());
      for(const auto& row:selection.edges) {
        if(surface_target&&!row.second.physical_users)continue;
        const auto h=selection.edge_history.find(row.first);const auto length=row.second.measure.length;
        double value=double(length);if(value<length)value=std::nextafter(value,INFINITY);
        samples.push_back({row.first,value,row.second.physical_users!=0,h==selection.edge_history.end()?0:h->second.age,
            h==selection.edge_history.end()?0:h->second.disposition,h==selection.edge_history.end()?0:h->second.round});
      }
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    if(!MeasureGenerationProgress(world,samples,edge_progress,result.reason,options.memory_ceiling,
        transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),transfer_memory::Bytes(edge_progress.top))))return false;
    stats.unique_long_surface=edge_progress.long_surface;stats.unique_long_interior=edge_progress.long_interior;
    stats.unique_edge_debt=edge_progress.hinge_squared;stats.maximum_edge=edge_progress.max_length;stats.edge_histogram=edge_progress.histogram;
    edge_census_round=stats.rounds;
    return true;
  };
  auto generation_debt=[&]() {
    GenerationDebt d;d.edges=edge_progress.hinge_squared;d.maximum=edge_progress.max_length;
    const auto p=selection.Progress(working.size());
    d.geometry=TimedAllreduce(double(p.geometry_excess_squared),CPassiveComm::Op::SUM,world.comm);
    bool geometry_complete=p.geometry_complete;
    if(surface_target) {
      const auto count=selection.SurfaceCensus(working);
      geometry_complete=selection.progress_consistent&&selection.census_started&&count[0]==count[1]&&count[0]==count[2];
    }
    d.geometry_complete=!world.maximum(!geometry_complete);return d;
  };
  ContextValue previous_quality_lifetime(control.previous_quality);
  auto& previous_quality = previous_quality_lifetime.Get();
  ContextValue previous_quality_census_lifetime(control.previous_quality_census);
  auto& previous_quality_census = previous_quality_census_lifetime.Get();
  ContextValue previous_quality_elapsed_lifetime(control.previous_quality_elapsed, 0);
  auto& previous_quality_elapsed = previous_quality_elapsed_lifetime.Get();
  ContextValue previous_quality_collective_lifetime(control.previous_quality_collective, 0);
  auto& previous_quality_collective = previous_quality_collective_lifetime.Get();
  ContextValue quality_census_serial_lifetime(control.quality_census_serial, 0);
  auto& quality_census_serial = quality_census_serial_lifetime.Get();
  ContextValue previous_quality_construction_lifetime(control.previous_quality_construction, 0);
  auto& previous_quality_construction = previous_quality_construction_lifetime.Get();
  ContextValue previous_quality_ownership_lifetime(control.previous_quality_ownership, 0);
  auto& previous_quality_ownership = previous_quality_ownership_lifetime.Get();
  ContextValue quality_census_started_lifetime(control.quality_census_started, false);
  auto& quality_census_started = quality_census_started_lifetime.Get();
  auto emit_quality_census=[&](const char* stage,const StageProgress& p) {
    const auto began=Clock::now();
    const double elapsed=std::chrono::duration<double>(began-started).count();
    const double tracked_collective=world.collective_seconds+world.election_collective_seconds;
    const uint64_t construction_edits=stats.length_splits+stats.length_collapses;
    if(!quality_census_started) {
      previous_quality=stats.quality;previous_quality_census=p;previous_quality_elapsed=elapsed;
      previous_quality_collective=tracked_collective;previous_quality_construction=construction_edits;
      previous_quality_ownership=stats.ownership_changes;quality_census_started=true;
    }
    std::array<uint64_t,2> q_location{},j_location{};
    std::array<uint64_t,3> q_features{},j_features{};
    std::array<uint64_t,6> q_hist{},j_hist{},geometry_hist{};
    std::array<uint64_t,8> geometry_types{};
    uint64_t bad_total=0,bad_short09=0,bad_short05=0,stuck_shape=0,stuck_required=0,missing_features=0,blocked_features=0;
    auto miss_bin=[](long double value){return !std::isfinite(value)?5u:value<.01L?0u:value<.1L?1u:value<.25L?2u:value<.5L?3u:4u;};
    for(const auto& item:selection.cells) {
      const auto& row=item.second;const auto& d=row.debt;
      const bool bad=d.q_bad||d.j_bad;
      const unsigned feature=row.feature_known?unsigned(row.near_feature):2u;
      if(d.q_bad){++q_location[row.surface];++q_features[feature];++q_hist[miss_bin(std::sqrt(d.q))];}
      if(d.j_bad){++j_location[row.surface];++j_features[feature];++j_hist[miss_bin(std::sqrt(d.j))];}
      if(bad) {
        ++bad_total;bool short09=false,short05=false;
        for(const auto& edge:row.edges) {
          const auto length=selection.edges.at(edge).measure.length;short09=short09||length<.9L;short05=short05||length<.5L;
        }
        bad_short09+=short09;bad_short05+=short05;
      }
      if(row.geometry_invalid) {
        ++geometry_hist.at(row.geometry_excess_bin);
        if(!row.geometry_types)++geometry_types[7];
        for(unsigned type=0;type<7;++type)if(row.geometry_types&(1u<<type))++geometry_types[type];
      }
      const auto repairs=selection.cell_repairs.find(item.first);
      if(repairs==selection.cell_repairs.end()||repairs->second.empty()) {missing_features+=bad;continue;}
      bool blocked=true;
      for(const auto& key:repairs->second) {
        const auto demand=selection.repair_users.find(key);
        if(demand==selection.repair_users.end()||!demand->second.users){missing_features+=bad;blocked=false;break;}
        if(!demand->second.blocked){blocked=false;break;}
      }
      stuck_required+=blocked;stuck_shape+=blocked&&bad;
    }
    for(const auto& feature:selection.repair_users)blocked_features+=feature.second.users&&feature.second.blocked;
    stats.quality.diagnostic_seconds+=std::chrono::duration<double>(Clock::now()-began).count();
    const auto& q=stats.quality;const auto& old=previous_quality;
    const double seconds=elapsed-previous_quality_elapsed;
    if(options.timings) {
      std::cout<<std::setprecision(17)<<"NATIVE3D_QUALITY rank="<<world.rank<<" stage="<<stage<<" census="<<quality_census_serial
          <<" complete=1 round="<<stats.rounds<<" elapsed="<<elapsed<<" window_seconds="<<seconds
          <<" busy_seconds="<<q.busy_seconds-old.busy_seconds<<" join_call_seconds="<<q.join_wait_seconds-old.join_wait_seconds
          <<" private_work_used="<<q.private_work_used-old.private_work_used
          <<" tracked_collective_call_seconds="<<tracked_collective-previous_quality_collective
          <<" diagnostic_seconds="<<q.diagnostic_seconds-old.diagnostic_seconds
          <<" commits="<<q.commits-old.commits<<" commits_total="<<q.commits
          <<" private_tracked_collectives="<<q.private_tracked_collectives-old.private_tracked_collectives
          <<" owned_q_removed="<<int64_t(previous_quality_census.q_bad_cells)-int64_t(p.q_bad_cells)
          <<" owned_j_removed="<<int64_t(previous_quality_census.j_bad_cells)-int64_t(p.j_bad_cells)
          <<" owned_debt_removed="<<double(previous_quality_census.q_hinge_squared+previous_quality_census.j_hinge_squared-p.q_hinge_squared-p.j_hinge_squared)
          <<" q_removed="<<q.q_removed-old.q_removed<<" q_created="<<q.q_created-old.q_created
          <<" j_removed="<<q.j_removed-old.j_removed<<" j_created="<<q.j_created-old.j_created
          <<" q_retired="<<q.q_retired-old.q_retired<<" q_introduced="<<q.q_introduced-old.q_introduced
          <<" j_retired="<<q.j_retired-old.j_retired<<" j_introduced="<<q.j_introduced-old.j_introduced
          <<" unmeasured_churn="<<q.unmeasured_churn-old.unmeasured_churn
          <<" construction_edits="<<construction_edits-previous_quality_construction
          <<" ownership_changes="<<stats.ownership_changes-previous_quality_ownership
          <<" queue="<<selection.repair_queue.size()<<" blocked_features="<<blocked_features
          <<" stuck_shape="<<stuck_shape<<" stuck_required="<<stuck_required<<" missing_features="<<missing_features<<'\n';
      auto histogram=[&](const auto& values){for(size_t i=0;i<values.size();++i){if(i)std::cout<<',';std::cout<<values[i];}};
      std::cout<<"NATIVE3D_QUALITY_LOCATION rank="<<world.rank<<" census="<<quality_census_serial
          <<" q_surface="<<q_location[1]<<" q_interior="<<q_location[0]
          <<" j_surface="<<j_location[1]<<" j_interior="<<j_location[0]
          <<" q_feature="<<q_features[1]<<" q_no_feature="<<q_features[0]<<" q_feature_unknown="<<q_features[2]
          <<" j_feature="<<j_features[1]<<" j_no_feature="<<j_features[0]<<" j_feature_unknown="<<j_features[2]
          <<" bad_union="<<bad_total<<" short09="<<bad_short09<<" short05="<<bad_short05
          <<" short09_share="<<(bad_total?double(bad_short09)/bad_total:0.)<<" short05_share="<<(bad_total?double(bad_short05)/bad_total:0.)
          <<" q_miss_hist=";histogram(q_hist);std::cout<<" j_miss_hist=";histogram(j_hist);
      std::cout<<" geometry_excess_hist=";histogram(geometry_hist);std::cout<<" geometry_authority_types=";histogram(geometry_types);std::cout<<'\n';
      for(unsigned kind=0;kind<3;++kind) {
        const auto& now=q.ladder[kind];const auto& prior=old.ladder[kind];
        std::cout<<"NATIVE3D_QUALITY_LADDER rank="<<world.rank<<" census="<<quality_census_serial<<" kind="<<kind
            <<" trials="<<now.trials-prior.trials<<" certified="<<now.certified-prior.certified<<" commits="<<now.published-prior.published
            <<" optimizer_work="<<now.work-prior.work<<" seconds="<<now.seconds-prior.seconds
            <<" debt_removed="<<double(now.debt_removed-prior.debt_removed)<<" q_removed="<<now.q_removed-prior.q_removed
            <<" j_removed="<<now.j_removed-prior.j_removed<<" rejected=";
        for(size_t reason=0;reason<now.rejected.size();++reason){if(reason)std::cout<<',';std::cout<<now.rejected[reason]-prior.rejected[reason];}
        std::cout<<'\n';
      }
    }
    previous_quality=stats.quality;previous_quality_census=p;previous_quality_elapsed=elapsed;
    previous_quality_collective=tracked_collective;previous_quality_construction=construction_edits;
    previous_quality_ownership=stats.ownership_changes;++quality_census_serial;
  };
  auto observe_progress=[&](const char* stage) {
    stats.job_peak_rss_lower = transfer_memory::Add(JobPeakRSS3D(world.comm), options.idle_peak_rss_bytes);
    CLocalFailure memory_failure;
    if (options.job_memory_limit && stats.job_peak_rss_lower > options.job_memory_limit)
      memory_failure.Set(3, 0, "Native3D whole-job process peak RSS exceeds memory budget.");
    const auto memory_vote = world.elect(memory_failure);
    if (memory_vote.any) {
      result.valid = result.surface_prepared = false;
      stats.stop = EngineStop::MemoryBudget;
      result.reason = memory_vote.message;
      return false;
    }
    if(options.timings && (std::strcmp(stage, "length_collapse_exit") == 0 ||
                            std::strcmp(stage, "construction_entry") == 0 || std::strcmp(stage, "exit") == 0))
      SU2NativeTiming3D::Session::Checkpoint(stage);
    if(surface_target) {
      CLocalFailure failure;
      try{refresh_surface_census();}catch(const std::exception& e){failure.Set(2,0,e.what());}
      const auto elected=world.elect(failure);
      if(elected.any){result.valid=result.surface_prepared=false;result.reason=elected.message;return false;}
    }
    if(phase==Phase::Improvement) {
      SU2NativeTiming3D::Scope progress_timer(SU2NativeTiming3D::Operation::Census);
      const auto census=selection.Progress(working.size());
      const bool complete=!world.maximum(!census.census_complete||!census.shape_complete||!census.geometry_complete);
      if(complete){EngineReports::EmitFixedMetricDrift(context, stage);emit_quality_census(stage,census);}
    }
    if(options.timings && (std::string(stage)!="window" || phase==Phase::Improvement)) {
      SU2NativeTiming3D::Scope output_scope(SU2NativeTiming3D::Operation::Output);
      const auto p=selection.Progress(working.size());const auto* state=geometry.Parameters();
      const auto cache=geometry_authority?geometry_authority->GeometryStatsSnapshot():SU2NativeGeometry::MappedFacetReference::GeometryStats{};
      const auto authority=geometry_authority?geometry_authority->ResidentBytes():0;
      std::cout<<"NATIVE3D_STORAGE rank="<<world.rank<<" stage="<<stage
          <<" authority_plus_memo_bytes="<<(authority>=cache.prepared_limit?authority-cache.prepared_limit:authority)
          <<" prepared_reserved_bytes="<<cache.prepared_limit<<" facet_live_bytes="<<cache.facet_bytes<<" scope_live_bytes="<<cache.scope_bytes
          <<" private_cells_bytes="<<MapBytes(working)<<" selection_bytes="<<selection.Bytes()<<" directory_bytes="<<directory->ResidentBytes()
          <<" metric_source_bytes="<<source.ResidentBytes()<<" parameter_bytes="<<(private_parameters?private_parameters->ResidentBytes():0)
          <<" caller_reservation_bytes="<<options.caller_bytes<<" native_peak_bytes="<<stats.maximum_work_bytes<<'\n';
      size_t face_pieces=0,trace_pieces=0,limbs=0;
      auto ratio=[&](const SU2NativeGeometry::ExactRatio& r){limbs=std::max({limbs,r.numerator.size(),r.denominator.size()});};
      auto bary=[&](const SU2NativeGeometry::ExactBary& b){ratio(b.u);ratio(b.v);};
      if(state) {
        for(const auto& row:state->Coverage().faces)for(const auto& piece:row.second.pieces){
          ++face_pieces;for(const auto& b:piece.reference)bary(b);for(const auto& b:piece.active)bary(b);}
        for(const auto& row:state->Coverage().traces)for(const auto& piece:row.second.pieces){
          ++trace_pieces;bary(piece.first);bary(piece.last);ratio(piece.end);}
      }
      const auto g=geometry_authority?geometry_authority->GeometryStatsSnapshot():SU2NativeGeometry::MappedFacetReference::GeometryStats{};
      std::cout<<std::setprecision(17)<<"NATIVE3D_STAGE rank="<<world.rank<<" stage="<<stage
          <<" job_peak_rss_lower="<<stats.job_peak_rss_lower
          <<" phase="<<(phase==Phase::Construction?"construction":"improvement")<<" cells="<<p.owned_cells
          <<" measured="<<p.measured_cells<<" cache_consistent="<<p.cache_consistent
          <<" census_complete="<<p.census_complete<<" shape_complete="<<p.shape_complete
          <<" geometry_complete="<<p.geometry_complete<<" q_measured="<<p.q_measured_cells<<" j_measured="<<p.j_measured_cells
          <<" q_bad="<<p.q_bad_cells<<" j_bad="<<p.j_bad_cells<<" size_bad="<<p.size_bad_cells
          <<" geometry_bad="<<p.geometry_bad_cells<<" q_debt="<<p.q_hinge_squared<<" j_debt="<<p.j_hinge_squared
          <<" size_debt="<<p.size_hinge_squared<<" geometry_debt="<<p.geometry_excess_squared
          <<" distinct_facets="<<g.distinct_facets<<" distinct_scope_keys="<<g.distinct_scope_keys
          <<" prepared_facet_builds="<<g.prepared_facet_builds<<" prepared_facet_mean_bytes="<<g.prepared_facet_mean_bytes
          <<" associations="<<(state?state->Records().size():0)<<" working_faces="<<(state?state->Surface().size():0)
          <<" face_pieces="<<face_pieces<<" trace_pieces="<<trace_pieces<<" maximum_ratio_limbs="<<limbs
          <<" atlas_work="<<atlas_budget.work<<" atlas_bytes="<<atlas_budget.peak_bytes<<" global_work="<<stats.global_work
          <<" rounds="<<stats.rounds<<" batch_rounds="<<stats.batch_rounds
          <<" collapse_corrections="<<stats.collapse_corrections<<" collapse_correction_cells="<<stats.collapse_correction_cells
          <<" collapse_correction_work="<<stats.collapse_correction_work<<" collapse_correction_seconds="<<stats.collapse_correction_seconds
          <<" batch_candidates="<<stats.batch_candidates<<" batch_reserved="<<stats.batch_reserved
          <<" quality_progress="<<stats.quality_progress<<" accepted="<<stats.accepted
          <<" updated_cells="<<stats.updated_cells<<" update_seconds="<<stats.update_seconds
          <<" surface_measurement_skipped="<<stats.surface_measurement_skipped
          <<" surface_required_handoffs="<<stats.surface_required_handoffs
          <<" surface_demand_required="<<stats.surface_demand_required_cells<<" surface_demand_measured="<<stats.surface_demand_measured_cells
          <<" surface_demand_complete="<<stats.surface_demand_census_complete<<" surface_geometry_complete="<<stats.surface_demand_geometry_complete
          <<" seed_cell_classes="<<stats.seed_cell_classes[0]<<','<<stats.seed_cell_classes[1]<<','<<stats.seed_cell_classes[2]
          <<" updated_cell_classes="<<stats.updated_cell_classes[0]<<','<<stats.updated_cell_classes[1]<<','<<stats.updated_cell_classes[2]
          <<" geometry_trials="<<stats.geometry_trials<<" geometry_rejected="<<stats.geometry_rejected
          <<" guidance_trials="<<stats.geometry_guidance_trials<<" guidance_rejected="<<stats.geometry_guidance_rejected
          <<" guidance_faces="<<stats.geometry_guidance_faces<<" guidance_early_rejected="<<stats.geometry_guidance_early_rejections
          <<" guidance_seconds="<<stats.geometry_guidance_seconds
          <<" collective_calls="<<world.collective_calls-tracked_calls_begin<<" collective_seconds="<<world.collective_seconds-tracked_seconds_begin
          <<" election_calls="<<world.election_collective_calls-election_calls_begin<<" election_seconds="<<world.election_collective_seconds-election_seconds_begin
          <<" direct_calls="<<g.direct_calls-geometry_begin.direct_calls<<" direct_exceptions="<<g.direct_exceptions-geometry_begin.direct_exceptions
          <<" direct_work="<<g.direct_work-geometry_begin.direct_work<<" direct_seconds="<<g.direct_seconds-geometry_begin.direct_seconds
          <<" upper_calls="<<g.upper_calls-geometry_begin.upper_calls<<" union_exceptions="<<g.union_exceptions-geometry_begin.union_exceptions
          <<" upper_refusals="<<g.upper_refusals-geometry_begin.upper_refusals<<" upper_work="<<g.upper_work-geometry_begin.upper_work
          <<" upper_refinements="<<g.upper_refinements-geometry_begin.upper_refinements
          <<" upper_deferred_bounds="<<g.upper_deferred_bounds-geometry_begin.upper_deferred_bounds
          <<" classification_calls="<<g.classification_calls-geometry_begin.classification_calls
          <<" classification_work="<<g.classification_work-geometry_begin.classification_work
          <<" magnitude_calls="<<g.magnitude_calls-geometry_begin.magnitude_calls
          <<" magnitude_work="<<g.magnitude_work-geometry_begin.magnitude_work
          <<" limit_calls="<<g.limit_calls-geometry_begin.limit_calls
          <<" limit_work="<<g.limit_work-geometry_begin.limit_work
          <<" upper_seconds="<<g.upper_seconds-geometry_begin.upper_seconds<<" full_calls="<<g.full_calls-geometry_begin.full_calls
          <<" full_work="<<g.full_work-geometry_begin.full_work<<" full_seconds="<<g.full_seconds-geometry_begin.full_seconds
          <<" facet_hits="<<g.facet_hits-geometry_begin.facet_hits<<" facet_misses="<<g.facet_misses-geometry_begin.facet_misses
          <<" facet_resolutions="<<g.facet_resolutions
          <<" scope_hits="<<g.scope_hits-geometry_begin.scope_hits<<" scope_misses="<<g.scope_misses-geometry_begin.scope_misses
          <<" scope_attempts="<<g.scope_attempts-geometry_begin.scope_attempts
          <<" scope_builds="<<g.scope_builds-geometry_begin.scope_builds<<" scope_build_work="<<g.scope_build_work-geometry_begin.scope_build_work
          <<" scope_build_seconds="<<g.scope_build_seconds-geometry_begin.scope_build_seconds
          <<" support_calls="<<g.support_calls-geometry_begin.support_calls<<" support_facets="<<g.support_facets-geometry_begin.support_facets
          <<" support_seconds="<<g.support_seconds-geometry_begin.support_seconds
          <<" facet_build_work="<<g.facet_build_work-geometry_begin.facet_build_work<<" facet_build_seconds="<<g.facet_build_seconds-geometry_begin.facet_build_seconds
          <<" piece_selection_work="<<g.piece_selection_work-geometry_begin.piece_selection_work<<" piece_selection_seconds="<<g.piece_selection_seconds-geometry_begin.piece_selection_seconds
          <<" traversal_work="<<g.traversal_work-geometry_begin.traversal_work<<" traversal_seconds="<<g.traversal_seconds-geometry_begin.traversal_seconds
          <<" selected_pieces="<<g.selected_pieces-geometry_begin.selected_pieces<<" support_pieces="<<g.support_pieces-geometry_begin.support_pieces
          <<" smooth_boundary_stars="<<stats.boundary_smoothing_stars<<" smooth_boundary_reused="<<stats.boundary_smoothing_reused
          <<" smooth_boundary_candidates="<<stats.boundary_smoothing_candidates<<" smooth_boundary_rejects="<<stats.boundary_smoothing_validity_rejects<<','<<stats.boundary_smoothing_shape_rejects<<','<<stats.boundary_smoothing_edge_rejects<<','<<stats.boundary_smoothing_geometry_rejects
          <<" smooth_boundary_guidance="<<stats.boundary_smoothing_guidance_calls<<" smooth_boundary_upper_queries="<<stats.boundary_smoothing_upper_queries
          <<" smooth_boundary_move_contexts="<<stats.boundary_smoothing_move_contexts<<" smooth_boundary_prepared_trials="<<stats.boundary_smoothing_prepared_trials
          <<" smooth_boundary_guidance_reused_faces="<<stats.boundary_smoothing_guidance_reused_faces<<" smooth_boundary_guidance_faces="<<stats.boundary_smoothing_guidance_faces<<" smooth_boundary_guidance_early_rejected="<<stats.boundary_smoothing_guidance_early_rejections
          <<" smooth_boundary_moves="<<stats.boundary_smoothing_moves<<" smooth_boundary_debt_reduction="<<double(stats.boundary_smoothing_debt_reduction)
          <<" smooth_boundary_seconds="<<stats.boundary_smoothing_seconds
          <<" smooth_interior_stars="<<stats.interior_smoothing_stars<<" smooth_interior_reused="<<stats.interior_smoothing_reused
          <<" smooth_interior_candidates="<<stats.interior_smoothing_candidates<<" smooth_interior_rejects="<<stats.interior_smoothing_validity_rejects<<','<<stats.interior_smoothing_shape_rejects<<','<<stats.interior_smoothing_edge_rejects<<','<<stats.interior_smoothing_geometry_rejects
          <<" smooth_interior_guidance="<<stats.interior_smoothing_guidance_calls<<" smooth_interior_upper_queries="<<stats.interior_smoothing_upper_queries
          <<" smooth_interior_moves="<<stats.interior_smoothing_moves<<" smooth_interior_debt_reduction="<<double(stats.interior_smoothing_debt_reduction)
          <<" smooth_interior_seconds="<<stats.interior_smoothing_seconds
          <<" retention_refusals="<<g.retention_refusals-geometry_begin.retention_refusals<<" prepared_bytes="<<g.prepared_bytes<<" prepared_limit="<<g.prepared_limit<<" facet_bytes="<<g.facet_bytes<<" scope_bytes="<<g.scope_bytes
          <<" facet_entries="<<g.facet_entries<<" scope_entries="<<g.scope_entries<<" cache_evictions="<<g.evictions<<" cache_evicted_bytes="<<g.evicted_bytes
          <<" memo_direct_hits="<<g.memo_direct_hits-geometry_begin.memo_direct_hits<<" memo_direct_misses="<<g.memo_direct_misses-geometry_begin.memo_direct_misses
          <<" memo_union_hits="<<g.memo_union_hits-geometry_begin.memo_union_hits<<" memo_union_misses="<<g.memo_union_misses-geometry_begin.memo_union_misses
          <<" memo_stores="<<g.memo_stores-geometry_begin.memo_stores<<" memo_evictions="<<g.memo_evictions-geometry_begin.memo_evictions
          <<" memo_evicted_bytes="<<g.memo_evicted_bytes-geometry_begin.memo_evicted_bytes<<" memo_retention_refusals="<<g.memo_retention_refusals-geometry_begin.memo_retention_refusals
          <<" memo_maintenance_work="<<g.memo_maintenance_work-geometry_begin.memo_maintenance_work
          <<" memo_bytes="<<g.memo_bytes<<" memo_limit="<<g.memo_limit<<" memo_direct_entries="<<g.memo_direct_entries<<" memo_union_entries="<<g.memo_union_entries
          <<" length_splits="<<stats.length_splits<<" length_collapses="<<stats.length_collapses
          <<" split_passes="<<stats.length_split_passes<<" collapse_passes="<<stats.length_collapse_passes<<" quality_stages="<<stats.quality_stages
          <<" split_generation="<<stats.split_generation<<" split_lane="<<stats.split_lane
          <<" surface_rounds="<<stats.surface_rounds<<" interior_rounds="<<stats.interior_rounds
          <<" surface_seconds="<<stats.surface_seconds<<" interior_seconds="<<stats.interior_seconds
          <<" surface_conflicts="<<stats.surface_conflicts<<" interior_conflicts="<<stats.interior_conflicts
          <<" interior_boundary_discoveries="<<stats.interior_boundary_discoveries
          <<" unique_long_surface="<<stats.unique_long_surface<<" unique_long_interior="<<stats.unique_long_interior
          <<" unique_edge_debt="<<stats.unique_edge_debt<<" maximum_edge="<<stats.maximum_edge
          <<" edge_census_round="<<edge_census_round<<" edge_census_current="<<(edge_census_round==stats.rounds)
          <<" edge_histogram="<<stats.edge_histogram[0]<<','<<stats.edge_histogram[1]<<','<<stats.edge_histogram[2]
          <<" child_parent_max="<<stats.maximum_child_parent_ratio
          <<" child_ratio_measured="<<stats.child_ratio_measured
          <<" elapsed="<<std::chrono::duration<double>(Clock::now()-started).count()<<std::endl;
      if(std::string(stage)=="length_split_exit")for(const auto& edge:edge_progress.top)
        std::cout<<"NATIVE3D_EDGE rank="<<world.rank<<" generation="<<stats.split_generation
            <<" a="<<edge.edge[0]<<" b="<<edge.edge[1]<<" length="<<edge.length<<" surface="<<edge.surface
            <<" age="<<edge.age<<" disposition="<<edge.disposition<<" disposition_round="<<edge.disposition_round<<'\n';
    }
    if(!observe_stage || !stage_storage_admitted || stage_observer_failed)return !stage_observer_failed;
    CLocalFailure failure;
    if(options.stage_observer)try {
      const auto progress=selection.Progress(working.size());
      options.stage_observer({stage,phase,stats.rounds,result.valid,progress.complete,progress,stats,result.reason,
          working,original,geometry,composition,options.edge_breakpoints,options.wall_heights,options.region_walls,
          options.surface_tolerance,options.maximum_seconds,std::chrono::duration<double>(Clock::now()-started).count(),
          options.maximum_rounds,options.maximum_work,options.memory_ceiling,options.caller_bytes,options.stage_observer_bytes,
          [&](Id id,CellDiagnostic& out){const auto row=working.find(id);return row!=working.end()&&selection.Diagnose(row->second,out);},
          &last_rejection,&diagnostic_rejections,world.rank,world.size});
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    const auto elected=world.elect(failure);
    if(elected.any) {
      stage_observer_failed=true;result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;
      result.reason+=" Stage progress observer failed: "+elected.message;
      return false;
    }
    return true;
  };
  ContextValue transaction_captured_lifetime(control.transaction_captured, false);
  auto& transaction_captured = transaction_captured_lifetime.Get();
  ContextValue layer_active_lifetime(control.layer_active, false);
  auto& layer_active = layer_active_lifetime.Get();
  ContextValue region_active_lifetime(control.region_active, false);
  auto& region_active = region_active_lifetime.Get();
  ContextValue layer_started_lifetime(control.layer_started);
  auto& layer_started = layer_started_lifetime.Get();
  ContextValue region_started_lifetime(control.region_started);
  auto& region_started = region_started_lifetime.Get();
  auto finish=[&]() {
    // Directory stages can refuse shared work and return directly here without an engine vote.
    const auto prior_reason=result.reason;const auto prior_stop=stats.stop;
    if(!context.exchange.Vote(context, CLocalFailure{})) {
      result.valid=result.surface_prepared=false;
      if(prior_stop==EngineStop::WorkBudget && !prior_reason.empty())result.reason=prior_reason;
      else if(!prior_reason.empty() && prior_reason!=result.reason)result.reason+=" Prior failure: "+prior_reason;
    }
    if(region_active && options.timings)stats.reconstruction_seconds+=std::chrono::duration<double>(Clock::now()-region_started).count();
    region_active=false;
    if(layer_active && options.timings)stats.layer_seconds+=std::chrono::duration<double>(Clock::now()-layer_started).count();
    layer_active=false;
    if((result.valid||result.surface_prepared) && geometry.EntityGeometry()) {
      std::optional<SU2NativeTiming3D::PhaseScope> proof_phase;
      std::optional<SU2NativeTiming3D::Scope> proof_scope;
      if (options.timings) {
        proof_phase.emplace(SU2NativeTiming3D::Phase::FinalProof);
        proof_scope.emplace(SU2NativeTiming3D::Operation::Certification);
      }
      CLocalFailure geometryFailure;
      try {
        D9QueryScope d9_query(SU2NativeD9::Site::Finish, &geometry);
        ProveOwnedSurface(world,working,geometry,atlas_budget,stats);
      }
      catch(const std::exception& e){geometryFailure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, geometryFailure)){result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;}
    }
    if(result.surface_prepared && !geometry.EntityGeometry()) {
      std::optional<SU2NativeTiming3D::PhaseScope> proof_phase;
      std::optional<SU2NativeTiming3D::Scope> proof_scope;
      if (options.timings) {
        proof_phase.emplace(SU2NativeTiming3D::Phase::FinalProof);
        proof_scope.emplace(SU2NativeTiming3D::Operation::Certification);
      }
      CLocalFailure geometryFailure;
      try {for(const auto& row:working) {
        const auto patch=GeometryPatch(Imported{{row.second},true,{}},&geometry);
        for(const auto& face:patch.surface) {
          std::array<Point,3> triangle{};
          for(unsigned k=0;k<3;++k)for(const auto& node:row.second.cell.v)if(node.id==face.v[k])triangle[k]=node.p;
          if(geometry.SurfaceDeviation(face.facet,triangle,SU2NativeGeometry::SurfaceQueryNeed::Classify())>options.surface_tolerance)
            geometryFailure.Set(1,face.facet,"Prepared surface does not meet the prescribed geometry tolerance.");
        }
      }}catch(const std::exception& e){geometryFailure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, geometryFailure)){result.surface_prepared=false;stats.stop=EngineStop::Failure;}
    }
    if((result.valid||result.surface_prepared) && !options.wall_heights.empty()) {
      std::optional<SU2NativeTiming3D::PhaseScope> proof_phase;
      std::optional<SU2NativeTiming3D::Scope> proof_scope;
      if (options.timings) {
        proof_phase.emplace(SU2NativeTiming3D::Phase::FinalProof);
        proof_scope.emplace(SU2NativeTiming3D::Operation::Certification);
      }
      CLocalFailure heightFailure;
      for(const auto& row:working) {
        std::string reason;
        if(!EngineTrial::HeightCheck(context, GeometryPatch(Imported{{row.second},true,{}}, &geometry),reason,bool(surface_target)))heightFailure.Set(1,row.first,reason);
      }
      if(!context.exchange.Vote(context, heightFailure)){result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;}
    }
    result.rebuilt_domain=result.valid && region_rebuilt;
    if (stats.stop==EngineStop::None) stats.stop=result.valid||result.surface_prepared ? EngineStop::Complete : EngineStop::Failure;
    if(observe_state) {
      CLocalFailure observed;
      if(!result.valid&&!result.surface_prepared && options.rejected_state)try {options.rejected_state(working,geometry,result.reason);}
      catch(const std::exception& e){observed.Set(2,0,e.what());}
      const auto elected=world.elect(observed);
      if(elected.any) {
        result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;
        result.reason+=" Rejected-state diagnostic failed: "+elected.message;
      }
    }
    stats.final_owned_cells=working.size();
    stats.cached_measured_cells=selection.cells.size();
    stats.cached_invalid_cells=selection.invalid;
    stats.remaining_edges=selection.queue.size()+selection.surface_queue.size()+selection.geometry_queue.size();
    stats.remaining_repairs=selection.repair_queue.size();
    stats.tracked_bytes=world.bytes_sent-tracked_bytes_begin;
    stats.tracked_calls=world.collective_calls-tracked_calls_begin;
    stats.tracked_collective_seconds=world.collective_seconds-tracked_seconds_begin;
    const auto saved_directory=retired_directory;
    context.exchange.RetireDirectory(directory->Statistics());
    if(checkpoint.directory)context.exchange.RetireDirectory(checkpoint.directory->Statistics());
    const auto all_directory=retired_directory;retired_directory=saved_directory;
    stats.collision_seconds=all_directory.collision_seconds;
    stats.collision_builds=all_directory.collision_builds;
    stats.collision_candidates=all_directory.collision_candidates;
    stats.collision_checks=all_directory.collision_checks;
    stats.directory_elections=all_directory.elections;
    stats.directory_election_seconds=all_directory.election_seconds;
    stats.parameter_agreement_seconds=all_directory.parameter_agreement_seconds;
    stats.parameter_publication_seconds=all_directory.parameter_publication_seconds;
    stats.parameter_edits=all_directory.parameter_edits;stats.parameter_faces=all_directory.parameter_faces;
    stats.parameter_payload_bytes=all_directory.parameter_payload_bytes;
    stats.changed_star_scans=all_directory.change_scanned;
    stats.changed_vertices_sent=all_directory.change_sent;
    stats.changed_vertices_received=all_directory.change_received;
    stats.change_notification_seconds=all_directory.change_seconds;
    stats.maximum_work_bytes=std::max(stats.maximum_work_bytes,all_directory.maximum_work_bytes);
    const auto& donor = source.Statistics();
    stats.donor_candidates = donor.index_candidates; stats.donor_filtered = donor.filtered; stats.donor_box_filtered = donor.box_filtered;
    stats.donor_payloads = donor.payloads; stats.donor_reused = donor.reused_candidates; stats.donor_maximum_patch = donor.maximum_patch;
    stats.donor_search_seconds = donor.search_seconds; stats.donor_filter_seconds = donor.filter_seconds;
    stats.metric_support_cells=donor.metric_sample_cells;stats.metric_support_edges=donor.metric_edge_queries;stats.metric_support_skipped=donor.metric_edge_skipped;stats.metric_support_duplicates=donor.metric_edge_duplicates;
    stats.maximum_work_bytes = std::max(stats.maximum_work_bytes, donor.maximum_work_bytes);
    stats.atlas_work=atlas_budget.work-atlas_work_initial;stats.atlas_peak_bytes=atlas_budget.peak_bytes;
    stats.maximum_work_bytes=std::max(stats.maximum_work_bytes,atlas_budget.peak_bytes);
    result.parameters=private_parameters;result.reference=private_geometry;
    if(curved && !result.valid && !selection.cells.empty()) {
      size_t metric_bad=0,geometry_bad=0;
      for(const auto& row:selection.cells){metric_bad+=!row.second.target_valid;geometry_bad+=row.second.geometry_invalid;}
      result.reason+=" Local cached demands: geometry_cells="+std::to_string(geometry_bad)+
          ", metric_or_height_cells="+std::to_string(metric_bad)+", geometry_edges="+std::to_string(selection.geometry_queue.size())+
          ", metric_edges="+std::to_string(selection.queue.size())+".";
    }
    if (!result.valid && !last_rejection.empty()) result.reason += " Last local rejection: " + last_rejection;
    if (options.timings) {
      stats.process_cpu_seconds=double(std::clock()-started_cpu)/CLOCKS_PER_SEC;
      stats.total_seconds=std::chrono::duration<double>(Clock::now()-started).count();
      const double phases=stats.initialization_seconds+stats.seed_seconds+stats.selection_seconds+
          stats.dependency_seconds+stats.reservation_seconds+stats.donor_seconds+stats.reconstruction_seconds+
          stats.metric_seconds+stats.routing_seconds+stats.publication_seconds+stats.update_seconds+stats.completion_seconds+stats.collision_seconds;
      stats.other_seconds=stats.total_seconds-phases-stats.layer_seconds;
    }
    PrintWallLawCensus(working, geometry, options.surface_tolerance, world.rank, "exit", options.timings);
    observe_progress("exit");
    wall_counters.Print(world.rank, {stats.geometry_trials, stats.geometry_rejected, stats.geometry_guidance_trials,
                                     stats.geometry_guidance_rejected, stats.accepted, stats.metric_trials,
                                     stats.proposed, stats.attempted});
    lane_counters.Print(world.rank);
    stats.tracked_bytes=world.bytes_sent-tracked_bytes_begin;
    stats.tracked_calls=world.collective_calls-tracked_calls_begin;
    stats.tracked_collective_seconds=world.collective_seconds-tracked_seconds_begin;
    if(options.timings) {
      const auto total=std::chrono::duration<double>(Clock::now()-started).count();
      stats.other_seconds+=total-stats.total_seconds;stats.total_seconds=total;
      stats.process_cpu_seconds=double(std::clock()-started_cpu)/CLOCKS_PER_SEC;
    }
    result.rebuilt_domain=result.valid && region_rebuilt;
    result.cells.swap(working);
    return std::move(result);
  };
  if(observe_stage) {
    stage_storage_admitted=context.exchange.Admit(context, 0);
    if(!stage_storage_admitted)return finish();
  }
  ContextValue ready_lifetime(control.ready, false);
  auto& ready = ready_lifetime.Get();
  ContextValue maximum_node_lifetime(context.commit.maximum_node, 0);
  auto& maximum_node = maximum_node_lifetime.Get();
  ContextValue maximum_cell_lifetime(context.commit.maximum_cell, 0);
  auto& maximum_cell = maximum_cell_lifetime.Get();
  {
    Timer timer(stats.initialization_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
    CLocalFailure failure;
    const auto curved_lo=TimedAllreduce(int(curved),CPassiveComm::Op::MIN,world.comm);
    const auto curved_hi=TimedAllreduce(int(curved),CPassiveComm::Op::MAX,world.comm);
    const double surface_lo=TimedAllreduce(options.surface_tolerance,CPassiveComm::Op::MIN,world.comm);
    const double surface_hi=TimedAllreduce(options.surface_tolerance,CPassiveComm::Op::MAX,world.comm);
    if(curved_lo!=curved_hi || surface_lo!=surface_hi || !std::isfinite(surface_lo) ||
       (curved && !(surface_lo>0)))
      failure.Set(1,0,"Native3D analytic runtime requires a consistent positive frozen surface tolerance.");
    const auto ownership_lo=TimedAllreduce(int(options.phase_ownership),CPassiveComm::Op::MIN,world.comm);
    const auto ownership_hi=TimedAllreduce(int(options.phase_ownership),CPassiveComm::Op::MAX,world.comm);
    if(ownership_lo!=ownership_hi || ownership_lo<0 || ownership_hi>int(PhaseOwnership::DiagnosticAlways))
      failure.Set(1,0,"Native3D phase ownership controls differ or are invalid.");
    const auto composition_lo=TimedAllreduce(int(bool(composition)),CPassiveComm::Op::MIN,world.comm);
    const auto composition_hi=TimedAllreduce(int(bool(composition)),CPassiveComm::Op::MAX,world.comm);
    const auto bands_lo=TimedAllreduce(int(bool(options.edge_breakpoints)),CPassiveComm::Op::MIN,world.comm);
    const auto bands_hi=TimedAllreduce(int(bool(options.edge_breakpoints)),CPassiveComm::Op::MAX,world.comm);
    if(composition_lo!=composition_hi || bands_lo!=bands_hi || (composition_hi && !bands_lo))
      failure.Set(1,0,"Native3D frozen composition/band policies differ or composed integration is missing.");
    const auto lo=TimedAllreduce(options.maximum_rounds,CPassiveComm::Op::MIN,world.comm);
    const auto hi=TimedAllreduce(options.maximum_rounds,CPassiveComm::Op::MAX,world.comm);
    if (lo!=hi) failure.Set(1,0,"Native 3D round limit must be equal across workers.");
    const auto work_lo=TimedAllreduce(options.maximum_work,CPassiveComm::Op::MIN,world.comm);
    const auto work_hi=TimedAllreduce(options.maximum_work,CPassiveComm::Op::MAX,world.comm);
    const auto window_lo=TimedAllreduce(options.stagnation_window,CPassiveComm::Op::MIN,world.comm);
    const auto window_hi=TimedAllreduce(options.stagnation_window,CPassiveComm::Op::MAX,world.comm);
    const double time_lo=TimedAllreduce(options.maximum_seconds,CPassiveComm::Op::MIN,world.comm);
    const double time_hi=TimedAllreduce(options.maximum_seconds,CPassiveComm::Op::MAX,world.comm);
    if (work_lo!=work_hi || window_lo!=window_hi || !window_hi || !std::isfinite(time_lo) ||
        !std::isfinite(time_hi) || time_lo!=time_hi || time_lo<0)
      failure.Set(1,0,"Native 3D work/time/progress controls differ or are invalid.");
    const auto global_cells=TimedAllreduce(uint64_t(accepted.size()),CPassiveComm::Op::SUM,world.comm);
    stats.work_limit=options.maximum_work==SIZE_MAX ? std::max<size_t>(4096,transfer_memory::Mul(global_cells,64)) : options.maximum_work;
    if (stats.work_limit==SIZE_MAX) failure.Set(1,0,"Native 3D automatic work ceiling overflows.");
    if(atlas_geometry) {
      const auto allowance=transfer_memory::Mul(transfer_memory::Add(global_cells,stats.work_limit),SU2NativeGeometry::MappedFacetReference::ClearanceWork);
      if(allowance==SIZE_MAX)failure.Set(1,0,"Native3D exact atlas arithmetic work reservation overflows.");
      else atlas_budget.maximum_work=options.shared_geometry_budget?
          std::min(atlas_budget.maximum_work,transfer_memory::Add(atlas_budget.work,allowance)):allowance;
    }
    const auto lease_low=TimedAllreduce(unsigned(bool(options.geometry_reservation)),CPassiveComm::Op::MIN,world.comm);
    const auto lease_high=TimedAllreduce(unsigned(bool(options.geometry_reservation)),CPassiveComm::Op::MAX,world.comm);
    if(lease_low!=lease_high)failure.Set(1,0,"Native3D target geometry reservation differs across workers.");
    if(atlas_geometry && options.geometry_reservation)try {target_geometry_lease=options.geometry_reservation(atlas_budget);}
      catch(const std::exception& e){failure.Set(2,0,e.what());}
    const auto batch_lo=TimedAllreduce(options.candidate_batch,CPassiveComm::Op::MIN,world.comm);
    const auto batch_hi=TimedAllreduce(options.candidate_batch,CPassiveComm::Op::MAX,world.comm);
    if (batch_lo!=batch_hi || !batch_hi || batch_hi>MaximumCandidateBatch)
      failure.Set(1,0,"Native 3D candidate batch must be bounded and equal across workers.");
    const auto mode_lo=TimedAllreduce(16*int(bool(surface_target))+2*int(intent)+int(bidirectional),CPassiveComm::Op::MIN,world.comm);
    const auto mode_hi=TimedAllreduce(16*int(bool(surface_target))+2*int(intent)+int(bidirectional),CPassiveComm::Op::MAX,world.comm);
    if (mode_lo!=mode_hi) failure.Set(1,0,"Native 3D adaptation intent differs across workers.");
    if(options.wall_heights.size()>MaximumDirectoryFeatures)
      failure.Set(1,0,"Native3D wall-height policy exceeds bounded marker count.");
    for(const auto& row:options.region_walls) {
      const auto h=options.wall_heights.find(row.first);const auto p=row.second;
      if(h==options.wall_heights.end() || h->second!=p.height || !(p.growth>=1 && p.thickness>=p.height) ||
          !std::isfinite(p.height+p.growth+p.thickness))
        failure.Set(1,0,"Native3D region/height policies are inconsistent or invalid.");
    }
    for(const auto& h:options.wall_heights)if(!(h.second>0) || !std::isfinite(h.second))
      failure.Set(1,0,"Native3D wall-height policy is nonfinite/nonpositive.");
    // One first-height tolerance T (ADAP_BL_FIRST_HEIGHT_TOL) on every worker; no rank-local gate.
    const auto height_tolerance_lo=TimedAllreduce(options.wall_heights.tolerance,CPassiveComm::Op::MIN,world.comm);
    const auto height_tolerance_hi=TimedAllreduce(options.wall_heights.tolerance,CPassiveComm::Op::MAX,world.comm);
    if(!(height_tolerance_lo>0 && height_tolerance_hi<1) || height_tolerance_lo!=height_tolerance_hi)
      failure.Set(1,0,"Native3D first-height tolerance must lie in (0,1) and agree across workers.");
    ready=context.exchange.Vote(context, failure);
    if(ready)ready=context.exchange.Admit(context, transfer_memory::Add(transfer_memory::Mul(world.size,sizeof(std::vector<HeightPolicyRow>)),
        transfer_memory::Mul(transfer_memory::Mul(world.size,options.wall_heights.size()),2*sizeof(HeightPolicyRow))));
    if(ready) {
      std::vector<std::vector<HeightPolicyRow>> to(world.size);
      for(auto& peer:to)for(const auto& h:options.wall_heights) {
        const auto p=options.region_walls.find(h.first);
        peer.push_back({h.first,h.second,p==options.region_walls.end()?0:p->second.growth,
                        p==options.region_walls.end()?0:p->second.thickness});
      }
      bool admitted=false;
      const auto rows=world.exchange(to,&admitted,options.memory_ceiling,context.exchange.Bytes(context));
      if(!admitted){result.reason="Native3D wall-height policy exchange exceeds budget.";ready=false;}
      else {
        if(rows.size()!=size_t(world.size)*options.wall_heights.size())failure.Set(1,0,"Native3D wall-height policies differ across workers.");
        else for(size_t i=0;i<rows.size();++i) {
          auto h=options.wall_heights.begin();std::advance(h,i%options.wall_heights.size());
          const auto p=options.region_walls.find(h->first);
          if(rows[i].marker!=h->first || rows[i].height!=h->second ||
             rows[i].growth!=(p==options.region_walls.end()?0:p->second.growth) ||
             rows[i].thickness!=(p==options.region_walls.end()?0:p->second.thickness))
            failure.Set(1,0,"Native3D wall-height/region policies differ across workers.");
        }
        ready=context.exchange.Vote(context, failure);
      }
    }
    if (ready) ready=context.exchange.Admit(context, transfer_memory::Add(accepted_bytes,64,transfer_memory::Mul(geometry.ExtensionComponents().size(),sizeof(Id)),
        transfer_memory::Mul(std::min<uint64_t>(stats.work_limit,4096),
            bidirectional ? sizeof(Edge)+sizeof(SplitRecord) : coarsening ? sizeof(Edge) : sizeof(SplitRecord)),transfer_memory::Mul(accepted.size(),context.control.SelectionBound(context, repairing))));
    if (ready) try {
      field_identity=std::make_shared<const FrozenMetricIdentity>(surface_target?
          FrozenMetricIdentity::Scope::SurfacePlanning:FrozenMetricIdentity::Scope::FullTarget);
      working=accepted;
      stats.maximum_owned=working.size();
      if (coarsening || bidirectional) result.collapses.reserve(std::min<uint64_t>(stats.work_limit,4096));
      if (!coarsening && !repairing) result.splits.reserve(std::min<uint64_t>(stats.work_limit,4096));
      initial.reserve(working.size());
      eligible_extensions=geometry.ExtensionComponents();
      if(curved)for(const auto& donor:original) {
        maximum_cell=std::max(maximum_cell,donor.cell.id);
        for(auto node:donor.cell.v)maximum_node=std::max(maximum_node,node.id);
      }
      for (const auto& row : working) {
        if(!surface_target||selection.RequestedWall(row.second))initial.push_back(row.first);
        maximum_cell=std::max(maximum_cell,row.first);
        for (auto node : row.second.cell.v) maximum_node=std::max(maximum_node,node.id);
      }
    } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
    if (ready) ready=context.exchange.Vote(context, failure);
    if (ready && !world.maximum(!working.empty())) { failure.Set(1,0,"Native 3D adaptation input is empty."); ready=context.exchange.Vote(context, failure); }
    if (ready) {
      maximum_node=TimedAllreduce(maximum_node,CPassiveComm::Op::MAX,world.comm);
      maximum_cell=TimedAllreduce(maximum_cell,CPassiveComm::Op::MAX,world.comm);
      ready=directory->Build(working,result.reason,options.memory_ceiling,
          transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()));
    }
    if (ready) ready=source.Build(original,result.reason,options.memory_ceiling,
        transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes()));
  }
  if (!ready) return finish();
  // Freeze donors first; normalization changes working associations, not the source interpretation.
  if(atlas_geometry && !geometry.EntityGeometry()) {
    if(!context.exchange.Admit(context, 0))return finish();
    SU2NativeGeometry::BoundaryCoverage refreshed;CLocalFailure failure;
    const auto before_work=atlas_budget.work;
    try {
      if(!SU2NativeGeometry::RebuildWorkingSurface(*geometry.Parameters(),refreshed,atlas_budget,result.reason))
        failure.Set(2,0,result.reason);
    }catch(const std::exception& error){failure.Set(2,0,error.what());}
    if(!context.exchange.Vote(context, failure))return finish();
    if(world.maximum(!refreshed.faces.empty())) {
      std::set<Face> affected;std::vector<Dependency> removed;std::vector<OwnedCell> added;
      const auto face_storage=transfer_memory::Add(SU2Native3D::BoundaryCoverageBytes(refreshed),
          transfer_memory::Mul(refreshed.faces.size(),sizeof(Face)+4*sizeof(void*)));
      if(!context.exchange.Admit(context, face_storage))return finish();
      size_t count=0;
      auto owns=[&](const OwnedCell& row){const auto faces=Faces(row.cell);
        for(unsigned k=0;k<4;++k)if(row.physical[k].present&&affected.count(Key(faces[k])))return true;return false;};
      try {
        for(const auto& row:refreshed.faces)affected.insert(Key(row.first));
        for(const auto& row:working)count+=owns(row.second);
      }catch(const std::exception& error){failure.Set(2,0,error.what());}
      if(!context.exchange.Vote(context, failure))return finish();
      const auto local_storage=transfer_memory::Add(face_storage,transfer_memory::Mul(count,sizeof(Dependency)+sizeof(OwnedCell)));
      if(!context.exchange.Admit(context, local_storage))return finish();
      try {
        removed.reserve(count);added.reserve(count);
        for(const auto& row:working)if(owns(row.second)) {
          if(row.second.version==UINT64_MAX)throw std::overflow_error("Working-surface owner version overflows.");
          removed.push_back({row.first,row.second.version,world.rank});added.push_back(row.second);++added.back().version;
        }
      }catch(const std::exception& error){failure.Set(2,0,error.what());}
      if(!context.exchange.Vote(context, failure))return finish();
      const SU2NativeGeometry::BoundaryCoverage empty;
      if(!directory->Publish(working,removed,added,true,result.reason,options.memory_ceiling,
          transfer_memory::Add(context.exchange.RealBytes(context),source.ResidentBytes(),local_storage),{},
          world.rank?empty:refreshed,&atlas_budget))return finish();
      if(options.timings)std::cout<<"NATIVE3D working surface refresh rank="<<world.rank
          <<" faces="<<refreshed.faces.size()<<" owners="<<added.size()<<" arithmetic_work="<<atlas_budget.work-before_work<<'\n';
    }
  }
  // A complete visible radial region is constructed as one transaction, never as a larger local cavity.
  const auto global_original=TimedAllreduce(uint64_t(original.size()),CPassiveComm::Op::SUM,world.comm);
  const bool prismatic=!surface_target && !repairing && options.region_walls.size()==options.wall_heights.size() &&
      (!coarsening || options.wall_heights.empty()) && PrismaticWallRegion(geometry,options.region_walls);
  bool region_applicable=!surface_target && curved && !repairing && options.region_walls.size()<=1 &&
      options.region_walls.size()==options.wall_heights.size() &&
      (!coarsening || options.wall_heights.empty());
  if(region_applicable) {
    std::set<Id> walls;
    if(!options.region_walls.empty()) {
      const auto policy=options.region_walls.begin()->second;
      const double g=policy.growth,requested=.9*MaximumMetricEdge;
      const double depth=g==1?policy.height*requested:policy.height*(.5*(g-1)+.5*(g+1)*std::expm1((requested-.5)*2*(g-1)/(g+1)))/(g-1);
      region_applicable=std::isfinite(depth) && depth>policy.height && depth<policy.thickness;
    }
    for(const auto& row:geometry.Facets()) {
      const Id id=geometry.Canonical(row.first);const auto a=geometry.Analytic().find(id);
      if(!geometry.CompleteAnalytic(id) || a==geometry.Analytic().end()) {region_applicable=false;break;}
      const bool radial=a->second.kind==AnalyticSurface::Kind::Cylinder || a->second.kind==AnalyticSurface::Kind::Sphere;
      if(radial) {
        walls.insert(id);
        region_applicable=region_applicable && (options.region_walls.empty() || options.region_walls.count(row.second.marker));
      } else region_applicable=region_applicable && a->second.kind==AnalyticSurface::Kind::Disk && !options.region_walls.count(row.second.marker);
    }
    region_applicable=region_applicable && walls.size()==1;
  }
  region_applicable=region_applicable || prismatic;
  const int region_lo=TimedAllreduce(int(region_applicable),CPassiveComm::Op::MIN,world.comm);
  const int region_hi=TimedAllreduce(int(region_applicable),CPassiveComm::Op::MAX,world.comm);
  if(region_lo!=region_hi){result.reason="Native3D region applicability differs across workers.";return finish();}
  if(region_applicable) {
    region_active=true;region_started=Clock::now();CLocalFailure failure;
    // Fresh regional identities must also exceed frozen donor identities after earlier coarsening.
    for(const auto& donor:original) {
      maximum_cell=std::max(maximum_cell,donor.cell.id);
      for(auto node:donor.cell.v)maximum_node=std::max(maximum_node,node.id);
    }
    maximum_node=TimedAllreduce(maximum_node,CPassiveComm::Op::MAX,world.comm);
    maximum_cell=TimedAllreduce(maximum_cell,CPassiveComm::Op::MAX,world.comm);
    const size_t global_input=TimedAllreduce(working.size(),CPassiveComm::Op::SUM,world.comm);
    // shortcut: a bounded single-worker visible region; partition into connected regions for large sources.
    const size_t region_cells=stats.work_limit;
    const auto scratch=transfer_memory::Add(transfer_memory::Mul(global_input,8192),
        transfer_memory::Mul(region_cells,16384),RegionFieldWorkspaceBytes);
    if(!context.exchange.Admit(context, scratch))return finish();
    std::vector<std::vector<OwnedCell>> buckets(world.size);
    try {buckets[0].reserve(working.size());for(const auto& row:working)buckets[0].push_back(row.second);}
    catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return finish();bool admitted=false;
    auto rows=world.exchange(buckets,&admitted,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),scratch));
    if(!admitted){result.reason="Native3D region input exchange exceeds storage.";return finish();}
    std::vector<DonorRegion> regions;Patch old,fresh;std::vector<OwnedCell> replacement;std::vector<BoundaryParameterEdit> region_parameter_edits;bool core_declined=false;
    try {if(!world.rank){
      std::sort(rows.begin(),rows.end(),[](const OwnedCell& a,const OwnedCell& b){return a.cell.id<b.cell.id;});
      old=GeometryPatch(Imported{rows,true,{}}, &geometry);Point lo=rows.front().cell.v[0].p,hi=lo;
      for(const auto& c:old.cells)for(auto n:c.v){lo={std::min(lo.x,n.p.x),std::min(lo.y,n.p.y),std::min(lo.z,n.p.z)};hi={std::max(hi.x,n.p.x),std::max(hi.y,n.p.y),std::max(hi.z,n.p.z)};}
      regions.push_back({lo.x,lo.y,lo.z,hi.x,hi.y,hi.z});
    }}catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return finish();
    DonorPatch imported;imported.valid=true;
    if(global_original<=MaximumDonors)imported=source.Import(regions,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),scratch));
    if(!imported.valid){result.reason=imported.reason;return finish();}
    RegionReport report;
    auto tick=[&](){if(options.maximum_seconds && std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)
      throw std::runtime_error("Native3D region construction exhausts elapsed-time budget.");};
    RegionFieldService service(world,source.Bootstrap(),geometry,composition,options.edge_breakpoints,options.timings,
        options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),scratch,directory->ResidentBytes()),
        [&](const FrozenField& field){FieldCounts(stats,field);},tick);
    try {service.Run([&](const RegionMetric& target){
      bool already_valid=GeometryGuidanceExcess(old,geometry,options.surface_tolerance).excess==0;
      bool short_edges=false;
      if(already_valid)for(const auto& c:old.cells) {
        for(unsigned a=0;a<4 && already_valid;++a)for(unsigned b=a+1;b<4;++b) {
          const auto length=target.edge(c.v[a].p,c.v[b].p);
          if(length>MaximumMetricEdge){already_valid=false;break;}
          short_edges=short_edges || (coarsening && length<CoarseningMetricEdge);
        }
        if(!already_valid)break;
      }
      if(!already_valid || short_edges) {
        ++stats.region_attempts;std::map<Id,Point> points;for(const auto& c:old.cells)for(auto n:c.v)points.emplace(n.id,n.p);
        std::vector<Facet> skin;for(auto f:old.surface){Facet face;face.id=f.facet;face.marker=geometry.Get(f.facet).marker;for(unsigned k=0;k<3;++k)face.v[k]={f.v[k],points.at(f.v[k])};skin.push_back(face);}
        std::sort(skin.begin(),skin.end(),[](const Facet& a,const Facet& b){return Key({a.v[0].id,a.v[1].id,a.v[2].id})<Key({b.v[0].id,b.v[1].id,b.v[2].id});});
        // Surface integrals give one partition-independent region kernel.
        const Point origin=old.cells.front().v[0].p;long double volume=0,x=0,y=0,z=0;
        for(const auto& f:skin){const auto a=f.v[0].p,b=f.v[1].p,c=f.v[2].p;const long double v=Orientation(origin,a,b,c);
          volume+=v;x+=v*((long double)origin.x+a.x+b.x+c.x)/4;y+=v*((long double)origin.y+a.y+b.y+c.y)/4;z+=v*((long double)origin.z+a.z+b.z+c.z)/4;}
        if(!(volume>0))throw std::runtime_error("Native3D region has nonpositive closed volume.");const Point kernel{double(x/volume),double(y/volume),double(z/volume)};
        if(maximum_node==UINT64_MAX||maximum_cell==UINT64_MAX)throw std::overflow_error("Native3D region identity reservation overflows.");
        RegionLimits limits;limits.maximum_cells=region_cells;limits.maximum_work=stats.work_limit;limits.timings=options.timings;
        if(options.rejected_trial)limits.rejected=[&](const Patch& candidate,const std::string& why) {
          options.rejected_trial(old,candidate,{},MetricDiagnosis{},false,why);
        };
        limits.checkpoint=[&](){if(options.maximum_seconds && std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)
            throw std::runtime_error("Native3D region construction exhausts elapsed-time budget.");};
        const bool constructed=ConstructWallRegion(skin,kernel,geometry,options.region_walls,options.surface_tolerance,
            options.wall_heights.tolerance,maximum_node+1,maximum_cell+1,target,limits,fresh,report,result.reason);
        if(!constructed) {
          // A height-free cone cannot resolve every interior field; retain the existing volume operators there.
          core_declined=report.unsupported_topology || (options.region_walls.empty() && !report.exhausted_work &&
              (report.unresolved_core || report.maximum_edge>MaximumMetricEdge));
          if(!core_declined)throw std::runtime_error(result.reason);
          last_rejection=result.reason;
        } else if(coarsening && already_valid && fresh.cells.size()>=old.cells.size()) {
          core_declined=true;
          last_rejection="Native3D regional coarsening did not reduce the cell count.";
        } else {
          stats.global_work=fresh.cells.size()+report.surface_trials+report.junction_trials+report.core_trials+report.front_trials;
          if(stats.global_work>stats.work_limit)throw std::runtime_error("Native3D region construction exceeds global event work.");
          if(geometry.Mapped()){geometry.ExportParameters(old);geometry.ExportParameters(fresh);region_parameter_edits=BoundaryParameterState::Changes(old,fresh,geometry.Parameters()->Revision());}
          std::map<Face,Id> physical;for(auto f:fresh.surface)physical.emplace(Key(f.v),f.facet);
          for(const auto& c:fresh.cells){OwnedCell row;row.cell=c;const auto faces=Faces(c);for(unsigned f=0;f<4;++f){auto found=physical.find(Key(faces[f]));if(found!=physical.end())row.physical[f]={true,found->second};}replacement.push_back(row);}
          PublishMetrics(rows,replacement);
        }
      }
    },imported.cells);}catch(const std::exception& e){failure.Set(2,0,e.what());}
    const auto& field_stats=service.Statistics();
    stats.region_field_points=field_stats.point_calls;stats.region_field_sensor_hits=field_stats.sensor_hits;
    stats.region_field_interior_hits=field_stats.interior_hits;stats.region_field_edges=field_stats.edge_calls;
    stats.region_field_edge_hits=field_stats.edge_hits;stats.region_field_imports=field_stats.imports;
    stats.region_field_maximum_resident=field_stats.maximum_resident;
    stats.field_requests+=field_stats.sensor_hits+field_stats.sampled_points;
    stats.field_hits+=field_stats.sensor_hits;stats.field_misses+=field_stats.sampled_points;
    if(composition)stats.field_compositions+=field_stats.sensor_hits+field_stats.sampled_points;

    stats.region_surface_trials=report.surface_trials;stats.region_junction_trials=report.junction_trials;
    stats.region_core_trials=report.core_trials;stats.region_core_regions=report.core_regions;
    stats.region_transition_fronts=report.transition_fronts;stats.region_front_trials=report.front_trials;
    stats.region_cap_seconds=report.cap_seconds;
    stats.region_sampling_seconds=report.sampling_seconds;stats.region_first_band_seconds=report.first_band_seconds;
    stats.region_transition_seconds=report.transition_seconds;stats.region_junction_seconds=report.junction_seconds;
    stats.region_core_seconds=report.core_seconds;stats.region_validation_seconds=report.validation_seconds;
    stats.global_work=TimedAllreduce(uint64_t(report.generated_cells+report.surface_trials+report.junction_trials+report.core_trials+report.front_trials),CPassiveComm::Op::MAX,world.comm);
    if(!context.exchange.Vote(context, failure)) {
      if(world.maximum(report.exhausted_work))stats.stop=EngineStop::WorkBudget;
      else if(options.maximum_seconds && world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds))stats.stop=EngineStop::TimeBudget;
      return finish();
    }
    const bool changed=world.maximum(!replacement.empty());
    if(changed) {
      std::vector<std::vector<OwnedCell>> to(world.size);
      try {for(auto row:replacement)to[row.cell.id%world.size].push_back(row);}catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure))return finish();
      const auto added=world.exchange(to,&admitted,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),scratch));
      if(!admitted){result.reason="Native3D region result exchange exceeds storage.";return finish();}
      std::vector<Dependency> removed;try{for(const auto& row:working)removed.push_back({row.first,row.second.version,world.rank});}catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure))return finish();
      if(!directory->Publish(working,removed,added,true,result.reason,options.memory_ceiling,transfer_memory::Add(context.exchange.RealBytes(context),scratch),region_parameter_edits,fresh.coverage,geometry.AtlasReservation()))return finish();
      if (!world.rank) {
        ++stats.accepted;
        wall_counters.Accepted();
      }
      stats.maximum_owned = std::max(stats.maximum_owned, working.size());
      stats.region_cells = TimedAllreduce(working.size(), CPassiveComm::Op::SUM, world.comm);
    }
    region_rebuilt=changed;stats.global_work=TimedAllreduce(stats.global_work,CPassiveComm::Op::MAX,world.comm);
    if(changed)try {
      initial.clear();initial.reserve(working.size());
      for(const auto& row:working){if(!surface_target||selection.RequestedWall(row.second))initial.push_back(row.first);maximum_cell=std::max(maximum_cell,row.first);
        for(auto node:row.second.cell.v)maximum_node=std::max(maximum_node,node.id);}
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return finish();
    maximum_node=TimedAllreduce(maximum_node,CPassiveComm::Op::MAX,world.comm);
    maximum_cell=TimedAllreduce(maximum_cell,CPassiveComm::Op::MAX,world.comm);
    // Valid coarsening inputs and finer interior fields retain the existing volume search.
    if(options.timings)stats.reconstruction_seconds+=std::chrono::duration<double>(Clock::now()-region_started).count();
    region_active=false;result.valid=false;result.reason.clear();
  }
  if(!surface_target&&!options.wall_heights.empty()) {
    layer_active=true;layer_started=Clock::now();
    CLocalFailure failure;
    std::set<Id> pending;
    const auto layerScratch=transfer_memory::Add(transfer_memory::Mul(working.size(),sizeof(Id)+4*sizeof(void*)),
        transfer_memory::Mul(transfer_memory::Mul(options.candidate_batch,MaximumReplacementCells),8192),MaximumFrozenFieldBytes);
    if(!context.exchange.Admit(context, layerScratch))return finish();
    auto needs_layer=[&](const OwnedCell& row) {
      bool wall=false;
      for(const auto& f:row.physical)wall=wall || (f.present && options.wall_heights.count(geometry.Get(f.facet).marker));
      if(!wall)return false;
      std::string reason;
      return !EngineTrial::HeightCheck(context, GeometryPatch(Imported{{row},true,{}}, &geometry),reason);
    };
    try {for(const auto& row:working)if(needs_layer(row.second))pending.insert(row.first);}
    catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return finish();
    uint64_t epoch=0;
    while(world.maximum(!pending.empty())) {
      if(stats.global_work>=stats.work_limit) {stats.stop=EngineStop::WorkBudget;result.reason="Native3D first-row initialization exhausts global work budget.";return finish();}
      auto timed_out=[&]() {
        if(options.maximum_seconds && world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
          stats.stop=EngineStop::TimeBudget;result.reason="Native3D first-row initialization exhausts elapsed-time budget.";return true;
        }
        return false;
      };
      if(timed_out())return finish();
      std::vector<Feature> features;std::vector<Id> queued;
      DependencyBatch dependencies;ImportedBatch imported;ReservationBatch reserved;
      auto plan=[&]() {
        Timer timer(stats.layer_metadata_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
        const uint64_t available=std::min(pending.size(),options.candidate_batch);
        const auto position=CPassiveComm::ExscanSum(available,world.comm);
        const auto remaining=stats.work_limit-stats.global_work;
        const size_t count=position<remaining ? std::min(available,remaining-position) : 0;
        stats.global_work+=TimedAllreduce(uint64_t(count),CPassiveComm::Op::SUM,world.comm);
        try {
          auto it=pending.begin();
          for(size_t i=0;i<count;++i,++it) {
            const auto& row=working.at(*it);const auto faces=Faces(row.cell);bool found=false;
            for(unsigned f=0;f<4;++f)if(row.physical[f].present && options.wall_heights.count(geometry.Get(row.physical[f].facet).marker)) {
              features.push_back({faces[f],3});queued.push_back(row.cell.id);found=true;break;
            }
            if(!found)throw std::runtime_error("Native3D first-row queue lost its wall face.");
          }
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return false;
        ++stats.layer_batches;stats.layer_maximum_batch=std::max(stats.layer_maximum_batch,features.size());
        const auto held=transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),layerScratch);
        dependencies=directory->LookupBatch(features,options.memory_ceiling,held);
        if(!dependencies.valid){result.reason=dependencies.reason;return false;}
        imported=directory->FetchBatch(dependencies,working,options.memory_ceiling,held);
        if(!imported.valid){result.reason=imported.reason;return false;}
        try {for(size_t i=0;i<imported.candidates.size();++i) {
          const auto& item=imported.candidates[i];
          if(!item.valid || item.cells.size()!=1 || item.cells.front().cell.id!=queued.at(i))
            throw std::runtime_error("Native3D first-row batch lacks its complete queued cell.");
        }}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return false;
        // These operators preserve every old face/vertex; only the cell interiors are written.
        reserved=directory->ReserveInteriors(imported,options.memory_ceiling,held);
        if(!reserved.valid){result.reason=reserved.reason;return false;}
        if(!world.maximum(std::any_of(reserved.chosen.begin(),reserved.chosen.end(),[](bool x){return x;}))) {
          result.reason="Native3D first-row batch has no reserved cell.";return false;
        }
        return true;
      };
      if(!plan())return finish();
      std::vector<Patch> proposals;
      try {proposals.resize(imported.candidates.size());}catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure))return finish();
      const size_t slots=TimedAllreduce(imported.candidates.size(),CPassiveComm::Op::MAX,world.comm);
      auto joint_candidate=[&](const auto& item) {
        unsigned walls=0;
        for(const auto& face:item.cells.front().physical)
          walls+=face.present && options.wall_heights.count(geometry.Get(face.facet).marker);
        return walls>1;
      };
      bool local_joint=false;
      for(size_t k=0;k<imported.candidates.size();++k)if(reserved.chosen[k])local_joint=local_joint || joint_candidate(imported.candidates[k]);
      const bool ranked_background=world.maximum(local_joint);
      size_t span=options.candidate_batch;
      auto construct=[&]() {
        for(size_t at=0;at<slots;) {
          if(timed_out())return false;
          size_t group=std::min(span,slots-at);DonorPatch donors;
          if(ranked_background) {
            Timer timer(stats.layer_donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);
            for(;;) {
              std::vector<Cell> query;std::vector<OwnedCell> metric_context;
              try {for(size_t k=at;k<std::min(at+group,imported.candidates.size());++k)
                if(reserved.chosen[k] && joint_candidate(imported.candidates[k])) {
                  query.push_back(imported.candidates[k].cells.front().cell);
                  metric_context.push_back(imported.candidates[k].cells.front());
                }
              }catch(const std::exception& e){failure.Set(2,0,e.what());}
              if(!context.exchange.Vote(context, failure))return false;
              source.SetCavity(&metric_context);
              donors=context.exchange.ImportSource(context, query,layerScratch,true);
              source.SetCavity(nullptr);
              if(donors.valid)break;
              if(!DonorCap(donors.reason) || group==1){result.reason=donors.reason;return false;}
              span=(group+1)/2;group=std::min(span,slots-at);++stats.layer_donor_retries;
            }
          }
          std::unique_ptr<FrozenField> target;std::unique_ptr<FieldAccounting> accounting;
          try {
            if(ranked_background) {
              Timer timer(stats.layer_metric_seconds,options.timings,
                          SU2NativeTiming3D::Operation::MetricNormalization);
              const auto components=AssociatedExtensions(donors.cells,geometry);
              target=std::make_unique<FrozenField>(std::move(donors.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
              accounting.reset(new FieldAccounting{stats,*target});
            }
          }catch(const std::exception& e){failure.Set(2,0,e.what());}
          if(!context.exchange.Vote(context, failure))return false;
          bool rejected=false,expired=false;
          auto local_deadline=[&]() {return options.maximum_seconds && std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds;};
          for(size_t k=at;k<at+group;++k) {
            if(local_deadline()){expired=true;break;}
            if(k<imported.candidates.size() && reserved.chosen[k])try {
              const auto old=GeometryPatch(imported.candidates[k], &geometry);auto& fresh=proposals[k];bool approved=false;
              const auto ticket=transfer_memory::Add(transfer_memory::Mul(
                  transfer_memory::Add(transfer_memory::Mul(epoch,world.size),world.rank),options.candidate_batch),k);
              const auto nodeOffset=transfer_memory::Mul(ticket,5),cellOffset=transfer_memory::Mul(ticket,MaximumReplacementCells);
              if(maximum_node>UINT64_MAX-5 || nodeOffset>UINT64_MAX-maximum_node-5 ||
                 maximum_cell>UINT64_MAX-MaximumReplacementCells || cellOffset>UINT64_MAX-maximum_cell-MaximumReplacementCells)
                throw std::invalid_argument("Native3D first-row reserved range overflows.");
              if(old.cells.size()!=1 || old.surface.size()>4)
                throw std::invalid_argument("Native3D first-row identity reservation requires one complete wall cell.");
              const Id node=maximum_node+1+nodeOffset,cell=maximum_cell+1+cellOffset;
              if(!joint_candidate(imported.candidates[k])) {
                FirstHeightReport report;
                {Timer timer(stats.layer_geometry_seconds,options.timings,
                              SU2NativeTiming3D::Operation::GeometryBound);
                  approved=InsertFirstWallPoint(old,node+1,cell,options.wall_heights,geometry,fresh,report,result.reason);
                  if(approved && !SameSkin(old,fresh))throw std::runtime_error("Native3D interior first-row replacement changed its interface.");
                }
              } else {
                std::vector<Point> backgrounds{Centroid(old.cells.front())};
                std::map<Id,Point> coordinates;for(const auto& c:old.cells)for(auto n:c.v)coordinates.emplace(n.id,n.p);
                for(const auto& face:old.surface) {
                  const auto h=options.wall_heights.find(geometry.Get(face.facet).marker);if(h==options.wall_heights.end())continue;
                  const auto a=coordinates.at(face.v[0]),b=coordinates.at(face.v[1]),c=coordinates.at(face.v[2]);
                  const std::array<long double,3> u{(long double)b.x-a.x,(long double)b.y-a.y,(long double)b.z-a.z},
                      v{(long double)c.x-a.x,(long double)c.y-a.y,(long double)c.z-a.z};
                  auto normal=std::array<long double,3>{u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]};
                  const auto length=std::hypot(normal[0],normal[1],normal[2]);for(auto& x:normal)x/=length;
                  for(double factor:{1.25,1.5,2.})backgrounds.push_back({double(((long double)a.x+b.x+c.x)/3-factor*h->second*normal[0]),
                      double(((long double)a.y+b.y+c.y)/3-factor*h->second*normal[1]),double(((long double)a.z+b.z+c.z)/3-factor*h->second*normal[2])});
                }
                long double bestLength=std::numeric_limits<long double>::infinity();std::map<Edge,EdgeMeasure> reuse;
                for(const auto& background:backgrounds) {
                  Patch candidate;FirstHeightReport report;std::string why;bool built=false;
                  {Timer timer(stats.layer_geometry_seconds,options.timings,
                                SU2NativeTiming3D::Operation::GeometryBound);
                    built=ConstructFirstLayer(old,{node,background},node+1,cell,options.wall_heights,geometry,candidate,report,why);
                    if(built && !SameSkin(old,candidate))throw std::runtime_error("Native3D interior first-row replacement changed its interface.");
                  }
                  if(!built) {
                    if(!approved)result.reason=why;
                    if(why.find("geometry-height incompatibility")!=std::string::npos)break;
                    continue;
                  }
                  MetricStats counted;PatchMetric measured;
                  {Timer timer(stats.layer_metric_seconds,options.timings,
                                SU2NativeTiming3D::Operation::MetricNormalization);
                    measured=MeasureMetricEdges(candidate.cells,*target,&counted,&reuse);
                  }
                  reuse=measured.edges;
                  stats.layer_edge_evaluations+=counted.edge_evaluations;stats.layer_edge_reused+=counted.edge_reused;
                  if(measured.maximum_length<bestLength) {
                    bestLength=measured.maximum_length;fresh=std::move(candidate);approved=true;result.reason.clear();
                  }
                }
              }
              if(!approved){failure.Set(1,old.cells.front().id,"Native3D initial first-row construction rejected: "+result.reason);rejected=true;}
            }catch(const std::exception& e){failure.Set(2,k<queued.size()?queued[k]:0,e.what());rejected=true;}
            if(rejected)break;
            if(local_deadline()){expired=true;break;}
          }
          // Private operators/query fields are local. Vote once per admitted group, while each worker checks its deadline per candidate.
          if(!context.exchange.Vote(context, failure))return false;
          if(world.maximum(expired)) {
            stats.stop=EngineStop::TimeBudget;result.reason="Native3D first-row initialization exhausts elapsed-time budget.";return false;
          }
          at+=group;
        }
        return true;
      };
      if(!construct())return finish();
      auto publish=[&]() {
        Timer timer(stats.layer_publication_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
        std::vector<std::vector<Dependency>> toRemove(world.size);
        std::vector<std::vector<OwnedCell>> toAdd(world.size);size_t published=0;
        std::vector<BoundaryParameterEdit> layer_parameter_edits;SU2NativeGeometry::BoundaryCoverage layer_coverage;
        try {for(size_t k=0;k<proposals.size();++k)if(reserved.chosen[k]) {
          const auto& old=imported.candidates[k].cells.front().cell;const auto& fresh=proposals[k];
          const auto& dep=dependencies.candidates[k].cells.front();
          if(dep.cell!=old.id || dependencies.candidates[k].cells.size()!=1 || fresh.cells.empty())
            throw std::runtime_error("Native3D first-row publication lacks its complete replacement.");
          if(geometry.Mapped()) {
            auto before=GeometryPatch(imported.candidates[k],&geometry);auto after=fresh;geometry.ExportParameters(after);
            const auto changes=BoundaryParameterState::Changes(before,after,geometry.Parameters()->Revision());layer_parameter_edits.insert(layer_parameter_edits.end(),changes.begin(),changes.end());
            for(const auto& cover:after.coverage.faces)if(!layer_coverage.faces.emplace(cover).second)throw std::invalid_argument("Repeated physical face in layer atlas publication.");
            for(const auto& trace:after.coverage.traces){const auto previous=layer_coverage.traces.find(trace.first);std::string why;
              if(previous==layer_coverage.traces.end())layer_coverage.traces.emplace(trace);
              else if(!geometry.AtlasReservation()||!geometry.Parameters()->Geometry().EqualTraces(previous->second,trace.second,*geometry.AtlasReservation(),why))throw std::invalid_argument("Conflicting inherited layer atlas edge: "+why);}
          }
          toRemove.at(dep.owner).push_back(dep);
          std::map<Face,Id> physical;for(const auto& f:fresh.surface)physical.emplace(Key(f.v),f.facet);
          for(const auto& c:fresh.cells) {
            OwnedCell row;row.cell=c;const auto faces=Faces(row.cell);
            for(unsigned f=0;f<4;++f){const auto found=physical.find(Key(faces[f]));if(found!=physical.end())row.physical[f]={true,found->second};}
            std::vector<OwnedCell> metric_rows{row};
            PublishMetrics(imported.candidates.at(k).cells,metric_rows);
            toAdd.at(dep.owner).push_back(metric_rows.front());
          }
          ++published;
        }}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return false;
        bool admitted=false;const auto baseline=transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),layerScratch);
        const auto removed=world.exchange(toRemove,&admitted,options.memory_ceiling,baseline);
        if(!admitted){result.reason="Native3D first-row removal routing exceeds budget.";return false;}
        const auto added=world.exchange(toAdd,&admitted,options.memory_ceiling,baseline);
        if(!admitted){result.reason="Native3D first-row addition routing exceeds budget.";return false;}
        if(!directory->Publish(working,removed,added,true,result.reason,options.memory_ceiling,transfer_memory::Add(context.exchange.RealBytes(context),source.ResidentBytes(),layerScratch),layer_parameter_edits,layer_coverage,geometry.AtlasReservation()))return false;
        try {
          for(const auto& row:removed)pending.erase(row.cell);
          for(const auto& row:added)if(needs_layer(row))pending.insert(row.cell.id);
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return false;
        stats.layer_published+=published;++epoch;stats.maximum_owned=std::max(stats.maximum_owned,working.size());
        return true;
      };
      if(!publish())return finish();
    }
    try {
      initial.clear();initial.reserve(working.size());
      for(const auto& row:working){if(!surface_target||selection.RequestedWall(row.second))initial.push_back(row.first);maximum_cell=std::max(maximum_cell,row.first);for(auto n:row.second.cell.v)maximum_node=std::max(maximum_node,n.id);}
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return finish();
    maximum_node=TimedAllreduce(maximum_node,CPassiveComm::Op::MAX,world.comm);
    maximum_cell=TimedAllreduce(maximum_cell,CPassiveComm::Op::MAX,world.comm);
    if(options.timings)stats.layer_seconds+=std::chrono::duration<double>(Clock::now()-layer_started).count();
    layer_active=false;
  }
  constexpr size_t MeasurementBatch=16;
  // Construction requests missing edges only; improvement also imports centroid support.
  auto measure=[&](const std::vector<Id>& requested_ids,bool seed,double* enclosing_seconds) {
    std::optional<SU2NativeTiming3D::Scope> census_scope;
    if (options.timings) census_scope.emplace(SU2NativeTiming3D::Operation::Census);
    std::vector<Id> demand;
    const auto demand_bytes=surface_target?transfer_memory::GrowthBound(requested_ids.size(),sizeof(Id)):0;
    const auto plan_scratch=transfer_memory::Add(demand_bytes,
        transfer_memory::Mul(3*MaximumCampaignEdges,sizeof(std::pair<const Edge,EdgeMeasure>)+6*sizeof(void*)),
        surface_target?transfer_memory::Add(SurfacePlanningScratchBytes(MeasurementBatch),
            transfer_memory::Mul(MeasurementBatch,sizeof(OwnedCell))):0);
    if(!context.exchange.Admit(context, transfer_memory::Add(plan_scratch,transfer_memory::Mul(MeasurementBatch,sizeof(Cell)+sizeof(unsigned char)))))return false;
    if(surface_target) {
      CLocalFailure failure;
      try {
        demand.reserve(requested_ids.size());
        for(Id id:requested_ids)if(selection.RequestedWall(working.at(id)))demand.push_back(id);
        stats.surface_measurement_skipped+=requested_ids.size()-demand.size();
      }catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure))return false;
    }
    // Publication keeps the complete cavity; only requested walls own this provisional census.
    const auto& ids=surface_target?demand:requested_ids;
    selection.census_started=true;
    const size_t count=TimedAllreduce(ids.size(),CPassiveComm::Op::MAX,world.comm);
    for (size_t slot=0; slot<count;) {
      if(options.maximum_seconds && world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
        stats.stop=EngineStop::TimeBudget;result.reason=seed ? "Native3D metric seeding exhausts elapsed-time budget." :
            "Native3D metric update exhausts elapsed-time budget.";return false;
      }
      size_t batch=std::min({MeasurementBatch,MaximumCavityCells/6,count-slot});
      DonorPatch imported;std::map<Edge,EdgeMeasure> reuse;
      CLocalFailure failure;
      for (;;) {
        std::vector<Cell> regions;
        try {
          reuse.clear();
          for (size_t i=slot;i<std::min(slot+batch,ids.size());++i) {
            const auto& cell=working.at(ids[i]).cell;regions.push_back(cell);selection.Cached(cell,reuse);
            for(auto a:cell.v)for(auto b:cell.v)if(a.id<b.id) {
              const auto prior=retired_edges.find({a.id,b.id});if(prior!=retired_edges.end())reuse.emplace(prior->first,prior->second);
            }
          }
        } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        if (!context.exchange.Vote(context, failure)) return false;
        std::vector<unsigned char> requests;
        try {requests=MetricEdgeRequests(regions,reuse,field_identity,&campaign_edges);}
        catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return false;
        {Timer timer(stats.donor_seconds,options.timings,enclosing_seconds, SU2NativeTiming3D::Operation::Import);
          imported=context.exchange.ImportSource(context, regions,transfer_memory::Add(MaximumFrozenFieldBytes,plan_scratch),false,&requests);}

        if (imported.valid) break;
        if (batch==1) { result.reason=imported.reason; return false; }
        batch=(batch+1)/2; ++stats.batch_retries;
      }
      if (!context.exchange.Admit(context, transfer_memory::Add(transfer_memory::Bytes(imported.cells),
          MaximumFrozenFieldBytes,plan_scratch,transfer_memory::Mul(working.size(),context.control.SelectionBound(context, selection.track_repairs))))) return false;
      if (slot<ids.size()) try {
        CpuTimer private_cpu(stats.measurement_cpu_seconds,options.timings);
        const auto components=AssociatedExtensions(imported.cells,geometry);
        FrozenField field(std::move(imported.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
        FieldAccounting accounting{stats,field};
        PatchMetric planned;
        if(surface_target && phase==Phase::Construction) {
          Imported published;published.cells.reserve(batch);
          for(size_t i=slot;i<std::min(slot+batch,ids.size());++i)published.cells.push_back(working.at(ids[i]));
          MetricStats counted;
          // Published coordinates/associations and the field are unchanged throughout this measurement batch.
          planned=MeasureSurfacePlanning(GeometryPatch(published,&geometry),field,geometry,options.wall_heights,surface_target,&counted);
          stats.edge_evaluations+=counted.edge_evaluations;stats.edge_reused+=counted.edge_reused;
        }
        for (size_t i=slot;i<std::min(slot+batch,ids.size());++i) {
          PatchMetric metric;
          std::string reason;
          MetricStats counted;
          const auto& cell=working.at(ids[i]).cell;
          bool strict=false,quality_valid=false,height_valid=true;FirstHeightReport height;
          if(phase==Phase::Construction) {
            if(surface_target) {
              const auto& owned=working.at(ids[i]);
              for(unsigned a=0;a<4;++a)for(unsigned b=a+1;b<4;++b) {
                Edge key{cell.v[a].id,cell.v[b].id};std::sort(key.begin(),key.end());
                metric.edges.emplace(key,planned.edges.at(key));
              }
              for(const auto& edge:metric.edges)for(unsigned face=0;face<4;++face)
                if(cell.v[face].id!=edge.first[0] && cell.v[face].id!=edge.first[1] && owned.physical[face].present &&
                    options.wall_heights.count(geometry.Get(owned.physical[face].facet).marker) && edge.second.length>metric.maximum_length) {
                  metric.maximum_length=edge.second.length;metric.longest_edge=edge.first;
                }
            } else metric=MeasureMetricEdges({cell},field,&counted,&reuse,&campaign_edges);
            strict=metric.maximum_length<=MaximumMetricEdge;
          } else {
            const bool metric_valid=ValidateMetricPatch({cell},field,metric,reason,&counted,&reuse);
            std::string height_reason;
            height_valid=EngineTrial::HeightCheck(context, GeometryPatch(Imported{{working.at(ids[i])},true,{}}, &geometry),height_reason,false,&height);
            if(!height_valid)reason=height_reason;
            quality_valid=metric.shape_measured && std::isfinite(metric.minimum_mean_ratio) && std::isfinite(metric.minimum_scaled_jacobian) &&
                metric.minimum_mean_ratio>=MinimumMeanRatio &&
                metric.minimum_scaled_jacobian>=MinimumScaledJacobian && height_valid;
            strict=metric_valid && height_valid;
          }
          if(phase==Phase::Improvement && selection.cells.count(ids[i]))
            selection.RefreshQuality(working.at(ids[i]),metric,strict,quality_valid,!options.wall_heights.empty()?&height:nullptr,height_valid,field_identity);
          else selection.Add(working.at(ids[i]),metric,strict,quality_valid,reason,
              phase==Phase::Improvement && !options.wall_heights.empty()?&height:nullptr,height_valid);
          for(const auto& edge:metric.edges)reuse.insert_or_assign(edge.first,edge.second);
          stats.edge_evaluations+=counted.edge_evaluations;
          stats.edge_reused+=counted.edge_reused;
          if (seed) ++stats.initial_cells; else ++stats.updated_cells;
          const auto& owned=working.at(ids[i]);
          const unsigned category=selection.RequestedWall(owned)?2:selection.cells.at(ids[i]).surface?1:0;
          ++(seed?stats.seed_cell_classes:stats.updated_cell_classes)[category];
        }
      } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
      if (!context.exchange.Vote(context, failure)) return false;
      slot+=batch;if(seed)++stats.seed_batches;
    }
    return true;
  };
  auto seed_next=[&](bool local_active=true) {
    Timer timer(stats.seed_seconds,options.timings, SU2NativeTiming3D::Operation::Census);
    // Composed or sided planning is expensive; a complete cavity may remove still-unmeasured topology.
    if((!composition && !surface_target) || phase==Phase::Improvement) {const bool measured=measure(initial,true,&stats.seed_seconds);if(measured)seed_slot=initial.size();return measured;}
    if(options.maximum_seconds && world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
      stats.stop=EngineStop::TimeBudget;result.reason="Native3D metric seeding exhausts elapsed-time budget.";return false;
    }
    if(!context.exchange.Admit(context, transfer_memory::Mul(MeasurementBatch,sizeof(Id))))return false;
    CLocalFailure failure;std::vector<Id> next;
    try {
      size_t scanned=0;next.reserve(MeasurementBatch);
      while(local_active && seed_slot<initial.size() && next.size()<MeasurementBatch && scanned++<MaximumDirectoryScan) {
        const auto id=initial[seed_slot++];
        if(working.count(id) && !selection.cells.count(id))next.push_back(id);
      }
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    return context.exchange.Vote(context, failure) && measure(next,true,&stats.seed_seconds);
  };
  ContextValue ownership_evaluated_lifetime(context.ownership.ownership_evaluated, std::array<bool, 2>{{false, false}});
  auto& ownership_evaluated = ownership_evaluated_lifetime.Get();
  ContextValue quality_ownership_round_lifetime(context.ownership.quality_ownership_round, 0);
  auto& quality_ownership_round = quality_ownership_round_lifetime.Get();
  auto phase_ownership=[&](bool quality) {
    auto within_time=[&]() {
      if(!options.maximum_seconds)return true;
      if(!world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds))return true;
      stats.stop=EngineStop::TimeBudget;result.reason="Native3D phase ownership exceeds the event deadline; prior ownership retained.";return false;
    };
    if(!within_time())return false;
    const unsigned boundary=quality?1:0;
    if(world.size==1 || options.phase_ownership==PhaseOwnership::Disabled)return true;
    if(ownership_evaluated[boundary]&&(!quality||stats.rounds<quality_ownership_round||
        stats.rounds-quality_ownership_round<options.stagnation_window))return true;
    if(!quality){ownership_evaluated[boundary]=true;++stats.ownership_evaluations;}
    // The checkpoint's ownership is part of its rollback contract. Its enclosing speculative
    // coarsening cycle retains that ownership until it is explicitly retired.
    if(world.maximum(checkpoint.valid || !scope_census_complete() || (quality&&!selection.repair_zero.empty())))return true;
    if(quality&&world.maximum(!selection.Progress(working.size()).complete))return true;
    const auto global_cells=TimedAllreduce(uint64_t(working.size()),CPassiveComm::Op::SUM,world.comm);
    // Optional migration cannot populate one graph part per rank with fewer cells than ranks.
    if(global_cells<uint64_t(world.size))return true;
    if(quality){ownership_evaluated[boundary]=true;quality_ownership_round=stats.rounds;++stats.ownership_evaluations;}
    const double transition_started=world.seconds();
    const auto scratch=transfer_memory::Add(MapBytes(working),transfer_memory::Mul(working.size(),
        sizeof(uint32_t)*(quality?3:2)+sizeof(double)*(quality?3:2)+sizeof(Selection::CachedRow)*3+sizeof(Id)),
        transfer_memory::Mul(working.size(),4*(sizeof(std::pair<const Id,uint64_t>)+4*sizeof(void*))),
        transfer_memory::Mul(world.size,256),
        quality&&geometry_authority?transfer_memory::Mul(geometry_authority->Reference().Facets().size(),256):0);
    if(!context.exchange.Admit(context, scratch))return false;
    std::map<Id,uint64_t> complete_stars;
    if(!VertexStarSizes(world,working,complete_stars,result.reason,options.memory_ceiling,
        transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),scratch),&stats.maximum_work_bytes))return false;
    if(!within_time())return false;
    CLocalFailure failure;std::vector<uint32_t> weights,geometric,quality_weights;std::vector<double> costs,geometry_costs,quality_debts;
    double local_demand=0,local_geometry=0,local_quality_debt=0;
    try {
      costs.reserve(working.size());geometry_costs.reserve(working.size());weights.reserve(working.size());geometric.reserve(working.size());
      if(quality){quality_debts.reserve(working.size());quality_weights.reserve(working.size());}
      for(const auto& owned:working) {
        if(surface_target&&!quality&&!selection.RequestedWall(owned.second)) {
          // Untouched volume has no independent wall demand; it still migrates with the complete mesh.
          costs.push_back(1);geometry_costs.push_back(0);local_demand+=1;continue;
        }
        const auto& row=selection.cells.at(owned.first);double demand=1;
        if(quality) {
          if(!row.shape_measured)throw std::logic_error("Quality ownership requires the permitted complete shape census.");
          const double debt=double(row.debt.q+row.debt.j);
          if(!std::isfinite(debt)||debt<0)throw std::logic_error("Invalid quality ownership debt.");
          quality_debts.push_back(debt);local_quality_debt+=debt;
          double star=0;for(Id vertex:row.vertices)star+=complete_stars.at(vertex)/4.;
          demand+=(double(row.debt.q+row.debt.j+row.debt.height)+double(row.geometry_invalid))*(1+star);
        }
        for(unsigned i=0;i<6;++i) {
          const auto edge=row.edges[i];const auto length=selection.edges.at(edge).measure.length;
          if(surface_target&&!selection.edges.at(edge).physical_users)continue;
          const double insertions=double(std::max(0.L,length/MaximumMetricEdge-1));
          const auto star=complete_stars.at(edge[0])+complete_stars.at(edge[1]);
          demand+=insertions*(1+std::log2(1.+star));
        }
        double geometry_cost=0;
        if(quality && geometry_authority && options.surface_tolerance>0) {
          std::array<long double,6> lengths;
          // Cached rows use global key order; the predictor requires local vertex-pair order.
          unsigned slot=0;
          for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j) {
            Edge edge{owned.second.cell.v[i].id,owned.second.cell.v[j].id};std::sort(edge.begin(),edge.end());
            lengths[slot++]=selection.edges.at(edge).measure.length;
          }
          geometry_cost=EstimateGeometryWork(owned.second,geometry,options.surface_tolerance,lengths).work*demand;
        } else for(unsigned face=0;face<4;++face)if(owned.second.physical[face].present) {
          double preparation=1;
          if(geometry_authority) {
            const auto structure=geometry_authority->StructuralEstimate(owned.second.physical[face].facet);
            const double pieces=std::max(double(structure.prepared_pieces),
                std::clamp(options.surface_tolerance>0?16*structure.control_deviation/options.surface_tolerance:1.,1.,1048576.));
            preparation+=pieces*(1+std::log2(pieces));
          }
          geometry_cost+=preparation*demand;
        }
        if(!(std::isfinite(demand)&&std::isfinite(geometry_cost)))throw std::logic_error("Nonfinite phase workload estimate.");
        costs.push_back(demand);geometry_costs.push_back(geometry_cost);local_demand+=demand;local_geometry+=geometry_cost;
      }
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure)||!within_time())return false;
    const auto max_cost=TimedAllreduce(costs.empty()?0:*std::max_element(costs.begin(),costs.end()),CPassiveComm::Op::MAX,world.comm);
    const auto max_geometry=TimedAllreduce(geometry_costs.empty()?0:*std::max_element(geometry_costs.begin(),geometry_costs.end()),CPassiveComm::Op::MAX,world.comm);
    const double max_quality_debt=quality?TimedAllreduce(quality_debts.empty()?0:*std::max_element(quality_debts.begin(),quality_debts.end()),CPassiveComm::Op::MAX,world.comm):0;
    for(size_t i=0;i<costs.size();++i) {
      weights.push_back(uint32_t(std::clamp(std::ceil(costs[i]/std::max(1.,max_cost)*MaximumPartitionWeight),1.,double(MaximumPartitionWeight))));
      geometric.push_back(geometry_costs[i]>0?uint32_t(std::clamp(std::ceil(geometry_costs[i]/max_geometry*MaximumPartitionWeight),1.,double(MaximumPartitionWeight))):0);
      if(quality)quality_weights.push_back(quality_debts[i]>0?uint32_t(std::clamp(std::ceil(quality_debts[i]/max_quality_debt*MaximumPartitionWeight),1.,double(MaximumPartitionWeight))):0);
    }
    const double demand_sum=TimedAllreduce(local_demand,CPassiveComm::Op::SUM,world.comm);
    const double demand_max=TimedAllreduce(local_demand,CPassiveComm::Op::MAX,world.comm);
    const double geometry_sum=TimedAllreduce(local_geometry,CPassiveComm::Op::SUM,world.comm);
    const double geometry_max=TimedAllreduce(local_geometry,CPassiveComm::Op::MAX,world.comm);
    const double quality_debt_sum=quality?TimedAllreduce(local_quality_debt,CPassiveComm::Op::SUM,world.comm):0;
    const double quality_debt_max=quality?TimedAllreduce(local_quality_debt,CPassiveComm::Op::MAX,world.comm):0;
    const double imbalance=std::max({demand_sum?world.size*demand_max/demand_sum:1.,geometry_sum?world.size*geometry_max/geometry_sum:1.,
        quality_debt_sum?world.size*quality_debt_max/quality_debt_sum:1.});
    const double wall=std::chrono::duration<double>(Clock::now()-started).count();
    // Conservative benefit proxy: remaining demand relative to observed attempted edits. The
    // twofold hurdle acknowledges unknown placement, operator mix and destination cache locality.
    const double attempts=TimedAllreduce(double(stats.attempted),CPassiveComm::Op::SUM,world.comm);
    const double remaining=wall*std::max(0.,demand_sum-double(global_cells))/std::max(1.,attempts);
    const double estimate_seconds=TimedAllreduce(world.seconds()-transition_started,CPassiveComm::Op::MAX,world.comm);
    const double rebuild=TimedAllreduce(stats.initialization_seconds+stats.seed_seconds,CPassiveComm::Op::MAX,world.comm);
    double warming=0;
    if(geometry_authority) {const auto cache=geometry_authority->GeometryStatsSnapshot();
      warming=TimedAllreduce(cache.scope_build_seconds/std::max<size_t>(1,cache.scope_builds)*cache.scope_entries,CPassiveComm::Op::MAX,world.comm);}
    const double predicted_cost=estimate_seconds+rebuild+warming+stats.ownership_seconds;
    const double predicted_gain=remaining*(1-1/std::max(1.,imbalance));
    stats.ownership_predicted_gain+=predicted_gain;stats.ownership_predicted_cost+=predicted_cost;
    const bool locally_eligible=options.phase_ownership==PhaseOwnership::DiagnosticAlways || (imbalance>1.25 && predicted_gain>2*predicted_cost &&
        (!options.maximum_seconds || 2*predicted_cost<options.maximum_seconds-wall));
    // Local elapsed/cost estimates must not split participation in collective repartition.
    const bool proceed=!world.maximum(!locally_eligible);
    if(options.timings)std::cout<<"NATIVE3D_PHASE_OWNERSHIP rank="<<world.rank<<" quality="<<quality<<" evaluate=1 migrate="<<proceed
        <<" predicted_imbalance="<<imbalance<<" predicted_gain_seconds="<<predicted_gain<<" predicted_cost_seconds="<<predicted_cost
        <<" estimate_seconds="<<estimate_seconds<<" rebuild_allowance="<<rebuild<<" warming_allowance="<<warming<<" uncertainty_factor=2"<<'\n';
    if(!proceed){stats.ownership_seconds+=world.seconds()-transition_started;return true;}
    if (options.timings) ReportOwnershipMemory(world, "before");
    Owned pending;std::vector<Id> pending_initial;std::unique_ptr<Directory> pending_directory;
    Selection pending_selection(coarsening,repairing,geometry,stats,options.timings,options.surface_tolerance,options.wall_heights,bidirectional,bool(surface_target), &wall_counters);
    pending_selection.split_lanes=selection.split_lanes;pending_selection.lane=selection.lane;
    pending_selection.size_repairs=selection.size_repairs;pending_selection.geometry_repairs=selection.geometry_repairs;
    pending_selection.track_repairs=selection.track_repairs;pending_selection.repair_event=selection.repair_event;
    pending_selection.track_splits=selection.track_splits;pending_selection.repair_epoch=selection.repair_epoch;
    pending_selection.census_started=selection.census_started;
    pending_selection.progress_consistent=selection.progress_consistent;
    try {pending=working;pending_directory=std::make_unique<Directory>(world,true,geometry.Parameters());}
    catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    PartitionStats partition;
    const auto baseline=transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),scratch);
    if(!within_time())return false;
    const bool partitioned=Repartition(world,pending,weights,world.size,partition,result.reason,options.memory_ceiling,baseline,geometric,quality_weights);
    stats.maximum_work_bytes=std::max(stats.maximum_work_bytes,partition.maximum_native_bytes);
    if(!partitioned || !within_time())return false;
    // Stage exact per-cell census certificates with their cells. Mathematical cache identity is
    // retained; no geometry query, target recomposition or CFD projection occurs during migration.
    std::vector<std::vector<Selection::CachedRow>> outgoing;
    try {
      outgoing.resize(world.size);size_t slot=0;
      for(const auto& row:working) {
        const auto destination=partition.destinations.at(slot++);
        const auto found=selection.cells.find(row.first);
        if(found==selection.cells.end()) {
          if(surface_target&&!quality&&!selection.RequestedWall(row.second))continue;
          throw std::logic_error("Phase migration lacks a required cached row.");
        }
        Selection::CachedRow record;record.id=row.first;record.state=found->second;
        for(unsigned i=0;i<6;++i)record.lengths[i]=selection.edges.at(record.state.edges[i]).measure.length;
        if(quality)selection.SaveRepairState(record);
        outgoing.at(destination).push_back(std::move(record));
      }
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    bool admitted=false;
    const auto records=world.exchange(outgoing,&admitted,options.memory_ceiling,transfer_memory::Add(baseline,MapBytes(pending)));
    stats.maximum_work_bytes=std::max(stats.maximum_work_bytes,world.max_exchange_work_bytes);
    if(!admitted){result.reason="Native3D phase certificate migration exceeds memory admission.";return false;}
    const auto pending_bytes=transfer_memory::Add(MapBytes(pending),transfer_memory::Bytes(records),transfer_memory::Bytes(outgoing),
        transfer_memory::Mul(pending.size(),transfer_memory::Add(context.control.SelectionBound(context, quality),sizeof(Id))));
    if(!context.exchange.Admit(context, transfer_memory::Add(scratch,pending_bytes)))return false;
    if(!within_time())return false;
    const bool built=pending_directory->Build(pending,result.reason,options.memory_ceiling,transfer_memory::Add(baseline,pending_bytes));
    stats.maximum_work_bytes=std::max(stats.maximum_work_bytes,pending_directory->Statistics().maximum_work_bytes);
    if(!built)return false;
    try {
      pending_initial.reserve(pending.size());
      for(const auto& row:pending)if(!surface_target||pending_selection.RequestedWall(row.second))pending_initial.push_back(row.first);
      for(const auto& record:records)pending_selection.Restore(pending.at(record.id),record,field_identity);
      if(surface_target&&!quality) {
        const auto count=pending_selection.SurfaceCensus(pending);
        if(!pending_selection.progress_consistent||!pending_selection.census_started||count[0]!=count[1])
          throw std::logic_error("Incomplete migrated surface demand census.");
      } else if(records.size()!=pending.size())throw std::logic_error("Incomplete migrated phase census.");
      if(quality)pending_selection.RestoreRepairState(records);
      else pending_selection.ChangePhase(false,pending,field_identity);
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    if (options.timings) ReportOwnershipMemory(world, "staged", pending_bytes,
        transfer_memory::Bytes(outgoing), transfer_memory::Bytes(records));
    if(!within_time() || !observe_progress("ownership_staged"))return false;
    // No private transaction survives this swap; required features retain their inherited service history.
    context.exchange.RetireDirectory(directory->Statistics());working.swap(pending);directory.swap(pending_directory);selection.SwapState(pending_selection);
    EngineReports::ResetFixedMetricCells(context);
    inactive_blocked_edges.clear();inactive_blocked_links=0;length_blocks_dirty={{false,false}};
    retired_edges.clear();campaign_edges.clear();
    initial.swap(pending_initial);seed_slot=initial.size();
    construction_claims=bidirectional&&!quality;
    if(construction_claims)directory->BeginConstructionPass();
    ++stats.ownership_changes;stats.ownership_moved_cells+=partition.moved_cells;
    stats.maximum_owned=std::max(stats.maximum_owned,working.size());
    const auto seconds=world.seconds()-transition_started;stats.ownership_seconds+=seconds;
    if(options.timings)std::cout<<"NATIVE3D_PHASE_OWNERSHIP rank="<<world.rank<<" quality="<<quality<<" committed=1 moved_cells="<<partition.moved_cells
        <<" total_seconds="<<seconds<<" partition_seconds="<<partition.total_seconds<<" directory_build_seconds="<<directory->Statistics().build_seconds
        <<" work_before="<<partition.work_before.at(world.rank)<<" work_after="<<partition.work_after.at(world.rank)
        <<" geometry_before="<<partition.geometry_before.at(world.rank)<<" geometry_after="<<partition.geometry_after.at(world.rank)
        <<" quality_debt_weight_before="<<partition.quality_debt_before.at(world.rank)<<" quality_debt_weight_after="<<partition.quality_debt_after.at(world.rank)
        <<" directory_peak_bytes="<<directory->Statistics().maximum_work_bytes
        <<" cells="<<working.size()<<" transition_peak_bytes="<<stats.maximum_work_bytes<<'\n';
    if (options.timings) ReportOwnershipMemory(world, "committed", pending_bytes,
        transfer_memory::Bytes(outgoing), transfer_memory::Bytes(records));
    return !quality||observe_progress("ownership_committed");
  };
  auto begin_length_generation=[&](bool collapse) {
    if(!context.exchange.Admit(context, transfer_memory::Add(transfer_memory::Mul(working.size(),context.control.SelectionBound(context, false)),
        transfer_memory::Mul(transfer_memory::Mul(collapse?12:6,working.size()),sizeof(Edge)+4*sizeof(void*)))))return false;
    CLocalFailure failure;
    try {
      selection.lane=Selection::Lane::Surface;construction_claims=true;
      stats.split_lane=collapse?0:1;
      if(!collapse){stats.split_generation=stats.length_split_passes+1;selection.RefreshHistory(true);}
      directory->BeginConstructionPass();context.queues.LengthDirection(context, collapse);selection.ChangePhase(false,working,field_identity);
    }catch(const std::exception& error){failure.Set(2,0,error.what());}
    if(!context.exchange.Vote(context, failure))return false;
    construction_generation_changed=false;phase_start_round=stats.rounds;
    progress_at_window=stats.size_progress+stats.quality_progress+stats.cell_removals+stats.geometry_progress;
    attempted_at_window=stats.attempted;deferred_at_window=stats.length_pass_deferred;
    return true;
  };
  auto surface_ready=[&]() {
    // Known debt already proves unreadiness; scan coverage only at a possible readiness boundary.
    return !world.maximum(selection.construction_invalid!=0 || !scope_census_complete());
  };
  auto enter_phase=[&](Phase next,bool refine_geometry=false) {
    if(surface_target && next==Phase::Improvement) {
      if(surface_ready()){result.surface_prepared=true;result.reason.clear();return true;}
      // Use the existing repair service without enabling shape measurement or its optimizer.
      repairing=true;context.queues.LengthDirection(context, false);directory->EndConstructionPass();construction_claims=false;
      CLocalFailure failure;
      try {selection.ChangePhase(true,working,field_identity);}
      catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure))return false;
      phase_start_round=stats.rounds;
      progress_at_window=stats.size_progress+stats.cell_removals+stats.geometry_progress;
      attempted_at_window=stats.attempted;deferred_at_window=stats.length_pass_deferred;
      return observe_progress("surface_repair_entry");
    }
    metric_cleanup=false;
    if(bidirectional) {
      construction_claims=next==Phase::Construction;stats.split_lane=0;
      if(next==Phase::Construction) {
        generation_window_count=0;selection.edge_history.clear();
        if(world.maximum(improvement_changed))length_blocks_dirty={{true,true}};
        if(!refine_geometry)directory->BeginConstructionPass();
      } else directory->EndConstructionPass();
      if(!refine_geometry)context.queues.LengthDirection(context, next==Phase::Construction);
    }
    if(phase==Phase::Construction && !construction_entry_reported) {
      if(!observe_progress("construction_entry"))return false;
      construction_entry_reported=true;
    }
    construction_handoff_progress=next==Phase::Improvement && world.maximum(construction_changed);
    if(next==Phase::Construction){construction_changed=false;construction_generation_changed=false;}
    phase=next;repairing=next==Phase::Improvement;improvement_changed=false;phase_start_round=stats.rounds;
    progress_at_window=stats.size_progress+stats.quality_progress+stats.cell_removals+stats.geometry_progress;
    attempted_at_window=stats.attempted;deferred_at_window=stats.length_pass_deferred;
    if(repairing)++stats.quality_stages;else ++stats.construction_returns;
    if(!context.exchange.Admit(context, transfer_memory::Add(transfer_memory::Mul(working.size(),sizeof(Id)),
        transfer_memory::Mul(working.size(),context.control.SelectionBound(context, repairing)))))return false;
    if(refine_geometry && !begin_length_generation(false))return false;
    CLocalFailure failure;
    try {
      if(!refine_geometry)selection.ChangePhase(repairing,working,field_identity);
      initial.clear();initial.reserve(working.size());
      for(const auto& row:working) {const auto found=selection.cells.find(row.first);
        if(found==selection.cells.end() || (repairing && (!found->second.shape_measured ||
            (!options.wall_heights.empty() && !found->second.debt.height_measured))))initial.push_back(row.first);}
      seed_slot=0;
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    // A phase census has no enclosing update timer to debit for donor imports.
    const bool measured=measure(initial,false,nullptr);retired_edges.clear();
    if(!measured)return false;seed_slot=initial.size();
    if(refine_geometry&&!composition&&options.wall_heights.empty()&&geometry.EntityGeometry()) {
      if(!context.exchange.Admit(context, selection.GeometryPriorityBytes()))return false;
      CLocalFailure priority_failure;
      try{selection.PrioritizeGeometrySplits(started,options.maximum_seconds);}
      catch(const std::exception& e){priority_failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, priority_failure))return false;
    }
    if(!repairing)construction_entry_reported=true;
    if(repairing && !phase_ownership(true))return false;
    return observe_progress(repairing?"quality_entry":"construction_entry");
  };
  auto discard_checkpoint=[&]() {
    if(checkpoint.directory)context.exchange.RetireDirectory(checkpoint.directory->Statistics());
    checkpoint.directory.reset();checkpoint.parameters.reset();
    Owned().swap(checkpoint.cells);decltype(checkpoint.blocked)().swap(checkpoint.blocked);
    std::set<Edge>().swap(checkpoint.edges);std::set<Edge>().swap(checkpoint.attempted);
    std::set<Id>().swap(checkpoint.changed);checkpoint.blocked_links=0;
    checkpoint.valid=checkpoint.trial=false;
  };
  auto capture_checkpoint=[&]() {
    // This call follows the complete fresh quality census, including measured strict height.
    // No mutation intervenes; no initial/construction/partial state is presumed certified.
    CLocalFailure failure;
    const auto extra=transfer_memory::Add(MapBytes(working),directory->ResidentBytes(),
        private_parameters ? private_parameters->ResidentBytes() : 0,MapBytes(selection.blocked_edges),
        transfer_memory::Mul(selection.blocked_links,sizeof(Id)+4*sizeof(void*)),
        transfer_memory::Mul(transfer_memory::Mul(6,working.size()),sizeof(Edge)+4*sizeof(void*)));
    if(!context.exchange.Admit(context, extra))return false;
    try {
      checkpoint.cells=working;checkpoint.blocked=selection.blocked_edges;checkpoint.blocked_links=selection.blocked_links;
      for(const auto& row:working)for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j) {
        Edge edge{row.second.cell.v[i].id,row.second.cell.v[j].id};std::sort(edge.begin(),edge.end());checkpoint.edges.insert(edge);
      }
      if(private_parameters)checkpoint.parameters=std::make_unique<BoundaryParameterState>(*private_parameters);
      checkpoint.directory=std::make_unique<Directory>(world,true,geometry.Parameters());
    }catch(const std::exception& e){failure.Set(3,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    // Prebuild while both directories see the checkpoint parameter contents. This dormant
    // directory is never queried during the speculative trial; rollback needs no allocation.
    if(!checkpoint.directory->Build(checkpoint.cells,result.reason,options.memory_ceiling,
        transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes())))return false;
    checkpoint.global_cells=TimedAllreduce(working.size(),CPassiveComm::Op::SUM,world.comm);
    checkpoint.collapses=result.collapses.size();checkpoint.splits=result.splits.size();
    checkpoint.valid=true;checkpoint.trial=false;
    ++stats.coarsen_checkpoints;return true;
  };
  auto rollback_checkpoint=[&]() {
    static_assert(std::is_nothrow_swappable<BoundaryParameterState>::value,
        "Private checkpoint parameter contents must restore without allocation.");
    CLocalFailure failure;size_t retired=0;
    if(!checkpoint.valid || !checkpoint.directory || checkpoint.collapses>result.collapses.size() || checkpoint.splits>result.splits.size())
      failure.Set(1,0,"Native coarsening rollback lacks its complete checkpoint.");
    if(bool(private_parameters)!=bool(checkpoint.parameters) || (private_parameters &&
        private_parameters->Authority().get()!=checkpoint.parameters->Authority().get()))
      failure.Set(1,0,"Native coarsening rollback changes immutable geometry authority.");
    if(!context.exchange.Vote(context, failure))return false;
    if(!context.exchange.Admit(context, transfer_memory::Mul(checkpoint.attempted.size(),2*(sizeof(Edge)+8*sizeof(void*)))))return false;
    try {
      for(const auto& edge:checkpoint.attempted) {
        auto key=edge;std::sort(key.begin(),key.end());
        if(!checkpoint.edges.count(key))continue; // Descendants are absent after rollback.
        const bool inserted=checkpoint.blocked[edge[1]].insert(edge[0]).second;
        checkpoint.blocked_links+=inserted;retired+=inserted;
      }
    }catch(const std::exception& e){failure.Set(3,0,e.what());}
    if(!context.exchange.Vote(context, failure))return false;
    if(!world.maximum(retired!=0)) {
      result.reason="Native coarsening trial made no net reduction and retired no new checkpoint obligation.";
      return false;
    }
    // All proposal/import/private-parameter scopes have ended at this phase boundary. Restore
    // local ownership and exact identities together, leaving IDs/work/deadline/service epochs monotone.
    if(private_parameters)std::swap(*private_parameters,*checkpoint.parameters);
    working.swap(checkpoint.cells);directory.swap(checkpoint.directory);
    selection.blocked_edges.swap(checkpoint.blocked);std::swap(selection.blocked_links,checkpoint.blocked_links);
    stats.coarsen_rolled_back_collapses+=result.collapses.size()-checkpoint.collapses;
    result.collapses.resize(checkpoint.collapses);result.splits.resize(checkpoint.splits);
    ++stats.coarsen_rolled_back_passes;stats.coarsen_retired_directions+=retired;
    stats.coarsen_restored_cells+=working.size();
    discard_checkpoint();
    selection.Reset(true);retired_edges.clear();campaign_edges.clear();
    construction_changed=construction_handoff_progress=improvement_changed=false;
    // A strict checkpoint is not permission to return a stale census or to forgive a budget exit.
    return enter_phase(Phase::Improvement);
  };
  if(bidirectional)directory->BeginConstructionPass();
  if(!context.exchange.Admit(context, transfer_memory::Mul(transfer_memory::Mul(coarsening ? 12 : 6,working.size()),sizeof(Edge)+4*sizeof(void*))))return finish();
  {
    CLocalFailure failure;
    try{selection.SeedFrontier(working);}catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(!context.exchange.Vote(context, failure))return finish();
  }
  // Discover required surface work before optional collapses, without delaying a known deficit for the full census.
  do {
    ready=seed_next();
    if (!ready) return finish();
  } while(surface_target && !world.maximum(selection.construction_invalid!=0) && world.maximum(seed_slot<initial.size()));
  for (RoundState round_state;;) {
    auto& round = round_state.round;
    std::optional<SU2NativeTiming3D::PhaseScope> phase_scope;
    if (options.timings)
      phase_scope.emplace(phase == Phase::Improvement ? SU2NativeTiming3D::Phase::Quality
                          : surface_target            ? SU2NativeTiming3D::Phase::Surface
                                                      : SU2NativeTiming3D::Phase::Construction);
    if(surface_target && (result.surface_prepared || (repairing && surface_ready()))) {
      if(world.maximum(stats.global_work>stats.work_limit)) {
        result.surface_prepared=false;stats.stop=EngineStop::WorkBudget;
        result.reason="Surface preparation exhausted work before complete readiness.";return finish();
      }
      if(options.maximum_seconds&&world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
        result.surface_prepared=false;stats.stop=EngineStop::TimeBudget;
        result.reason="Surface preparation exhausted elapsed time before complete readiness.";return finish();
      }
      result.surface_prepared=true;result.reason.clear();return finish();
    }
    ContextValue timed_lane_lifetime(
        round_state.timed_lane,
        bidirectional && phase == Phase::Construction && !repairing && !coarsening ? stats.split_lane : 0);
    const unsigned& timed_lane = timed_lane_lifetime.Get();
    ContextValue untimed_lane_lifetime(round_state.untimed_lane, 0);
    double& untimed_lane = untimed_lane_lifetime.Get();
    Timer lane_timer(timed_lane==1?stats.surface_seconds:timed_lane==2?stats.interior_seconds:untimed_lane,
        options.timings&&timed_lane!=0);
    ContextValue choice_lifetime(round_state.choice);
    Choice& choice = choice_lifetime.Get();
    ContextValue complete_lifetime(round_state.complete, false);
    bool& complete = complete_lifetime.Get();
    ContextValue any_lifetime(round_state.any, false);
    bool& any = any_lifetime.Get();
    ContextValue bad_field_lifetime(round_state.bad_field, false);
    bool& bad_field = bad_field_lifetime.Get();
    ContextValue refill_lifetime(round_state.refill, false);
    bool& refill = refill_lifetime.Get();
    auto pick=[&]() {
      if (!coarsening) { choice=selection.Best(repairing); any=world.maximum(choice.active); return true; }
      CLocalFailure failure;
      try {
        choice=selection.Best(repairing);
        while (!repairing && (!bad_field||bidirectional) && selection.FilterCollapse(choice,working)) choice=selection.Best(false);
      } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
      if (!(ready=context.exchange.Vote(context, failure))) return false;
      any=world.maximum(choice.active); return true;
    };
    {
      Timer timer(stats.selection_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
      ++stats.selections;
      // The surface cursor covers only demand owners. Complete versioned coverage is checked at quiescent boundaries.
      const bool pending_census=surface_target ? seed_slot<initial.size()||!selection.progress_consistent : selection.cells.size()!=working.size();
      int dirty=world.maximum(selection.invalid ? 2 :
          (pending_census || (coarsening && !selection.queue.empty()) ? 1 : 0));
      bad_field=dirty==2;
      if (coarsening && !repairing && (!bad_field||bidirectional) && !selection.prune_collapses) {
        // Joint construction filters necessary validity constraints even while target debt remains.
        CLocalFailure failure;
        try { selection.EnableCollapseFilter(); } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        ready=context.exchange.Vote(context, failure);
        if (ready) dirty=world.maximum(pending_census || !selection.queue.empty());
      }
      if (ready) {
        complete=dirty==0;
        pick();
        if (ready && coarsening && !repairing && !bad_field && !any)
          complete=!world.maximum(pending_census || !selection.queue.empty());
        if(ready && !complete && !any)refill=world.maximum(seed_slot<initial.size());
      }
    }
    if (!ready) return finish();
    if(surface_target && phase==Phase::Construction && any &&
        world.maximum(!choice.active && seed_slot<initial.size())) {
      // One idle-rank census batch must not drain ahead of the active round.
      if(!seed_next(!choice.active))return finish();
      bad_field=world.maximum(selection.invalid!=0);
      if(!pick())return finish();
      complete=!world.maximum(selection.invalid!=0 || seed_slot<initial.size() ||
          !selection.progress_consistent || (coarsening&&!selection.queue.empty()));
      refill=!complete&&!any&&world.maximum(seed_slot<initial.size());
    }
    if(options.maximum_seconds && world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
      stats.stop=EngineStop::TimeBudget;result.reason="Native 3D kernel elapsed-time budget exhausted; feasibility is undetermined.";
      return finish();
    }
    if(surface_target && phase==Phase::Construction && !repairing && coarsening &&
        world.maximum(selection.construction_invalid!=0)) {
      // Required surface debt must not wait for an exhaustive optional short-edge sweep.
      if(!begin_length_generation(false))return finish();
      ++stats.surface_required_handoffs;
      if(!observe_progress("surface_required_entry"))return finish();
      continue;
    }
    // Before its first strict checkpoint, coarsening must finish the edge-only entry census.
    // A size/geometry-valid input can then establish its checkpoint in the quality phase before
    // destructive removals; invalid inputs still use construction until a strict closure exists.
    if(standalone_coarsening && !checkpoint.valid && phase==Phase::Construction && !repairing &&
        world.maximum(selection.cells.size()!=working.size()) && world.maximum(seed_slot<initial.size()))refill=true;
    if(refill) {ready=seed_next();if(!ready)return finish();continue;}
    if(standalone_coarsening && !checkpoint.valid && phase==Phase::Construction && !repairing &&
        !world.maximum(selection.cells.size()!=working.size() || selection.construction_invalid!=0)) {
      if(!enter_phase(Phase::Improvement))return finish();
      continue;
    }
    // Amortize the strict census over a useful repair pass before retrying outstanding construction.
    ContextValue clean_quality_lifetime(
        round_state.clean_quality,
        !metric_cleanup && phase == Phase::Improvement &&
            !world.maximum(selection.quality_invalid != 0 || selection.unmeasured_shape != 0 ||
                           selection.cells.size() != working.size()));
    const bool& clean_quality = clean_quality_lifetime.Get();
    if(metric_cleanup && !any) {
      if(world.maximum(!selection.Progress(working.size()).complete)) {
        result.reason="Native3D metric cleanup lost its complete improvement census.";return finish();
      }
      ++stats.length_collapse_passes;
      if(!observe_progress("metric_cleanup_exit") || !enter_phase(Phase::Improvement))return finish();
      continue;
    }
    // Close shape/height first, then give existing topology repair the residual length debt.
    if(bidirectional && clean_quality && !selection.size_repairs && world.maximum(selection.debt.size_bad_cells!=0)) {
      if(!context.exchange.Admit(context, transfer_memory::Mul(working.size(),context.control.SelectionBound(context, true))))return finish();
      CLocalFailure failure;
      try{selection.EnableSizeRepairs(working);}catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure) || !observe_progress("size_repair_entry"))return finish();
      continue;
    }
    // Geometry-only demand gets its own pass after shape, height and size have closed.
    if(bidirectional && clean_quality && !selection.geometry_repairs &&
        !world.maximum(selection.debt.size_bad_cells!=0) && world.maximum(selection.construction_invalid!=0)) {
      if(!context.exchange.Admit(context, transfer_memory::Mul(working.size(),context.control.SelectionBound(context, true))))return finish();
      CLocalFailure failure;
      try{selection.EnableGeometryRepairs(working);}catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure) || !observe_progress("geometry_repair_entry"))return finish();
      continue;
    }
    if(standalone_coarsening && phase==Phase::Improvement && checkpoint.valid && !any && !clean_quality &&
        !world.maximum(selection.cells.size()!=working.size()) && world.maximum(checkpoint.trial)) {
      if(stats.global_work>=stats.work_limit) {
        stats.stop=EngineStop::WorkBudget;result.reason="Native coarsening quality closure exhausted its work budget.";return finish();
      }
      if(!rollback_checkpoint())return finish();
      continue;
    }
    if(standalone_coarsening && clean_quality && !world.maximum(selection.construction_invalid!=0)) {
      if(checkpoint.valid && world.maximum(checkpoint.trial)) {
        const size_t cells=TimedAllreduce(working.size(),CPassiveComm::Op::SUM,world.comm);
        if(cells>=checkpoint.global_cells) {
          if(!rollback_checkpoint())return finish();
          continue;
        }
        ++stats.coarsen_committed_passes;
        discard_checkpoint();
      }
      if(!world.maximum(selection.HasCoarseningDemand())) {
        result.valid=true;result.reason.clear();return finish();
      }
      if(!checkpoint.valid) {
        if(!capture_checkpoint() || !enter_phase(Phase::Construction))return finish();
        continue;
      }
    }
    if(!metric_cleanup && phase==Phase::Improvement && (world.maximum(improvement_changed) || (construction_handoff_progress && clean_quality)) &&
        (standalone_coarsening || world.maximum(selection.construction_invalid!=0)) &&
        ((!world.maximum(selection.quality_invalid!=0) && !selection.size_repairs && !selection.geometry_repairs) || !any)) {
      const auto progress=selection.Progress(working.size());
      // An exhausted shape pass needs its residual surface rebuilt before another global coarsening sweep.
      const bool refine_geometry=bidirectional &&
          !world.maximum(!progress.complete || progress.size_bad_cells || progress.height_bad_cells || progress.height_unresolved_cells) &&
          world.maximum(progress.geometry_bad_cells!=0);
      if(!observe_progress("quality_exit") || !enter_phase(Phase::Construction,refine_geometry))return finish();
      continue;
    }
    if(bidirectional&&phase==Phase::Construction&&!repairing&&!coarsening&&!any&&selection.lane==Selection::Lane::Surface&&
        !world.maximum(!scope_census_complete())) {
      if(!generation_census()||!observe_progress("split_surface_exit"))return finish();
      // Interior publications can reopen surface demand after the full-vertex claims end.
      selection.geometry_split_priorities.clear();selection.geometry_priority_mode=false;
      directory->EndConstructionPass();construction_claims=false;selection.lane=Selection::Lane::Interior;stats.split_lane=2;
      if(!observe_progress("split_interior_entry"))return finish();
      continue;
    }
    if(bidirectional&&phase==Phase::Construction&&!repairing&&!coarsening&&!any&&selection.lane==Selection::Lane::Interior&&
        world.maximum(!selection.surface_queue.empty()||!selection.geometry_queue.empty())) {
      // Interior publications may reveal/reopen entry-edge surface demand. Drain it before ending
      // the finite generation; newly created edges still cannot enter its immutable frontier.
      if(!generation_census()||!observe_progress("split_interior_exit"))return finish();
      directory->BeginConstructionPass();construction_claims=true;selection.lane=Selection::Lane::Surface;stats.split_lane=1;
      if(!observe_progress("split_surface_resume"))return finish();
      continue;
    }
    if(bidirectional && phase==Phase::Construction && !repairing && !any &&
        !world.maximum(!scope_census_complete())) {
      const bool productive=world.maximum(construction_generation_changed);
      if(!generation_census())return finish();
      const auto current_debt=generation_debt();bool progressing=true;
      if(coarsening){generation_window_count=1;generation_window[0]=current_debt;}
      else {
        if(generation_window_count==generation_window.size()) {
          std::move(generation_window.begin()+1,generation_window.end(),generation_window.begin());--generation_window_count;
        }
        generation_window[generation_window_count++]=current_debt;
        if(generation_window_count==generation_window.size()) {
          const auto& before=generation_window.front();
          auto fell=[](double old,double now){return now<old-std::max(1e-12,std::abs(old)*1e-6);};
          progressing=fell(before.edges,current_debt.edges)||fell(before.maximum,current_debt.maximum)||
              (before.geometry_complete&&current_debt.geometry_complete&&fell(before.geometry,current_debt.geometry));
        }
      }
      if(productive)length_blocks_dirty={{true,true}};
      if(coarsening)++stats.length_collapse_passes;else ++stats.length_split_passes;
      if(options.timings) {
        const auto progress=selection.Progress(working.size());size_t short_edges=0,long_edges=0;
        long double minimum=INFINITY,maximum=0;
        for(const auto& edge:selection.edges){const auto length=edge.second.measure.length;
          short_edges+=length<CoarseningMetricEdge;long_edges+=length>MaximumMetricEdge;
          minimum=std::min(minimum,length);maximum=std::max(maximum,length);}
        std::cout<<std::setprecision(17)<<"NATIVE3D_LENGTH rank="<<world.rank<<" pass="<<(coarsening?"collapse":"split")
          <<" cells="<<working.size()<<" local_edges="<<selection.edges.size()<<" short_local_edges="<<short_edges
          <<" long_local_edges="<<long_edges<<" minimum_length="<<(selection.edges.empty()?0:minimum)
          <<" maximum_length="<<maximum<<" size_hinge_incidence="<<progress.size_hinge_squared
          <<" geometry_bad_cells="<<progress.geometry_bad_cells<<" size_bad_cells="<<progress.size_bad_cells
          <<" q_measured_cells="<<progress.q_measured_cells<<" j_measured_cells="<<progress.j_measured_cells
          <<" construction_stall_handoffs="<<stats.construction_stall_handoffs<<" maximum_parallel_split_commits="<<stats.maximum_parallel_split_commits
          <<" split_accepted="<<stats.length_splits<<" collapse_accepted="<<stats.length_collapses
          <<" atlas_work="<<atlas_budget.work<<" admitted_peak_bytes="<<stats.maximum_work_bytes
          <<" elapsed="<<std::chrono::duration<double>(Clock::now()-started).count()<<'\n';
      }
      if(!observe_progress(coarsening?"length_collapse_exit":"length_split_exit"))return finish();
      if(!coarsening) {
        // Descendant size demand stays in construction. Once size closes, give shape/height
        // improvement a turn before more geometry-only splitting; residual geometry can return here.
        const bool size_demand=world.maximum(selection.debt.size_bad_cells!=0);
        if(productive && progressing && size_demand) {
          if(stats.global_work>=stats.work_limit){stats.stop=EngineStop::WorkBudget;
            result.reason="Native3D construction generation exhausted global work; feasibility is undetermined.";return finish();}
          if(!begin_length_generation(false))return finish();
          continue;
        }
        if(productive&&!progressing)++stats.construction_stall_handoffs;
        if(!enter_phase(Phase::Improvement))return finish();
      } else {
        // The major direction boundary is quiescent; no repartition is evaluated at lane/generation switches.
        context.queues.LengthDirection(context, false);directory->EndConstructionPass();
        if(!phase_ownership(false) || !begin_length_generation(false))return finish();
      }
      continue;
    }
    if(!bidirectional && !coarsening && phase==Phase::Construction && !repairing && !any) {
      // New edges belong to the next finite generation; productive construction need not remeasure quality first.
      const bool census=world.maximum(!selection.Progress(working.size()).census_complete)==0;
      const bool demanded=world.maximum(selection.construction_invalid!=0);
      const bool productive=world.maximum(construction_generation_changed);
      if(census && demanded && productive) {
        if(stats.global_work>=stats.work_limit){stats.stop=EngineStop::WorkBudget;
          result.reason="Native3D construction generation exhausted global work; feasibility is undetermined.";return finish();}
        if(!context.exchange.Admit(context, transfer_memory::Mul(working.size(),context.control.SelectionBound(context, false))))return finish();
        CLocalFailure failure;
        try{selection.ChangePhase(false,working,field_identity);}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return finish();
        construction_generation_changed=false;
        continue;
      }
    }
    if(!bidirectional && phase==Phase::Construction && !repairing && (complete || (!any && !world.maximum(selection.cells.size()!=working.size())))) {
      if(!enter_phase(Phase::Improvement))return finish();
      continue;
    }
    {
      Timer timer(stats.selection_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
      if (options.maximum_seconds && world.maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
        stats.stop=EngineStop::TimeBudget; result.reason="Native 3D kernel elapsed-time budget exhausted; feasibility is undetermined.";
        return finish();
      }
    }
    // One finite, shape-preserving short-edge opportunity can change a stalled repair's neighbors.
    // A mesh that already satisfies every gate needs no optional cleanup before acceptance.
    if(bidirectional && !metric_cleanup && !metric_cleanup_tried && phase==Phase::Improvement && !any && !clean_quality) {
      const auto progress=selection.Progress(working.size());
      if(!world.maximum(!progress.complete || progress.geometry_bad_cells || progress.size_bad_cells ||
          progress.height_bad_cells || progress.height_unresolved_cells)) {
        bool short_edges=false;for(const auto& edge:selection.edges)short_edges|=edge.second.measure.length<CoarseningMetricEdge;
        if(world.maximum(short_edges)) {
          if(!context.exchange.Admit(context, transfer_memory::Mul(transfer_memory::Mul(12,working.size()),sizeof(Edge)+4*sizeof(void*))))return finish();
          CLocalFailure failure;
          try {
            directory->BeginConstructionPass();construction_claims=true;context.queues.LengthDirection(context, true);
            selection.ChangePhase(false,working,field_identity);
          }catch(const std::exception& e){failure.Set(2,0,e.what());}
          if(!context.exchange.Vote(context, failure))return finish();
          metric_cleanup=metric_cleanup_tried=true;repairing=false;phase_start_round=stats.rounds;
          progress_at_window=stats.size_progress+stats.quality_progress+stats.cell_removals+stats.geometry_progress;
          attempted_at_window=stats.attempted;deferred_at_window=stats.length_pass_deferred;
          if(!observe_progress("metric_cleanup_entry"))return finish();
          continue;
        }
      }
    }
    if (!metric_cleanup && complete && phase==Phase::Improvement && !world.maximum(selection.unmeasured_shape!=0 || selection.quality_invalid!=0 || selection.construction_invalid!=0)) {
      result.valid=true;result.reason.clear();return finish();
    }
    {
      Timer timer(stats.selection_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
      if (stats.rounds>phase_start_round && round && round%options.stagnation_window==0) {
        ++stats.progress_windows;
        const uint64_t progress=stats.size_progress+stats.quality_progress+stats.cell_removals+stats.geometry_progress;
        const bool mesh_progress=world.maximum(progress!=progress_at_window);
        const bool search_progress=world.maximum(stats.attempted!=attempted_at_window ||
            (bidirectional && stats.length_pass_deferred!=deferred_at_window));
        progress_at_window=progress; attempted_at_window=stats.attempted;deferred_at_window=stats.length_pass_deferred;
        // Valid coarsening may exhaust rejected directions without changing an already admissible mesh.
        if (!mesh_progress) ++stats.stagnant_windows;
        if (!mesh_progress && search_progress) ++stats.search_windows;
        if(!observe_progress("window"))return finish();
        if(!metric_cleanup&&phase==Phase::Improvement&&!phase_ownership(true))return finish();
        // Fresh rejected directions are finite search work even on invalid meshes; do not declare infeasibility early.
        if (!mesh_progress && !search_progress) {
          if(!bidirectional && phase==Phase::Construction && !repairing && !world.maximum(selection.cells.size()!=working.size())) {
            if(!enter_phase(Phase::Improvement))return finish();
            continue;
          }
          stats.stop=EngineStop::OperatorStagnation;
          result.reason="Native 3D admitted operators made no certified progress over the observation window; feasibility is undetermined.";
          return finish();
        }
      }
    }
    if (!any) {
      stats.stop=EngineStop::OperatorStagnation;
      CLocalFailure failure;
      if (selection.invalid || selection.cells.size()!=working.size()) failure.Set(1,0,"Native 3D adaptation stagnates: admitted operators cannot satisfy the frozen size/shape gates.");
      context.exchange.Vote(context, failure); return finish();
    }
    // A final census/phase transition consumes no additional operator round.
    if(options.maximum_rounds && round>=options.maximum_rounds)break;
    {
      Timer timer(stats.selection_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
      const size_t used=coarsening ? result.collapses.size() : result.splits.size();
      const size_t capacity=coarsening ? result.collapses.capacity() : result.splits.capacity();
      const size_t needed=transfer_memory::Add(used,options.candidate_batch);
      const size_t next=std::min<uint64_t>(stats.work_limit,std::max(needed,transfer_memory::Mul(capacity,2)));
      CLocalFailure failure;
      ready=context.exchange.Admit(context, !repairing && next>capacity ? transfer_memory::Mul(next,coarsening ? sizeof(Edge) : sizeof(SplitRecord)) : 0);
      if (ready && !repairing && next>capacity) {
        if (ready) try {
          if (coarsening) result.collapses.reserve(next); else result.splits.reserve(next);
        } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
      }
      // Every worker votes even if its history already has room.
      if (ready) ready=context.exchange.Vote(context, failure);
      if (!ready) return finish();
    }
    {
      CLocalFailure failure;
      if(selection.repair_epoch==UINT64_MAX)failure.Set(1,0,"Native repair service epoch overflows.");
      if(!context.exchange.Vote(context, failure))return finish();
      ++selection.repair_epoch;
    }
    ++stats.rounds;
    if(timed_lane==1)++stats.surface_rounds;else if(timed_lane==2)++stats.interior_rounds;
    ContextValue concurrent_lifetime(round_state.concurrent,
                                     (repairing || ((composition || curved || selection.split_lanes) && !coarsening) ||
                                      (bidirectional && coarsening)) &&
                                         options.candidate_batch > 1 && world.size > 1);
    const bool& concurrent = concurrent_lifetime.Get();
    stats.concurrent_rounds+=concurrent;
    // Repair uses one complete round snapshot, including the one-candidate correctness path.
    ContextValue batched_lifetime(
        round_state.batched,
        repairing || (options.candidate_batch > 1 && (!(selection.split_lanes && !coarsening) && !curved &&
                                                      !composition && (!coarsening || !bad_field))));
    const bool& batched = batched_lifetime.Get();
    ContextValue choices_lifetime(round_state.choices);
    std::vector<Choice>& choices = choices_lifetime.Get();
    ContextValue dependency_batch_lifetime(round_state.dependency_batch);
    DependencyBatch& dependency_batch = dependency_batch_lifetime.Get();
    ContextValue imported_batch_lifetime(round_state.imported_batch);
    ImportedBatch& imported_batch = imported_batch_lifetime.Get();
    ContextValue reserved_lifetime(round_state.reserved);
    ReservationBatch& reserved = reserved_lifetime.Get();
    ContextValue slots_lifetime(round_state.slots, 1);
    size_t& slots = slots_lifetime.Get();
    ContextValue planned_coarsening_lifetime(round_state.planned_coarsening,
                                             coarsening && !repairing && !curved && !composition && world.size > 1);
    const bool& planned_coarsening = planned_coarsening_lifetime.Get();
    // A complete star above the cavity bound blocks only its own proposal, as on every lookup path; changed
    // stars reactivate it. It is never published and never fails the event.
    ContextValue refused_candidates_lifetime(round_state.refused_candidates, 0);
    size_t& refused_candidates = refused_candidates_lifetime.Get();
    ContextValue refused_slots_lifetime(round_state.refused_slots, 0);
    size_t& refused_slots = refused_slots_lifetime.Get();
    ContextValue pass_deferred_candidates_lifetime(round_state.pass_deferred_candidates, 0);
    size_t& pass_deferred_candidates = pass_deferred_candidates_lifetime.Get();
    ContextValue refused_receipts_lifetime(round_state.refused_receipts,
                                           std::array<RepairReceipt, MaximumCandidateBatch>{});
    std::array<RepairReceipt, MaximumCandidateBatch>& refused_receipts = refused_receipts_lifetime.Get();
    ContextValue refused_receipt_count_lifetime(round_state.refused_receipt_count, 0);
    size_t& refused_receipt_count = refused_receipt_count_lifetime.Get();
    auto refuse=[&](const Choice& candidate,const Feature& feature,const std::string& why) {
      selection.Block(candidate.edge,candidate.feature,repairing);++stats.attempted;++stats.rejected;++stats.oversized_stars;
      wall_counters.PlanningRefusal();
      if(batched || (!repairing && planned_coarsening)) {
        if(refused_receipt_count==MaximumCandidateBatch)throw std::logic_error("Native refused frontier exceeds batch bound.");
        refused_receipts[refused_receipt_count++]={repairing ? feature : Feature{{candidate.edge[0],candidate.edge[1],0},2},false};
      }
      stats.last_rejected_feature=feature;++refused_candidates;
      last_rejection="feature "+std::to_string(feature.count)+":"+std::to_string(feature.vertices[0])+": "+why;
      EngineReports::RecordRejection(context, diagnostic_rejection_limit, feature,nullptr,nullptr,why);
    };
    // Every nonempty selected round admits work; at most batch*workers metadata frontiers per admitted round.
    auto plan_choices=[&]() {
      CLocalFailure failure;
      stats.batch_considered+=choices.size();
      if(stats.global_work==stats.work_limit) {
        stats.stop=EngineStop::WorkBudget;result.reason="Native 3D global proposal budget exhausted before admission; feasibility is undetermined.";
        return false;
      }
      if(planned_coarsening) {
        Timer timer(stats.planning_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
        std::vector<Feature> features;std::vector<size_t> selected;
        try {for(const auto& candidate:choices)features.push_back({{candidate.edge[1],0,0},1});}
        catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        dependency_batch=directory->PlanBatch(features,selected,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()));
        if(!dependency_batch.valid){result.reason=dependency_batch.reason;return false;}
        try {
          for(size_t i:dependency_batch.refused)refuse(choices.at(i),features.at(i),"Native 3D dependency star exceeds budget.");
          for(size_t i:dependency_batch.pass_deferred) {
            if(refused_receipt_count==MaximumCandidateBatch)throw std::logic_error("Native construction deferrals exceed frontier bound.");
            const auto edge=choices.at(i).edge;
            refused_receipts[refused_receipt_count++]={Feature{{edge[0],edge[1],0},2},false};
            ++pass_deferred_candidates;++stats.length_pass_deferred;
          }
          std::vector<Choice> planned;planned.reserve(selected.size());
          for(size_t i:selected)planned.push_back(choices.at(i));
          stats.batch_deferred+=choices.size()-planned.size()-dependency_batch.refused.size();choices.swap(planned);
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        if(world.maximum(refused_receipt_count!=0)) {
          if(!service_frontier({},false,false,&refused_receipts,refused_receipt_count))return false;
          refused_receipt_count=0;
        }
        if(!world.maximum(!choices.empty() || refused_candidates!=0 || pass_deferred_candidates!=0)){result.reason="Native 3D complete-star selection made no progress.";return false;}
      }
      return true;
    };
    if (batched) {
      // All retained metadata/payloads remain byte-admitted while each disjoint candidate uses the existing transaction.
      batch_bytes=transfer_memory::Add(transfer_memory::Mul(options.candidate_batch,
          sizeof(Choice)+sizeof(Feature)+sizeof(Dependencies)+sizeof(Imported)+2*sizeof(bool)+2*sizeof(size_t)),
          transfer_memory::Mul(transfer_memory::Mul(options.candidate_batch,MaximumCavityCells),
              sizeof(Dependency)+sizeof(OwnedCell)),
          transfer_memory::Mul(transfer_memory::Mul(8,options.candidate_batch*MaximumCavityCells),
              sizeof(Id)+4*sizeof(void*)));
      if (!context.exchange.Admit(context, 0)) return finish();
      CLocalFailure failure;
      size_t repair_slots=options.candidate_batch;
      if(repairing) {
        double local_debt=0;
        for(const auto& row:selection.repair_cell_severity)local_debt+=double(row.second);
        if(!std::isfinite(local_debt)||local_debt<0)failure.Set(1,0,"Invalid cached required repair debt.");
        if(!context.exchange.Vote(context, failure))return finish();
        const bool complete=!world.maximum(!selection.progress_consistent||selection.cells.size()!=working.size()||selection.unmeasured_shape!=0);
        const double total_debt=TimedAllreduce(local_debt,CPassiveComm::Op::SUM,world.comm);
        if(complete&&std::isfinite(total_debt)&&total_debt>0) {
          const double share=std::clamp(local_debt/total_debt*world.size,0.,1.);
          repair_slots=std::max<size_t>(1,size_t(std::ceil(options.candidate_batch*share)));
        }
      }
      {
        Timer timer(stats.selection_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
        try {
          bool oversized=false;
          choices=repairing ? selection.RepairBatch(working,repair_slots,oversized) :
              selection.Batch(working,options.candidate_batch);
        }
        catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        if (!(ready=context.exchange.Vote(context, failure))) return finish();
        if(!coalesce(choices))return finish();
        if(!plan_choices())return finish();
        slots=TimedAllreduce(choices.size(),CPassiveComm::Op::MAX,world.comm);
        ++stats.batch_rounds; stats.batch_candidates+=choices.size(); stats.proposed+=choices.size()+refused_candidates;
      }
      {
        Timer timer(stats.selection_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
        // Planned refusals are proposals too: they consume the same global work as serial oversized stars.
        const uint64_t proposed=TimedAllreduce(uint64_t(choices.size()+refused_candidates),CPassiveComm::Op::SUM,world.comm);
        if (proposed>stats.work_limit-stats.global_work) {
          stats.stop=EngineStop::WorkBudget; result.reason="Native 3D global proposal budget exhausted before admission; feasibility is undetermined.";
          return finish();
        }
        stats.global_work+=proposed;
      }
      {
        Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
        std::vector<Feature> features;
        try { for (const auto& candidate:choices) features.push_back(repairing ? candidate.feature :
            coarsening ? Feature{{candidate.edge[1],0,0},1} : Feature{{candidate.edge[0],candidate.edge[1],0},2}); }
        catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        if (!(ready=context.exchange.Vote(context, failure))) return finish();
        if(!planned_coarsening)
          dependency_batch=directory->LookupBatch(features,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()),repairing);
        if (!dependency_batch.valid) { result.reason=dependency_batch.reason; return finish(); }
        // A remote complete coordinate star may exceed the ordinary cavity bound. Retained
        // imports and footprint storage stay admitted across every subsequent private slot.
        size_t retained_cells=0;
        for(const auto& candidate:dependency_batch.candidates)
          retained_cells=transfer_memory::Add(retained_cells,candidate.cells.size());
        const auto ordinary_cells=transfer_memory::Mul(options.candidate_batch,MaximumCavityCells);
        if(retained_cells>ordinary_cells)batch_bytes=transfer_memory::Add(batch_bytes,
            transfer_memory::Mul(retained_cells-ordinary_cells,
                sizeof(Dependency)+sizeof(OwnedCell)+8*(sizeof(Id)+4*sizeof(void*))));
        if(!context.exchange.Admit(context, 0))return finish();
        imported_batch=directory->FetchBatch(dependency_batch,working,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()));
        if (!imported_batch.valid) { result.reason=imported_batch.reason; return finish(); }
        try {
          for (size_t i=0;i<imported_batch.candidates.size();++i) {
            const auto& candidate=imported_batch.candidates[i];
            if (candidate.valid) continue;
            const auto& star=dependency_batch.candidates.at(i);
            if (!star.valid && star.oversized) { refuse(choices.at(i),features.at(i),star.reason); ++refused_slots; }
            else failure.Set(1,0,candidate.reason);
          }
        } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        if (!(ready=context.exchange.Vote(context, failure))) return finish();
        if(repairing && curved) {
          const auto support_bytes=transfer_memory::Mul(transfer_memory::Mul(4,choices.size()),
              transfer_memory::Mul(MaximumCavityCells,sizeof(Dependency)+sizeof(OwnedCell)+8*(sizeof(Id)+4*sizeof(void*))));
          batch_bytes=transfer_memory::Add(batch_bytes,support_bytes,
              transfer_memory::Mul(retained_cells,sizeof(OwnedCell)+sizeof(Dependency)));
          if(!context.exchange.Admit(context, 0))return finish();
          std::vector<Feature> supports;std::vector<std::pair<size_t,size_t>> groups;
          try {
            for(size_t i=0;i<imported_batch.candidates.size();++i) {
              const auto& candidate=imported_batch.candidates[i];
              if(!candidate.valid || candidate.cells.size()>MaximumCavityCells)continue;
              const OwnedCell* core=nullptr;long double worst=-1;
              for(const auto& row:candidate.cells) {
                const auto cached=selection.cells.find(row.cell.id);
                if(cached==selection.cells.end() || !cached->second.geometry_invalid)continue;
                const auto physical=std::count_if(row.physical.begin(),row.physical.end(),[](const auto& f){return f.present;});
                if(selection.geometry_repairs ? physical==0 :
                    (!cached->second.shape_measured || cached->second.quality_valid || physical!=2))continue;
                const auto weight=selection.RepairWeight(cached->second);
                if(weight>worst || (weight==worst && core && row.cell.id<core->cell.id)){worst=weight;core=&row;}
              }
              if(!core)continue;
              groups.push_back({i,supports.size()});
              for(const auto& node:core->cell.v)supports.push_back({{node.id,0,0},1});
            }
          }catch(const std::exception& e){failure.Set(2,0,e.what());}
          if(!context.exchange.Vote(context, failure))return finish();
          if(world.maximum(!supports.empty())) {
            // Complete moved stars are fetched before the existing full-vertex-disjoint reservation.
            const auto extra=directory->LookupBatch(supports,options.memory_ceiling,
                transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()));
            if(!extra.valid){result.reason=extra.reason;return finish();}
            bool expanded=false;
            try {
              for(const auto& group:groups) {
                auto& original=dependency_batch.candidates.at(group.first);
                std::map<Id,Dependency> merged;for(const auto& row:original.cells)merged.emplace(row.cell,row);
                bool complete=true;
                for(size_t k=0;k<4;++k) {
                  const auto& star=extra.candidates.at(group.second+k);
                  if(!star.valid) {
                    if(!star.oversized)throw std::logic_error("Coupled boundary support lost a current vertex star.");
                    complete=false;continue;
                  }
                  for(const auto& row:star.cells) {
                    const auto prior=merged.emplace(row.cell,row);
                    if(!prior.second && (prior.first->second.owner!=row.owner || prior.first->second.version!=row.version))
                      throw std::logic_error("Coupled boundary support changed dependency ownership/version.");
                  }
                }
                if(!complete || merged.size()>MaximumCavityCells || merged.size()==original.cells.size())continue;
                original.cells.clear();for(const auto& row:merged)original.cells.push_back(row.second);
                original.coordinate_star={};expanded=true;
              }
            }catch(const std::exception& e){failure.Set(2,0,e.what());}
            if(!context.exchange.Vote(context, failure))return finish();
            if(world.maximum(expanded)) {
              auto complete=directory->FetchBatch(dependency_batch,working,options.memory_ceiling,
                  transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()));
              if(!complete.valid){result.reason=complete.reason;return finish();}
              imported_batch=std::move(complete);
            }
          }
        }
        if(world.maximum(refused_receipt_count!=0)) {
          if(!service_frontier({},false,false,&refused_receipts,refused_receipt_count))return finish();
          refused_receipt_count=0;
        }
      }
      {
        Timer timer(stats.reservation_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
        std::vector<unsigned> priorities;
        try {if(repairing)for(const auto& candidate:choices)priorities.push_back(candidate.reservation_priority);}
        catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return finish();
        reserved=directory->ReserveBatch(imported_batch,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()),priorities);
        if (!reserved.valid) { result.reason=reserved.reason; return finish(); }
        size_t winners=0;
        for (bool chosen:reserved.chosen) winners+=chosen;
        for(size_t i=0;i<reserved.pass_deferred.size();++i)if(reserved.pass_deferred[i]) {
          if(refused_receipt_count==MaximumCandidateBatch)throw std::logic_error("Native construction deferrals exceed frontier bound.");
          const auto edge=choices.at(i).edge;
          refused_receipts[refused_receipt_count++]={Feature{{edge[0],edge[1],0},2},false};
          ++pass_deferred_candidates;++stats.length_pass_deferred;
        }
        if(world.maximum(refused_receipt_count!=0)) {
          if(!service_frontier({},false,false,&refused_receipts,refused_receipt_count))return finish();
          refused_receipt_count=0;
        }
        stats.batch_reserved+=winners; stats.conflicts+=choices.size()-winners-refused_slots;
        if (!world.maximum(winners!=0 || refused_candidates!=0 || pass_deferred_candidates!=0)) { result.reason="Native 3D batch reservation made no progress."; return finish(); }
      }
    } else {
      Timer timer(stats.selection_seconds,options.timings, SU2NativeTiming3D::Operation::Scheduling);
      if((curved || composition) && !repairing && !concurrent) {
        // Single-proposal requests and coarsening retain their established serial ordering.
        if(composition && !curved && !repairing) {
          // Choose global metric priority before ownership; rank numbering must not decide the next edit.
          const double priority=choice.active ? double(selection.Priority(choice.measure.length)) : INFINITY;
          const double best=TimedAllreduce(priority,CPassiveComm::Op::MIN,world.comm);
          choice.active=choice.active && priority==best;
          const Id first=TimedAllreduce(choice.active ? choice.edge[0] : UINT64_MAX,CPassiveComm::Op::MIN,world.comm);
          choice.active=choice.active && choice.edge[0]==first;
          const Id second=TimedAllreduce(choice.active ? choice.edge[1] : UINT64_MAX,CPassiveComm::Op::MIN,world.comm);
          choice.active=choice.active && choice.edge[1]==second;
        }
        const int owner=TimedAllreduce(choice.active ? world.rank : world.size,CPassiveComm::Op::MIN,world.comm);
        choice.active=choice.active && world.rank==owner;
      }
      if(repairing || concurrent || (coarsening && !repairing && !curved && !composition && world.size>1)) {
        CLocalFailure failure;
        try {if(choice.active)choices.push_back(choice);}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure) || !coalesce(choices) || !plan_choices())return finish();
        choice=choices.empty()?Choice{}:choices.front();
      }
      stats.proposed+=choice.active;
      const uint64_t proposed=TimedAllreduce(uint64_t(choice.active),CPassiveComm::Op::SUM,world.comm);
      if (proposed>stats.work_limit-stats.global_work) {
        stats.stop=EngineStop::WorkBudget; result.reason="Native 3D global proposal budget exhausted before admission; feasibility is undetermined.";
        return finish();
      }
      stats.global_work+=proposed;
    }

    ContextValue repair_proposals_lifetime(round_state.repair_proposals);
    std::vector<RepairProposal>& repair_proposals = repair_proposals_lifetime.Get();
    ContextValue private_failure_lifetime(round_state.private_failure);
    CLocalFailure& private_failure = private_failure_lifetime.Get();
    ContextValue private_work_used_lifetime(round_state.private_work_used, 0);
    uint64_t& private_work_used = private_work_used_lifetime.Get();
    ContextValue private_work_reserved_lifetime(round_state.private_work_reserved, 0);
    uint64_t& private_work_reserved = private_work_reserved_lifetime.Get();
    ContextValue private_deadline_lifetime(round_state.private_deadline, false);
    bool& private_deadline = private_deadline_lifetime.Get();
    if(repairing) {
      size_t retained=transfer_memory::Mul(choices.size(),sizeof(RepairProposal)+1024);
      uint64_t eligible=0;
      for(size_t i=0;i<choices.size();++i)if(reserved.chosen.at(i)) {
        const auto& imported=imported_batch.candidates.at(i);
        const bool coordinate=imported.coordinate_star.count==1&&imported.cells.size()>MaximumCavityCells;
        eligible+=!coordinate;
        retained=transfer_memory::Add(retained,transfer_memory::Mul(std::max(MaximumReplacementCells,imported.cells.size()),16384));
      }
      batch_bytes=transfer_memory::Add(batch_bytes,retained);
      if(!context.exchange.Admit(context, 0))return finish();
      try {repair_proposals.resize(choices.size());}catch(const std::exception& e){private_failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, private_failure))return finish();
      eligible=TimedAllreduce(eligible,CPassiveComm::Op::SUM,world.comm);
      private_optimizer_allowance=eligible?std::min<uint64_t>(160,(stats.work_limit-stats.global_work)/eligible):0;
      private_work_reserved=eligible*private_optimizer_allowance;stats.global_work+=private_work_reserved;
    }
    ContextValue lane_slots_lifetime(round_state.lane_slots, std::array<lane_census::Slot, MaximumCandidateBatch>{});
    std::array<lane_census::Slot, MaximumCandidateBatch>& lane_slots = lane_slots_lifetime.Get();
    ContextValue private_started_lifetime(round_state.private_started, repairing ? Clock::now() : Clock::time_point{});
    const Clock::time_point& private_started = private_started_lifetime.Get();
    ContextValue private_collectives_lifetime(round_state.private_collectives,
                                              world.collective_calls + world.election_collective_calls);
    const uint64_t& private_collectives = private_collectives_lifetime.Get();
    for (SlotState slot_state;slot_state.slot<(repairing?choices.size():slots);++slot_state.slot) {
    size_t& slot = slot_state.slot;
    ContextValue dependencies_lifetime(slot_state.dependencies);
    Dependencies& dependencies = dependencies_lifetime.Get();
    ContextValue imported_lifetime(slot_state.imported);
    Imported& imported = imported_lifetime.Get();
    ContextValue chosen_lifetime(slot_state.chosen, false);
    bool& chosen = chosen_lifetime.Get();
    ContextValue pass_deferred_lifetime(slot_state.pass_deferred, false);
    bool& pass_deferred = pass_deferred_lifetime.Get();
    ContextValue collapse_corrected_lifetime(slot_state.collapse_corrected, false);
    bool& collapse_corrected = collapse_corrected_lifetime.Get();
    ContextValue collapse_apex_lifetime(slot_state.collapse_apex, 0);
    Id& collapse_apex = collapse_apex_lifetime.Get();
    ContextValue collapse_correction_refusal_lifetime(slot_state.collapse_correction_refusal);
    std::string& collapse_correction_refusal = collapse_correction_refusal_lifetime.Get();
    wall_diagnostics::Choice wall_choice(wall_counters);
    auto reserve_dependencies=[&](const Imported& rows,bool active,std::string& why,size_t ceiling,size_t caller,unsigned priority) {
      const bool selected=directory->Reserve(rows,active,why,ceiling,caller,priority);
      if(chosen && directory->PassDeferred())++stats.length_expansion_deferrals;
      pass_deferred=pass_deferred||directory->PassDeferred();return selected;
    };
    if (batched) {
      choice=slot<choices.size() ? choices[slot] : Choice{};
      wall_choice.Begin(choice.active);
      if (choice.active) {
        dependencies=std::move(dependency_batch.candidates[slot]);
        imported=std::move(imported_batch.candidates[slot]);
        chosen=reserved.chosen[slot];
      }
      if (repairing ? !chosen : !world.maximum(chosen)) {
        wall_choice.Disposition(wall_diagnostics::PreTrialDisposition::Conflict);
        continue;
      }
    } else {
      wall_choice.Begin(choice.active);
      {
        Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
        const Feature feature=repairing ? choice.feature : (coarsening ? Feature{{choice.edge[1],0,0},1} : Feature{{choice.edge[0],choice.edge[1],0},2});
        const auto features=choice.active ? std::vector<Feature>{feature} : std::vector<Feature>{};
        if(planned_coarsening) {
          // Every proposal of this round may have been refused for an oversized star during planning.
          if(!world.maximum(choice.active))continue;
          if(choice.active)dependencies=std::move(dependency_batch.candidates.at(0));else dependencies.valid=true;
        } else {
          auto batch=directory->LookupBatch(features,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()),repairing);
          if(!batch.valid) {result.reason=batch.reason;return finish();}
          if(choice.active)dependencies=std::move(batch.candidates.at(0));else dependencies.valid=true;
          const bool oversized=choice.active && !dependencies.valid && dependencies.oversized;
          CLocalFailure lookup_failure;
          if(choice.active && !dependencies.valid && !oversized)lookup_failure.Set(1,0,dependencies.reason);
          if(!context.exchange.Vote(context, lookup_failure))return finish();
          if(oversized) {
            // Refuse this proposal; publication still requires its complete star. Changed stars reactivate it.
            wall_choice.Disposition(wall_diagnostics::PreTrialDisposition::Oversized);
            try {refuse(choice,feature,dependencies.reason);}catch(const std::exception& e){lookup_failure.Set(2,0,e.what());}
            choice.active=false;dependencies=Dependencies{};dependencies.valid=true;
          }
          if(!context.exchange.Vote(context, lookup_failure))return finish();
          if(world.maximum(oversized) && !service_frontier(repairing ? feature : Feature{{choice.edge[0],choice.edge[1],0},2},oversized,false))return finish();
          // Concurrent peers keep their own proposals; a slot whose every proposal was refused is skipped.
          if(!world.maximum(choice.active))continue;
        }
        if (dependencies.valid) imported=directory->Fetch(dependencies,working,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()));
      }
      if (!dependencies.valid || !imported.valid) {
        result.reason=dependencies.valid ? imported.reason : dependencies.reason; return finish();
      }
      if(surface_target && curved && coarsening && !repairing) {
        Timer timer(stats.collapse_correction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);
        const size_t seed_cells=imported.cells.size();
        auto correction=directory->CorrectCollapse(dependencies,imported,working,choice.edge[1],choice.edge[0],
            choice.active,geometry,stats.work_limit-stats.global_work,atlas_budget.within_time,
            options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()));
        stats.global_work+=correction.work;stats.collapse_correction_work+=correction.work;
        if(!correction.valid){result.reason=correction.reason;return finish();}
        collapse_corrected=correction.corrected;collapse_apex=correction.apex;
        if(!collapse_corrected)collapse_correction_refusal=std::move(correction.reason);
        if(collapse_corrected){++stats.collapse_corrections;stats.collapse_correction_cells+=correction.imported.cells.size()-seed_cells;}
        dependencies=std::move(correction.dependencies);imported=std::move(correction.imported);
      }
      {
        Timer timer(stats.reservation_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
        chosen=reserve_dependencies(imported,choice.active,result.reason,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()),choice.reservation_priority);
        stats.conflicts+=choice.active && !chosen;
        if (choice.active && !chosen) {
          wall_choice.Disposition(pass_deferred ? wall_diagnostics::PreTrialDisposition::Deferred
                                                : wall_diagnostics::PreTrialDisposition::Conflict);
          selection.Note(choice.edge, pass_deferred ? 2 : 1);
          if(timed_lane==1)++stats.surface_conflicts;else if(timed_lane==2)++stats.interior_conflicts;
        }
        const int admitted=world.maximum(chosen?2:pass_deferred?1:0);
        if(!admitted)ready=false;
        else if(admitted==1) {
          if(!service_frontier(Feature{{choice.edge[0],choice.edge[1],0},2},choice.active&&pass_deferred,false,nullptr,0,2))return finish();
          stats.length_pass_deferred+=pass_deferred;continue;
        }
      }
      if (!ready) return finish();
    }
    // Private cavity evaluation uses the same operators with local reductions and explicit cavity data.
    auto trial_maximum=[&](int value){return private_repair?value:world.maximum(value);};
    auto trial_reduce=[&](auto value,CPassiveComm::Op op) {
      return private_repair?value:TimedAllreduce(value,op,world.comm);
    };
    auto trial_import_cells=[&](const std::vector<Cell>& cells,size_t ceiling,size_t caller) {
      return private_repair?source.ImportCellsLocal(cells,imported.cells,ceiling,caller):source.ImportCells(cells,ceiling,caller);
    };
    auto trial_import_samples=[&](const std::vector<Cell>& cells,const std::vector<Id>& extensions,
                                  size_t ceiling,size_t caller,const std::vector<unsigned char>& requests,bool shape) {
      return private_repair?source.ImportMetricSamplesLocal(cells,imported.cells,extensions,ceiling,caller,requests,shape):
          source.ImportMetricSamples(cells,extensions,ceiling,caller,requests,shape);
    };
    auto trial_sample_points=[&](const std::vector<Point>& points,const std::vector<Id>& extensions,size_t ceiling,size_t caller) {
      return private_repair?source.SamplePointsLocal(points,imported.cells,extensions,ceiling,caller):
          source.SamplePoints(points,extensions,ceiling,caller);
    };
    auto trial_sample_midpoints=[&](const std::vector<std::array<Point,2>>& points,const std::vector<Id>& extensions,
                                    size_t ceiling,size_t caller) {
      return private_repair?source.SampleMidpointsLocal(points,imported.cells,extensions,ceiling,caller):
          source.SampleMidpoints(points,extensions,ceiling,caller);
    };
    ContextValue failure_lifetime(slot_state.failure);
    CLocalFailure& failure = failure_lifetime.Get();
    ContextValue coordinate_only_lifetime(slot_state.coordinate_only, repairing &&
                                                                          imported.coordinate_star.count == 1 &&
                                                                          imported.cells.size() > MaximumCavityCells);
    const bool& coordinate_only = coordinate_only_lifetime.Get();
    ContextValue private_scratch_lifetime(
        slot_state.private_scratch,
        transfer_memory::Add(
            transfer_memory::Bytes(imported.cells),
            transfer_memory::Mul(std::max(MaximumReplacementCells, imported.cells.size()), 8192),
            surface_target ? SurfacePlanningScratchBytes(std::max(MaximumReplacementCells, imported.cells.size())) : 0,
            transfer_memory::Mul(selection.geometry_repairs ? 2 : 1, MaximumFrozenFieldBytes),
            MetricPatchSolveScratchBytes,
            transfer_memory::Mul(3 * MaximumCampaignEdges,
                                 sizeof(std::pair<const Edge, EdgeMeasure>) + 6 * sizeof(void*)),
            transfer_memory::Mul(8 * MaximumReplacementCells, 64)));
    const size_t& private_scratch = private_scratch_lifetime.Get(); // Bounded optimizer rejected-star set.
    ContextValue old_lifetime(slot_state.old);
    Patch& old = old_lifetime.Get();
    ContextValue fresh_lifetime(slot_state.fresh);
    Patch& fresh = fresh_lifetime.Get();
    ContextValue point_lifetime(slot_state.point);
    Node& point = point_lifetime.Get();
    ContextValue approved_lifetime(slot_state.approved, false);
    bool& approved = approved_lifetime.Get();
    ContextValue moved_lifetime(slot_state.moved, false);
    bool& moved = moved_lifetime.Get();
    ContextValue repair_approved_lifetime(slot_state.repair_approved, false);
    bool& repair_approved = repair_approved_lifetime.Get();
    ContextValue cavity_inserted_lifetime(slot_state.cavity_inserted, false);
    bool& cavity_inserted = cavity_inserted_lifetime.Get();
    ContextValue optimization_approved_lifetime(slot_state.optimization_approved, false);
    bool& optimization_approved = optimization_approved_lifetime.Get();
    ContextValue repair_optimization_lifetime(slot_state.repair_optimization);
    OptimizationOperations& repair_optimization = repair_optimization_lifetime.Get();
    ContextValue certified_lifetime(slot_state.certified);
    MetricDiagnosis& certified = certified_lifetime.Get();
    ContextValue geometric_progress_lifetime(slot_state.geometric_progress, false);
    bool& geometric_progress = geometric_progress_lifetime.Get();
    ContextValue last_geometry_operation_lifetime(slot_state.last_geometry_operation, nullptr);
    const char*& last_geometry_operation = last_geometry_operation_lifetime.Get();
    ContextValue field_lifetime(slot_state.field);
    std::unique_ptr<FrozenField>& field = field_lifetime.Get();
    ContextValue epoch_lifetime(slot_state.epoch,
                                transfer_memory::Add(transfer_memory::Mul(round, world.size), world.rank));
    const size_t& epoch = epoch_lifetime.Get();
    ContextValue token_lifetime(slot_state.token,
                                transfer_memory::Add(transfer_memory::Mul(epoch, options.candidate_batch), slot));
    const size_t& token = token_lifetime.Get();
    ContextValue offset_lifetime(slot_state.offset, transfer_memory::Mul(token, MaximumReplacementCells));
    const size_t& offset = offset_lifetime.Get();
    ContextValue construction_nodes_lifetime(slot_state.construction_nodes, !options.wall_heights.empty()
                                                                                ? MaximumReplacementCells + 3
                                                                            : (composition || curved) ? 9
                                                                                                      : 1);
    const size_t& construction_nodes = construction_nodes_lifetime.Get();
    ContextValue node_stride_lifetime(slot_state.node_stride, construction_nodes + 160);
    const size_t& node_stride = node_stride_lifetime.Get();
    ContextValue node_offset_lifetime(slot_state.node_offset, transfer_memory::Mul(token, node_stride));
    const size_t& node_offset = node_offset_lifetime.Get();
    ContextValue capture_lifetime(slot_state.capture, false);
    bool& capture = capture_lifetime.Get();
    ContextValue capture_selected_lifetime(slot_state.capture_selected, false);
    bool& capture_selected = capture_selected_lifetime.Get();
    ContextValue accepted_ladder_lifetime(slot_state.accepted_ladder, 3);
    unsigned& accepted_ladder = accepted_ladder_lifetime.Get();
    ContextValue old_flags_lifetime(slot_state.old_flags);
    std::vector<CellQualityFlag>& old_flags = old_flags_lifetime.Get();
    ContextValue fresh_flags_lifetime(slot_state.fresh_flags);
    std::vector<CellQualityFlag>& fresh_flags = fresh_flags_lifetime.Get();
    ContextValue measured_flags_lifetime(slot_state.measured_flags);
    std::vector<CellQualityFlag>& measured_flags = measured_flags_lifetime.Get();
    auto note_ladder=[&](unsigned kind,bool valid,Clock::time_point began,uint64_t geometry_before,uint64_t height_before,size_t work=0) {
      if(!repairing)return;
      auto& counter=stats.quality.ladder.at(kind);++counter.trials;counter.certified+=valid;counter.work+=work;
      counter.seconds+=std::chrono::duration<double>(Clock::now()-began).count();
      if(valid)accepted_ladder=kind;
      else {
        counter.rejected[0]+=stats.geometry_rejected>geometry_before;
        counter.rejected[1]+=stats.height_rejected+stats.footprint_rejected>height_before;
        counter.rejected[2]+=certified.failure==MetricFailure::Shape;
        counter.rejected[3]+=certified.failure==MetricFailure::Progress;
        counter.rejected[4]+=certified.failure==MetricFailure::Measurement;
        counter.rejected[7]+=stats.geometry_rejected==geometry_before&&stats.height_rejected+stats.footprint_rejected==height_before&&
            certified.failure==MetricFailure::None;
      }
    };
    ContextValue transaction_feature_lifetime(
        slot_state.transaction_feature, repairing ? choice.feature : Feature{{choice.edge[0], choice.edge[1], 0}, 2});
    const Feature& transaction_feature = transaction_feature_lifetime.Get();
    auto observe_transaction=[&](const char* stage,bool passed,const DonorPatch* donors=nullptr) {
      if(capture)options.transaction_observer({stage,transaction_feature,uint64_t(round),capture_selected,passed,
          working,geometry,dependencies,imported,old,fresh,point,maximum_cell+1+offset,maximum_node+1+node_offset,
          certified,result.reason,donors,composition,options.edge_breakpoints});
    };
    ContextValue repair_budget_lifetime(slot_state.repair_budget, 0);
    size_t& repair_budget = repair_budget_lifetime.Get();
    ContextValue repair_work_lifetime(slot_state.repair_work, 0);
    size_t& repair_work = repair_work_lifetime.Get();
    source.SetCavity(&imported.cells);
    struct CavityScope {
      CavityMetricSource& source;
      ~CavityScope() { source.SetCavity(nullptr); }
    } cavity_scope{source};
    ContextValue physical_edge_lifetime(
        slot_state.physical_edge,
        chosen && std::any_of(imported.cells.begin(), imported.cells.end(), [&](const OwnedCell& c) {
          const auto faces = Faces(c.cell);
          for (unsigned i = 0; i < 4; ++i)
            if (c.physical[i].present &&
                std::find(faces[i].begin(), faces[i].end(), choice.edge[0]) != faces[i].end() &&
                std::find(faces[i].begin(), faces[i].end(), choice.edge[1]) != faces[i].end())
              return true;
          return false;
        }));
    const bool& physical_edge = physical_edge_lifetime.Get();
    auto boundary_replacement_ready=[&]() {
      if(phase!=Phase::Improvement || !geometry.Mapped() || (old.surface.empty()&&fresh.surface.empty()))return true;
      try {
        geometry.ExportParameters(fresh);
        // Exact unchanged-face contracts avoid rebuilding a parameter delta for interior repairs.
        bool unchanged=old.surface.size()==fresh.surface.size();std::map<Face,Id> physical;
        if(unchanged)for(const auto& face:old.surface)
          if(!physical.emplace(Key(face.v),face.facet).second){unchanged=false;break;}
        if(unchanged)for(const auto& face:fresh.surface) {
          const auto found=physical.find(Key(face.v));
          if(found==physical.end()||found->second!=face.facet){unchanged=false;break;}
          std::array<BoundaryPoint,3> points;
          for(unsigned k=0;k<3;++k)points[k]=fresh.parameters.at(face.v[k]);
          if(!geometry.HasAcceptedFaceCertificate(face,points,fresh.coverage)){unchanged=false;break;}
          physical.erase(found);
        }
        if(unchanged&&physical.empty())return true;
        // The accepted parameter tables are replicated; this is one complete proposal, not an owner fragment.
        return geometry.Parameters()->CheckReplacement(old,fresh,result.reason,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),private_scratch,
                BoundaryCoverageBytes(old.coverage),BoundaryCoverageBytes(fresh.coverage)),geometry.AtlasReservation());
      }catch(const std::bad_alloc&){throw;}
      catch(const std::exception& e){result.reason=e.what();return false;}
    };
    auto evaluate_candidate=[&]() -> bool {
    lane_census::Trial lane_trial(lane_counters, repairing, lane_slots[slot], dependencies, imported,
                                 world.rank, repair_work);
    const bool coordinate_stream=trial_maximum(coordinate_only);
    // Admit large coordinate-star copies, surfaces, query regions and measurements before GeometryPatch
    // or source-region packing allocates them; the ordinary topology path keeps its existing bound.
    if(coordinate_stream && !context.exchange.Admit(context, private_scratch))return false;
    if(options.transaction_observer && options.capture_feature.count && !transaction_captured) {
      capture_selected=chosen && transaction_feature.count==options.capture_feature.count &&
          transaction_feature.vertices==options.capture_feature.vertices;
      capture=trial_maximum(capture_selected);
      transaction_captured=capture;
    }
    auto guarded_geometry = [&](bool valid, const char* operation = "geometry",
                                wall_diagnostics::GuardOrigin origin = wall_diagnostics::GuardOrigin::Operator) {
      last_geometry_operation=operation;
      std::array<bool, 4> guards{valid};
      guards[1] = valid && (!surface_target ||
                            PreservePassingFirstHeights(old, fresh, options.wall_heights, geometry, result.reason));
      guards[2] = guards[1] && EngineTrial::HeightCheck(context, fresh, result.reason, !selection.geometry_repairs);
      guards[3] = guards[2] && boundary_replacement_ready();
      const bool passed = EngineTrial::GeometryTrial(context, guards[3]);
      wall_counters.ObserveGuard(operation, origin, guards[0], guards[1], guards[2], guards[3], result.reason);
      observe_transaction(operation,passed);
      return passed;
    };
    auto repair_kind=[&]() {
      if(surface_target)return MetricChange::GeometryRepair;
      if(selection.geometry_repairs)return MetricChange::GeometryRepair;
      if(selection.size_repairs || GetShapeAdmission()!=ShapeAdmission::ValidityOnly || options.wall_heights.empty())return MetricChange::Repair;
      const auto before=HeightScore(old,options.wall_heights,geometry),after=HeightScore(fresh,options.wall_heights,geometry);
      return std::isfinite(before) && after>before+1e-6 ? MetricChange::GeometryRepair : MetricChange::Repair;
    };
    auto geometric_change=[&](bool candidate,MetricChange kind) {
      if(!candidate || !curved)return candidate;
      // Entity refinement constructs valid cells; local surrogate descent is not a geometry permission.
      if(!surface_target&&geometry.EntityGeometry()&&phase==Phase::Construction&&kind!=MetricChange::Coarsen)return true;
      D9QueryScope d9_query(SU2NativeD9::Site::Guidance, &geometry);
      ++stats.geometry_guidance_trials;
      wall_counters.GuidanceTrial(choice.geometric);
      Timer guidance_timer(stats.geometry_guidance_seconds,options.timings,
                           SU2NativeTiming3D::Operation::GeometryBound);
      try {
        long double before,after;bool complete_guidance=true;
        if(kind==MetricChange::Coarsen) {
          // A coarsening trial needs zero new excess; rejected trials need no old-surface score.
          const auto guidance=GeometryGuidanceExcess(fresh,geometry,options.surface_tolerance,0);
          stats.geometry_guidance_faces+=guidance.evaluated_faces;stats.geometry_guidance_early_rejections+=!guidance.complete;after=guidance.excess;
          if(!guidance.complete || !std::isfinite(after) || after>0) {
            ++stats.geometry_guidance_rejected;
            wall_counters.GuidanceReject(WallGuidanceCause(guidance.complete, std::isfinite(after), false, false),
                                         choice.geometric);
            geometric_progress=false;
            result.reason = "Native3D candidate does not preserve/improve its frozen geometry error.";
            return guarded_geometry(false, "geometry", wall_diagnostics::GuardOrigin::Guidance);
          }
          const auto old_guidance=GeometryGuidanceExcess(old,geometry,options.surface_tolerance);
          stats.geometry_guidance_faces+=old_guidance.evaluated_faces;before=old_guidance.excess;
        } else {
          const auto old_guidance=GeometryGuidanceExcess(old,geometry,options.surface_tolerance);
          stats.geometry_guidance_faces+=old_guidance.evaluated_faces;before=old_guidance.excess;
          const bool allow_increase=kind==MetricChange::GeometryRepair && phase==Phase::Improvement && !selection.geometry_repairs;
          const auto guidance=GeometryGuidanceExcess(fresh,geometry,options.surface_tolerance,
              allow_increase?std::numeric_limits<long double>::infinity():before);
          stats.geometry_guidance_faces+=guidance.evaluated_faces;stats.geometry_guidance_early_rejections+=!guidance.complete;after=guidance.excess;complete_guidance=guidance.complete;
        }
        geometric_progress=complete_guidance && before>0 && after<before*(1-1e-12L);
        if(!complete_guidance || !std::isfinite(after) || (selection.geometry_repairs && !geometric_progress) ||
           (kind==MetricChange::GeometryRefine && !geometric_progress) ||
           (kind==MetricChange::Coarsen && after>0) ||
           (kind!=MetricChange::GeometryRefine && after>before &&
            !(kind==MetricChange::GeometryRepair && phase==Phase::Improvement))) {
          ++stats.geometry_guidance_rejected;
          wall_counters.GuidanceReject(
              WallGuidanceCause(complete_guidance, std::isfinite(after),
                                selection.geometry_repairs || kind == MetricChange::GeometryRefine, geometric_progress),
              choice.geometric);
          result.reason = "Native3D candidate does not preserve/improve its frozen geometry error.";
          return guarded_geometry(false, "geometry", wall_diagnostics::GuardOrigin::Guidance);
        }
        return true;
      } catch (const std::exception& e) {
        ++stats.geometry_guidance_rejected;
        wall_counters.GuidanceReject(wall_diagnostics::GuidanceCause::Exception, choice.geometric);
        result.reason = e.what();
        return guarded_geometry(false, "geometry", wall_diagnostics::GuardOrigin::Guidance);
      }
    };
    try {observe_transaction("begin",chosen);}catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(options.transaction_observer && !context.exchange.Vote(context, failure))return false;
    auto validate_metric_vector=[&](MetricChange kind,FrozenField& target,PatchMetric& metric,
                                    const std::map<Edge,EdgeMeasure>& reuse) {
      if(!surface_target)return EngineTrial::MetricTrial(context, ValidateMetricChange(old.cells,fresh.cells,kind,target,metric,
          result.reason,nullptr,&reuse,&certified),certified,kind);
      if(!geometric_change(true,kind))return false;
      auto before=MeasureSurfacePlanning(old,target,geometry,options.wall_heights,surface_target);
      metric=MeasureSurfacePlanning(fresh,target,geometry,options.wall_heights,surface_target);
      EngineTrial::SurfaceMerit(context, before,old);EngineTrial::SurfaceMerit(context, metric,fresh);
      const auto effective=kind==MetricChange::Repair?MetricChange::GeometryRepair:kind;
      return EngineTrial::MetricTrial(context,
          wall_counters.MetricValidation(ValidateMetricChange(old.cells.size(), before, fresh.cells.size(), metric,
                                                              effective, result.reason, &certified)),
          certified, effective, geometric_progress);
    };
    Point splitPosition{},centralPosition{};bool split_failed=false,central_available=false;
    if(timed_lane==2&&physical_edge)++stats.interior_boundary_discoveries;
    SegmentFreedom crease_freedom=SegmentFreedom::Unresolved;Point crease_midpoint{};
    const long double diagnostic_limit=MaximumMetricEdge*(1+1e-8L); // Conservative diagnostic margin, never an acceptance tolerance.
    if(!repairing && !coarsening && composition && physical_edge && choice.measure.length>diagnostic_limit)try {
      std::set<Id> facets;
      for(const auto& row:imported.cells) {
        const auto faces=Faces(row.cell);
        for(unsigned i=0;i<4;++i)if(row.physical[i].present &&
            std::find(faces[i].begin(),faces[i].end(),choice.edge[0])!=faces[i].end() &&
            std::find(faces[i].begin(),faces[i].end(),choice.edge[1])!=faces[i].end())
          facets.insert(geometry.Canonical(row.physical[i].facet));
      }
      if(facets.size()==2) {
        const auto first=*facets.begin(),second=*facets.rbegin();
        if(!geometry.Declared(first) && !geometry.Declared(second)) {
          const auto& f=geometry.Get(first);const auto& g=geometry.Get(second);
          const bool folded=std::any_of(g.v.begin(),g.v.end(),[&](Node n){return Orientation(f.v[0].p,f.v[1].p,f.v[2].p,n.p)!=0;});
          if(folded)crease_freedom=Binary64SegmentFreedom(choice.measure.a,choice.measure.b,crease_midpoint);
        }
      }
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    auto incompatible_crease=[&](long double length) {
      std::ostringstream message;message<<std::setprecision(17)<<"Native3D exact-facet resolution conflict on crease edge "
          <<choice.edge[0]<<","<<choice.edge[1]<<": an interval without an interior binary64 point has frozen metric length "
          <<length<<" above "<<MaximumMetricEdge<<"; no admissible subdivision meets the current geometry/metric contract.";
      failure.Set(1,choice.edge[0],message.str());stats.last_rejected_feature={{choice.edge[0],choice.edge[1],0},2};
      if(!imported.cells.empty())stats.last_rejected_cavity_centroid=Centroid(imported.cells.front().cell);
    };
    if(crease_freedom==SegmentFreedom::None)incompatible_crease(choice.measure.length);
    if(!repairing && !coarsening && composition) {
      std::vector<Cell> query;
      try {if(chosen)query.push_back(imported.cells.front().cell);}catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure))return false;
      if(!context.exchange.Admit(context, transfer_memory::Add(MaximumFrozenFieldBytes,transfer_memory::Bytes(imported.cells))))return false;
      DonorPatch seed;
      {Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);
        seed=trial_import_cells(query,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),MaximumFrozenFieldBytes));}
      if(!seed.valid){result.reason=seed.reason;return false;}
      if(chosen)try {
        Timer timer(stats.metric_seconds,options.timings, SU2NativeTiming3D::Operation::MetricNormalization);CpuTimer cpu(stats.metric_cpu_seconds,options.timings);
        const auto components=AssociatedExtensions(seed.cells,geometry);
        observe_transaction("split_donors",seed.valid,&seed);
        FrozenField target(std::move(seed.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
        FieldAccounting accounting{stats,target};
        bool conflict=false;
        if(crease_freedom==SegmentFreedom::MidpointOnly) {
          const auto length=std::max(target.TargetEdgeLength(choice.measure.a,crease_midpoint),target.TargetEdgeLength(crease_midpoint,choice.measure.b));
          conflict=length>diagnostic_limit;if(conflict)incompatible_crease(length);
        }
        if(!conflict) {
          if(physical_edge){centralPosition=target.SegmentPoint(choice.measure.a,choice.measure.b,.5);central_available=true;}
          splitPosition=target.BalancedSplitPoint(choice.measure.a,choice.measure.b);
        }
      }catch(const std::exception& e){
        result.reason=e.what();split_failed=!(physical_edge && central_available);
        if(!split_failed)splitPosition=centralPosition;
      }
      if(!context.exchange.Vote(context, failure))return false;
    }
    {
      Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);
      if (chosen && split_failed) wall_choice.Disposition(wall_diagnostics::PreTrialDisposition::SplitPosition);
      if (chosen && !split_failed) {
        CpuTimer private_cpu(stats.reconstruction_cpu_seconds,options.timings);
        wall_choice.EnterOperator();
        ++stats.attempted;
        if ((maximum_node>UINT64_MAX-node_stride || node_offset>UINT64_MAX-maximum_node-node_stride) ||
            maximum_cell>UINT64_MAX-MaximumReplacementCells || offset>UINT64_MAX-maximum_cell-MaximumReplacementCells) {
          failure.Set(1,0,"Native 3D reserved identity range overflows.");
        } else try {
          old=GeometryPatch(imported, &geometry);
          const auto a=choice.measure.a,b=choice.measure.b;
          if (!repairing && coarsening) {
            if(!geometry.EntityGeometry()&&CollapseOutsideTolerance(old,choice.edge[1],choice.edge[0],geometry,options.surface_tolerance)) {
              result.reason="Native3D collapsed boundary leaves an original geometry sample outside tolerance.";
              approved=guarded_geometry(false,"CollapseVertex");
            } else if(collapse_corrected)approved=guarded_geometry(ReconnectCollapse(old,choice.edge[1],choice.edge[0],
              collapse_apex,maximum_cell+1+offset,geometry,fresh,result.reason),"ReconnectCollapse");
            else approved=guarded_geometry(CollapseVertex(old,choice.edge[1],choice.edge[0],maximum_cell+1+offset,
              geometry,fresh,result.reason),"CollapseVertex");
          }
          else if (!repairing) {
            point={maximum_node+1+node_offset,{double((static_cast<long double>(a.x)+b.x)/2),
                double((static_cast<long double>(a.y)+b.y)/2),double((static_cast<long double>(a.z)+b.z)/2)}};
            if(composition)point.p=splitPosition;
            approved=guarded_geometry(SplitEdge(old,choice.edge,point,maximum_cell+1+offset,geometry,fresh,result.reason),"SplitEdge");
            if (!approved) {
              approved=guarded_geometry(InsertEdgeCavity(old,choice.edge,point,maximum_cell+1+offset,geometry,fresh,result.reason),"InsertEdgeCavity");
              cavity_inserted=approved;
            }
            if(!approved && physical_edge && composition && central_available &&
                (point.p.x!=centralPosition.x || point.p.y!=centralPosition.y || point.p.z!=centralPosition.z)) {
              point.p=centralPosition;
              approved=guarded_geometry(SplitEdge(old,choice.edge,point,maximum_cell+1+offset,geometry,fresh,result.reason),"SplitEdge");
              if(!approved) {
                approved=guarded_geometry(InsertEdgeCavity(old,choice.edge,point,maximum_cell+1+offset,geometry,fresh,result.reason),"InsertEdgeCavity");
                cavity_inserted=approved;
              }
            }
          }
        } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
      }
      ready=context.exchange.Vote(context, failure);
    }
    if (!ready) return false;
    // A rejected surface collapse has no later repair route; unrelated debt needs no old-patch measurement.
    const bool metric_needed=chosen && (approved || repairing || !coarsening || (bad_field && !surface_target));
    DonorPatch sensors;sensors.valid=true;
    bool streamed=ready;
    if (!ready || (!sensors.valid && !streamed)) { if (ready) result.reason=sensors.reason; return false; }
    if (streamed && !context.exchange.Admit(context, private_scratch)) return false;
    if (streamed) ++stats.private_query_retries;
    auto reserve_optimization=[&](bool eligible) {
      if(private_repair){repair_budget=eligible?private_optimizer_allowance:repair_work;return;}
      const auto count=trial_reduce(uint64_t(eligible),CPassiveComm::Op::SUM);
      const auto budget=count?std::min<uint64_t>(160,(stats.work_limit-stats.global_work)/count):0;
      const auto extra=eligible?std::min<uint64_t>(budget,160-repair_work):0;
      stats.global_work+=trial_reduce(uint64_t(extra),CPassiveComm::Op::SUM);
      repair_budget=repair_work+extra;
    };
    auto release_optimization=[&]() {
      if(private_repair){repair_budget=repair_work;return;}
      stats.global_work-=trial_reduce(uint64_t(repair_budget-repair_work),CPassiveComm::Op::SUM);
      repair_budget=repair_work;
    };
    reserve_optimization(!streamed && chosen && repairing);
    if(trial_maximum(repair_budget>repair_work) &&
        !context.exchange.Admit(context, transfer_memory::Add(private_scratch,transfer_memory::Bytes(sensors.cells))))return false;
    auto optimize_patch=[&](const Patch& candidate,const RegionMetric& target,bool preserve_vertices) {
      optimization_approved=false;repair_optimization={};
      const auto reserved=repair_budget-repair_work;
      if(!reserved)return false;
      const double remaining=options.maximum_seconds ?
          options.maximum_seconds-std::chrono::duration<double>(Clock::now()-started).count() : 0;
      if(options.maximum_seconds && remaining<=0)return false;
      const Id first_node=maximum_node+1+node_offset+construction_nodes+repair_work;
      size_t used=reserved;repair_work+=reserved;
      ++stats.repair_proposals;++stats.optimization_trials;
      const bool changed=OptimizedRepairPatch(candidate,maximum_cell+1+offset,first_node,target,
                                              fresh,result.reason,used,preserve_vertices,geometry,options.wall_heights,options.surface_tolerance,repair_optimization,remaining);
      repair_work-=reserved-used;
      stats.boundary_smoothing_stars+=repair_optimization.boundary_stars;stats.boundary_smoothing_reused+=repair_optimization.boundary_reused;
      stats.boundary_smoothing_candidates+=repair_optimization.boundary_candidates;stats.boundary_smoothing_validity_rejects+=repair_optimization.boundary_validity;
      stats.boundary_smoothing_shape_rejects+=repair_optimization.boundary_shape;stats.boundary_smoothing_edge_rejects+=repair_optimization.boundary_edge;
      stats.boundary_smoothing_geometry_rejects+=repair_optimization.boundary_geometry;stats.boundary_smoothing_guidance_calls+=repair_optimization.boundary_guidance;
      stats.boundary_smoothing_move_contexts+=repair_optimization.boundary_move_contexts;stats.boundary_smoothing_prepared_trials+=repair_optimization.boundary_prepared_trials;
      stats.boundary_smoothing_guidance_faces+=repair_optimization.boundary_guidance_faces;stats.boundary_smoothing_guidance_reused_faces+=repair_optimization.boundary_guidance_reused_faces;stats.boundary_smoothing_guidance_early_rejections+=repair_optimization.boundary_guidance_early;
      stats.boundary_smoothing_upper_queries+=repair_optimization.boundary_upper;stats.boundary_smoothing_moves+=repair_optimization.boundary_moves;
      stats.boundary_smoothing_debt_reduction+=repair_optimization.boundary_debt;stats.boundary_smoothing_seconds+=repair_optimization.boundary_seconds;
      stats.interior_smoothing_stars+=repair_optimization.interior_stars;stats.interior_smoothing_reused+=repair_optimization.interior_reused;
      stats.interior_smoothing_candidates+=repair_optimization.interior_candidates;stats.interior_smoothing_validity_rejects+=repair_optimization.interior_validity;
      stats.interior_smoothing_shape_rejects+=repair_optimization.interior_shape;stats.interior_smoothing_edge_rejects+=repair_optimization.interior_edge;
      stats.interior_smoothing_geometry_rejects+=repair_optimization.interior_geometry;stats.interior_smoothing_guidance_calls+=repair_optimization.interior_guidance;
      stats.interior_smoothing_upper_queries+=repair_optimization.interior_upper;stats.interior_smoothing_moves+=repair_optimization.interior_moves;
      stats.interior_smoothing_debt_reduction+=repair_optimization.interior_debt;stats.interior_smoothing_seconds+=repair_optimization.interior_seconds;
      return changed;
    };
    {
      Timer timer(stats.metric_seconds,options.timings, SU2NativeTiming3D::Operation::MetricNormalization);
      const double reconstruction_before=stats.reconstruction_seconds;
      const double reconstruction_cpu_before=stats.reconstruction_cpu_seconds;
      if (!streamed && metric_needed) try {
        CpuTimer private_cpu(stats.metric_cpu_seconds,options.timings);
        const auto components=AssociatedExtensions(sensors.cells,geometry);
        observe_transaction("support_donors",sensors.valid,&sensors);
        field=std::make_unique<FrozenField>(std::move(sensors.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
        PatchMetric metric;
        std::map<Edge,EdgeMeasure> reuse;
        for (const auto& cell : old.cells) selection.Cached(cell,reuse);
        if (approved) {
          approved=validate_metric_vector(construction_kind,*field,metric,reuse);
        }
        if (!approved) cavity_inserted=false;
        if (repairing) {
          auto try_repair=[&](bool move,Id vertex) {
            std::map<Id,Node> nodes;
            for (const auto& cell:old.cells) for (auto node:cell.v) nodes.emplace(node.id,node);
            const Id first=maximum_cell+1+offset;
            if (move) {
              if (maximum_node>UINT64_MAX-node_stride || node_offset>UINT64_MAX-maximum_node-node_stride) return false;
              std::set<Id> neighbors;
              for (auto face:old.surface) if (std::find(face.v.begin(),face.v.end(),vertex)!=face.v.end())
                neighbors.insert(face.v.begin(),face.v.end());
              if (neighbors.empty()) for (const auto& row:nodes) neighbors.insert(row.first);
              neighbors.erase(vertex);
              long double x=0,y=0,z=0;
              for (Id id:neighbors) { auto p=nodes.at(id).p; x+=p.x; y+=p.y; z+=p.z; }
              Point center{};
              if(!neighbors.empty()) {
                const auto origin=nodes.at(vertex).p;center={double(x/neighbors.size()),double(y/neighbors.size()),double(z/neighbors.size())};
                if(composition) {
                  std::vector<std::pair<Point,Tensor>> samples;
                  for(auto id:neighbors) {
                    const auto q=nodes.at(id).p;
                    samples.emplace_back(q,field->QueryMidpoint(origin,q).target);
                  }
                  center=MetricMeanPoint(origin,samples);
                }
              }
              if (!neighbors.empty()) for (long double step:{1.L,.5L,.25L}) {
                const auto p=nodes.at(vertex).p;
                point={maximum_node+1+node_offset,{double(p.x+step*(center.x-p.x)),
                    double(p.y+step*(center.y-p.y)),double(p.z+step*(center.z-p.z))}};
                if(composition)point=ConstrainMovePoint(old,vertex,point,options.wall_heights,geometry);
                ++stats.repair_proposals;
                { Timer geometry_timer(stats.reconstruction_seconds,options.timings,
                                       SU2NativeTiming3D::Operation::Candidate); CpuTimer geometry_cpu(stats.reconstruction_cpu_seconds,options.timings);
                approved=guarded_geometry(MoveVertex(old,vertex,point,first,geometry,fresh,result.reason),"MoveVertex"); }
                if (approved) {const auto kind=repair_kind();
                  approved=validate_metric_vector(kind,*field,metric,reuse);}
                if (approved) { moved=true; break; }
              }
            } else {
              unsigned proposals=0;
              for (const auto& row:nodes) {
                if (++proposals>16) break;
                ++stats.repair_proposals;
                { Timer geometry_timer(stats.reconstruction_seconds,options.timings,
                                       SU2NativeTiming3D::Operation::Candidate); CpuTimer geometry_cpu(stats.reconstruction_cpu_seconds,options.timings);
                  approved=guarded_geometry(Reconnect(old,row.first,first,geometry,fresh,result.reason),"Reconnect"); }
                if (approved) {const auto kind=repair_kind();
                  approved=validate_metric_vector(kind,*field,metric,reuse);}
                if (approved) break;
              }
            }
            if(!surface_target && !approved && repair_work<repair_budget) {
              {Timer geometry_timer(stats.reconstruction_seconds,options.timings,
                                     SU2NativeTiming3D::Operation::Candidate);CpuTimer geometry_cpu(stats.reconstruction_cpu_seconds,options.timings);
                approved=guarded_geometry(optimize_patch(old,RegionMetric(*field),false));}
              if(approved){const auto kind=repair_kind();
                approved=validate_metric_vector(kind,*field,metric,reuse);}
              if(approved){moved=false;optimization_approved=true;++stats.optimization_validated;}
            }
            return approved;
          };
          approved=try_repair(choice.feature.count==1,choice.feature.vertices[0]);
          repair_approved=approved;
        }
      } catch (const std::exception& e) { approved=false; result.reason=e.what(); }
      if (field) FieldCounts(stats,*field);
      stats.metric_seconds-=stats.reconstruction_seconds-reconstruction_before;
      stats.metric_cpu_seconds-=stats.reconstruction_cpu_seconds-reconstruction_cpu_before;
    }
    release_optimization();
    if(!streamed && composition && !repairing && !coarsening) {
      if(trial_maximum(chosen && !approved)) {
        field.reset();if(!context.exchange.Admit(context, private_scratch))return false;
        streamed=true;++stats.private_query_retries;
      }
    }
    if (streamed) {
      // One bounded stage cache; only exact endpoint/field matches authorize reuse across proposals.
      auto measure_private=[&](const std::vector<Cell>& cells, PatchMetric& measured, bool shape,
                               const std::map<Edge,EdgeMeasure>& frozen_reuse,const Patch* surface_context=nullptr) {
        if(repairing)measured_flags.clear();
        CLocalFailure local;
        bool usable=true;
        std::string rejected;
        std::map<Edge,EdgeMeasure> reuse;
        try { reuse=frozen_reuse; } catch (const std::exception& e) { local.Set(2,0,e.what()); }
        if (!(ready=context.exchange.Vote(context, local))) return false;
        size_t count=trial_reduce(cells.size(),CPassiveComm::Op::MAX);
        measured={};
        const bool measure_shape=!surface_target&&phase==Phase::Improvement;
        if(measure_shape) {
          measured.minimum_mean_ratio=measured.minimum_scaled_jacobian=INFINITY;measured.shape_measured=true;
          if(!cells.empty())measured.weakest_cell=measured.sliver_cell=cells.front().id;
        }
        for (size_t slot=0;slot<count;) {
          size_t batch=std::min({MeasurementBatch,MaximumCavityCells/6,count-slot});
          DonorPatch donors;
          for (;;) {
            std::vector<Cell> query;
            try {
              if (usable) for (size_t i=slot;i<std::min(slot+batch,cells.size());++i) query.push_back(cells[i]);
            } catch (const std::exception& e) { local.Set(2,0,e.what()); }
            std::vector<unsigned char> requests;
            try {requests=MetricEdgeRequests(query,reuse,field_identity,&campaign_edges);
              if(surface_target)std::fill(requests.begin(),requests.end(),static_cast<unsigned char>(63));}
            catch(const std::exception& e){local.Set(2,0,e.what());}
            if (!(ready=context.exchange.Vote(context, local))) return false;
            {
              Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);
              ++stats.donor_batches;
              donors=trial_import_samples(query,eligible_extensions,options.memory_ceiling,
                  transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch),requests,measure_shape);
            }
            if (donors.valid) break;
            if (!DonorCap(donors.reason) || batch==1) { ready=false; result.reason=donors.reason; return false; }
            batch=(batch+1)/2; ++stats.batch_retries;
          }
          if (usable && slot<cells.size()) {
            Timer timer(stats.metric_seconds,options.timings, SU2NativeTiming3D::Operation::MetricNormalization);
            CpuTimer cpu(stats.metric_cpu_seconds,options.timings);
            MetricStats counted;
            std::unique_ptr<FrozenField> target;
            try {
              observe_transaction("metric_donors",donors.valid,&donors);
              const auto components=AssociatedExtensions(donors.cells,geometry);
              observe_transaction("support_donors",donors.valid,&donors);
              target=std::make_unique<FrozenField>(std::move(donors.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
              PatchMetric planned;
              if(surface_target) {
                if(!surface_context)throw std::logic_error("Surface planning lacks its current private cavity.");
                Patch local_surface;std::set<Face> faces;
                local_surface.parameters=surface_context->parameters;local_surface.coverage=surface_context->coverage;
                for(size_t i=slot;i<std::min(slot+batch,cells.size());++i) {
                  local_surface.cells.push_back(cells[i]);for(auto face:Faces(cells[i]))faces.insert(Key(face));
                }
                for(const auto& face:surface_context->surface)if(faces.count(Key(face.v)))local_surface.surface.push_back(face);
                // Guidance is cell-independent; use the same admitted source batch and current private associations once.
                planned=MeasureSurfacePlanning(local_surface,*target,geometry,options.wall_heights,surface_target,&counted);
              }
              for (size_t i=slot;i<std::min(slot+batch,cells.size());++i) {
                PatchMetric part;
                if(surface_target) {
                  for(unsigned a=0;a<4;++a)for(unsigned b=a+1;b<4;++b) {
                    Edge edge{cells[i].v[a].id,cells[i].v[b].id};std::sort(edge.begin(),edge.end());
                    part.edges.emplace(edge,planned.edges.at(edge));
                  }
                } else part=measure_shape ? MeasureMetricCells({cells[i]},*target,&counted,&reuse,shape,shape ? &certified : nullptr,&campaign_edges) :
                    MeasureMetricEdges({cells[i]},*target,&counted,&reuse,&campaign_edges);
                if (measure_shape && part.minimum_mean_ratio<measured.minimum_mean_ratio) {
                  measured.minimum_mean_ratio=part.minimum_mean_ratio; measured.weakest_cell=part.weakest_cell;
                }
                if (measure_shape && part.minimum_scaled_jacobian<measured.minimum_scaled_jacobian) {
                  measured.minimum_scaled_jacobian=part.minimum_scaled_jacobian; measured.sliver_cell=part.sliver_cell;
                }
                measured.shape_cells+=part.shape_cells;measured.shape_debt+=part.shape_debt;
                measured.q_bad_cells+=part.q_bad_cells;measured.j_bad_cells+=part.j_bad_cells;
                if(repairing&&part.shape_measured)measured_flags.push_back({cells[i].id,part.q_bad_cells!=0,part.j_bad_cells!=0});
                for (const auto& edge:part.edges) {
                  measured.edges.emplace(edge); reuse[edge.first]=edge.second;
                  if (edge.second.length>measured.maximum_length) {
                    measured.maximum_length=edge.second.length; measured.longest_edge=edge.first;
                  }
                }
              }
            } catch (const std::exception& e) { usable=false; rejected=e.what(); }
            if (target) FieldCounts(stats,*target);
            stats.private_edge_evaluations+=counted.edge_evaluations;
            stats.private_edge_reused+=counted.edge_reused;stats.private_edge_campaign_hits+=counted.edge_campaign_reused;
          }
          slot+=batch;
        }
        if(usable&&surface_target&&surface_context)EngineTrial::SurfaceMerit(context, measured,*surface_context);
        if (!usable) result.reason=rejected;
        return usable;
      };
      std::map<Edge,EdgeMeasure> reuse;
      { Timer timer(stats.metric_seconds,options.timings, SU2NativeTiming3D::Operation::MetricNormalization);
        try { for (const auto& cell:old.cells) selection.Cached(cell,reuse); }
        catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        ready=context.exchange.Vote(context, failure);
      }
      if (!ready) return false;
      PatchMetric before;
      const std::vector<Cell> empty;
      const bool old_measured=measure_private(metric_needed ? old.cells : empty,before,false,reuse,&old);
      if(repairing&&old_measured)old_flags=measured_flags;
      // A failed measurement of unchanged accepted geometry invalidates the event on every worker.
      if (!ready) return false;
      CLocalFailure old_failure;
      if (metric_needed && !old_measured) old_failure.Set(1,0,result.reason);
      if (!(ready=context.exchange.Vote(context, old_failure))) return false;
      // Refits and joint placement give each moved apex a new identity from maximum_node+2+node_offset on (one for one);
      // the split point is maximum_node+1+node_offset. Only those callers certify relocations (RefineAcceptance).
      auto reserved_relocations=[&]() {
        std::set<Id> previous,ids;for(const auto& c:old.cells)for(auto n:c.v)previous.insert(n.id);
        for(const auto& c:fresh.cells)for(auto n:c.v)
          if(n.id>=maximum_node+2+node_offset && n.id<maximum_node+1+node_offset+construction_nodes && !previous.count(n.id))ids.insert(n.id);
        return ids.size();
      };
      auto validate_private=[&](bool candidate,MetricChange kind,bool no_new_oversized=false,bool strict_size=false,size_t relocated=0,
                                  wall_diagnostics::PatchSource source=wall_diagnostics::PatchSource::Unreported,
                                  bool required_split=false) {
        const bool source_available=bool(surface_target) && !repairing && !coarsening && candidate;
        const auto source_rejected_before=stats.geometry_guidance_rejected;
        SU2NativeTiming3D::Scope candidate_timer(SU2NativeTiming3D::Operation::Candidate);
        const bool completed=concurrent && approved && !candidate;
        const auto retained=certified;
        certified={};
        const bool merit_first=!surface_target && bidirectional && repairing && kind==MetricChange::Repair && !selection.geometry_repairs;
        if(required_split)geometric_progress=false;
        if(!merit_first && !required_split)candidate=geometric_change(candidate,selection.geometry_repairs?MetricChange::GeometryRepair:kind);
        PatchMetric metric;
        const std::vector<Cell> empty;
        bool measured=measure_private(candidate ? fresh.cells : empty,metric,true,before.edges,&fresh);
        CLocalFailure observed;
        bool valid=false;
        { Timer timer(stats.metric_seconds,options.timings, SU2NativeTiming3D::Operation::MetricNormalization); CpuTimer cpu(stats.metric_cpu_seconds,options.timings);
          if (candidate) {
            const auto effective=kind==MetricChange::Repair ? (geometric_progress&&!bidirectional?MetricChange::GeometryRepair:repair_kind()) : kind;
            if (measured)
              valid = metric_cleanup ? ValidateMetricCleanup(old.cells.size(), before, fresh.cells.size(), metric,
                                                             result.reason, &certified)
                                     : wall_counters.MetricValidation(ValidateMetricChange(
                                           old.cells.size(), before, fresh.cells.size(), metric, effective,
                                           result.reason, &certified, relocated, coordinate_only));
            if(valid && no_new_oversized)for(const auto& edge:metric.edges)if(edge.second.length>MaximumMetricEdge) {
              const auto previous=before.edges.find(edge.first);
              auto same=[](Point a,Point b){return a.x==b.x && a.y==b.y && a.z==b.z;};
              if(previous==before.edges.end() || !same(previous->second.a,edge.second.a) || !same(previous->second.b,edge.second.b)) {
                valid=false;certified.failure=MetricFailure::Progress;
                result.reason="Native3D joint strip introduces a new oversized edge.";break;
              }
            }
            if(valid && strict_size && !certified.size_progress) {
              valid=false;certified.failure=MetricFailure::Progress;result.reason="Native3D compound wall repair does not reduce frozen changed-edge excess.";
            }
            valid=EngineTrial::MetricTrial(context, valid,certified,effective,geometric_progress);
          }
        }
        if(valid && merit_first && !required_split)valid=geometric_change(true,repair_kind());
        if(valid && selection.geometry_repairs)valid=EngineTrial::HeightCheck(context, fresh,result.reason);
        // The initial streaming probe precedes repair proposals; it is not an operator failure.
        if(chosen && !valid && !completed && (!repairing || last_geometry_operation)) {
          stats.last_metric_rejection=certified;
          stats.last_rejected_feature=repairing ? choice.feature : Feature{{choice.edge[0],choice.edge[1],0},2};
          if(!old.cells.empty())stats.last_rejected_cavity_centroid=Centroid(old.cells.front());
          last_rejection="feature "+std::to_string(stats.last_rejected_feature.count)+":"+
              std::to_string(stats.last_rejected_feature.vertices[0])+": "+result.reason;
          if(options.transaction_observer && !options.capture_feature.count && !transaction_captured)try {
            transaction_captured=true;
            const std::string stage=repairing?"first_"+std::string(last_geometry_operation)+"_failure":
                coarsening?"first_collapse_failure":"first_split_failure";
            options.transaction_observer({stage.c_str(),
                transaction_feature,uint64_t(round),true,false,working,geometry,dependencies,imported,old,fresh,point,
                maximum_cell+1+offset,maximum_node+1+node_offset,certified,result.reason,nullptr,composition,options.edge_breakpoints});
          }catch(const std::exception& e){observed.Set(2,0,e.what());}
          if(options.rejected_trial)try {
            options.rejected_trial(old,fresh,stats.last_rejected_feature,certified,candidate,result.reason);
          }catch(const std::exception& e){observed.Set(2,0,e.what());}
        }
        try {observe_transaction("metric",valid);}catch(const std::exception& e){observed.Set(2,0,e.what());}
        if(observe_rejections || (!repairing && !coarsening))ready=context.exchange.Vote(context, observed);
        if(completed)certified=retained;
        if(repairing&&valid)fresh_flags=measured_flags;
        wall_counters.ObserveSource(source,source_available,stats.geometry_guidance_rejected>source_rejected_before,valid);
        return valid;
      };
      bool required_split=false,checked_split=false;
      if(surface_target && curved && !coarsening && !repairing && choice.geometric && approved) {
        const Node* bound_point=nullptr;
        for(const auto& cell:fresh.cells)for(const auto& node:cell.v)
          if(node.id==point.id)bound_point=&node;
        if(bound_point) {
          required_split=SplitPointLiftRequiresSplit(point.p,bound_point->p,options.surface_tolerance);
          checked_split=!required_split;
          wall_counters.ObservePrimarySplit(required_split);
        }
      }
      const auto primary_guidance_rejected=stats.geometry_guidance_rejected;
      approved=validate_private(metric_needed && old_measured && approved,choice.geometric ? MetricChange::GeometryRefine : construction_kind,
                                false,false,0,wall_diagnostics::PatchSource::Primary,required_split);
      if(options.timings) {
        lane_slots[slot].required_primary_split=required_split && approved;
        lane_slots[slot].checked_primary_split=checked_split && approved;
        wall_counters.ObserveCheckedRejection(checked_split && stats.geometry_guidance_rejected>primary_guidance_rejected);
      }
      if (!approved) cavity_inserted=false;
      if (!ready) return false;
      const bool boundary_edge=std::any_of(old.surface.begin(),old.surface.end(),[&](const auto& f) {
        return std::find(f.v.begin(),f.v.end(),choice.edge[0])!=f.v.end() && std::find(f.v.begin(),f.v.end(),choice.edge[1])!=f.v.end();
      });
      bool joint=chosen && !split_failed && (choice.geometric || composition) && !repairing && !coarsening && !approved;
      bool flat_edge=true;
      for(const auto& f:old.surface)if(std::find(f.v.begin(),f.v.end(),choice.edge[0])!=f.v.end() &&
          std::find(f.v.begin(),f.v.end(),choice.edge[1])!=f.v.end()) {
        const auto authority=geometry.Analytic().find(f.facet);
        if(authority!=geometry.Analytic().end() && authority->second.kind!=AnalyticSurface::Kind::Disk)flat_edge=false;
      }
      // Flat caps/interior regions retain coordinated-strip freedom even in a domain with curved walls.
      bool strip=joint && composition && flat_edge && !choice.geometric;
      std::vector<Id> wallApices;
      if(joint && boundary_edge)for(const auto& f:old.surface) {
        if(!options.wall_heights.count(geometry.Get(f.facet).marker) ||
            std::find(f.v.begin(),f.v.end(),choice.edge[0])==f.v.end() ||
            std::find(f.v.begin(),f.v.end(),choice.edge[1])==f.v.end())continue;
        for(const auto& c:old.cells) {
          unsigned count=0;Node apex;
          for(auto n:c.v)if(std::find(f.v.begin(),f.v.end(),n.id)!=f.v.end())++count;else apex=n;
          if(count==3)wallApices.push_back(apex.id);
        }
      }
      std::sort(wallApices.begin(),wallApices.end());wallApices.erase(std::unique(wallApices.begin(),wallApices.end()),wallApices.end());
      bool wallSplit=joint && !wallApices.empty();
      Id placement_obstruction=UINT64_MAX;
      auto place_patch=[&](bool search,const std::vector<Id>& apices,Id height_apex=UINT64_MAX) {
        if(!trial_maximum(search))return true;
        if(stats.global_work>=stats.work_limit){stats.stop=EngineStop::WorkBudget;result.reason="Native3D joint placement exhausted the global work budget.";return false;}
        if(options.maximum_seconds && trial_maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
          stats.stop=EngineStop::TimeBudget;result.reason="Native3D joint placement exhausted the elapsed budget.";return false;
        }
        std::vector<Feature> features;
        if(search) {
          features.push_back({{choice.edge[0],choice.edge[1],0},2});
          for(Id id:apices)features.push_back({{id,0,0},1});
        }
        Dependencies joined;
        {Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
          joined=directory->Lookup(features,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));}
        if(!joined.valid) {
          if(joined.reason=="Native 3D dependency star exceeds budget." || joined.reason=="Native 3D dependency union exceeds budget.")search=false;
          else failure.Set(1,0,joined.reason);
        }
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        if(!search){joined.valid=true;joined.cells.clear();}
        Imported more;
        {Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
          more=directory->Fetch(joined,working,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));}
        if(!more.valid){result.reason=more.reason;return false;}
        if(search)try {
          std::set<Id> required;
          for(const auto& c:old.cells)if(std::count_if(c.v.begin(),c.v.end(),[&](Node n){return n.id==choice.edge[0] || n.id==choice.edge[1];})==2)required.insert(c.id);
          // Discard unused support from abandoned proposals; the actual edge and moved stars remain complete.
          for(const auto& dep:dependencies.cells)if(required.count(dep.cell)) {
            const auto found=std::find_if(joined.cells.begin(),joined.cells.end(),[&](const auto& d){return d.cell==dep.cell;});
            if(found==joined.cells.end() || found->version!=dep.version || found->owner!=dep.owner)
              throw std::runtime_error("Native3D joint placement lost a complete/versioned dependency.");
          }
          dependencies=std::move(joined);imported=std::move(more);old=GeometryPatch(imported, &geometry);reuse.clear();
          for(const auto& c:old.cells)selection.Cached(c,reuse);
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        bool reserved=false;
        {Timer timer(stats.reservation_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
          reserved=reserve_dependencies(imported,search || approved,result.reason,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch),choice.reservation_priority);}
        if((search || approved) && !reserved) {
          if(directory->PassDeferred() || result.reason=="Native 3D conflicting dependency reservation.") {
            ++stats.conflicts;
            if(directory->PassDeferred() || !concurrent){search=false;approved=false;if(directory->PassDeferred())joint=false;}
          } else failure.Set(1,0,"Native3D joint placement lost its complete-star reservation: "+result.reason);
        }
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        PatchMetric expanded_before;
        const bool measured=measure_private(search?old.cells:empty,expanded_before,false,reuse,&old);
        if(search && measured)before=std::move(expanded_before);
        if(!ready)return false;
        if(search && !measured)failure.Set(1,0,result.reason);
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        DonorPatch support;
        {Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);++stats.donor_batches;
          support=trial_import_cells(search?old.cells:empty,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch));}
        if(!support.valid) {
          if(DonorCap(support.reason))search=false;
          else {result.reason=support.reason;return false;}
        }
        const auto participants=concurrent ? trial_reduce(uint64_t(search),CPassiveComm::Op::SUM) : uint64_t(1);
        const auto allowance=std::min<uint64_t>(256,(stats.work_limit-stats.global_work)/std::max<uint64_t>(1,participants));
        if(!allowance){stats.stop=EngineStop::WorkBudget;result.reason="Native3D joint placement cannot admit simultaneous work within the global budget.";return false;}
        bool candidate=false;JointSplitReport report;
        if(search)try {
          Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
          const auto components=AssociatedExtensions(support.cells,geometry);
          observe_transaction("support_donors",support.valid,&support);
          FrozenField target(std::move(support.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
          FieldAccounting accounting{stats,target};std::vector<std::pair<Id,Id>> reserved_apices;
          for(size_t i=0;i<apices.size();++i)reserved_apices.emplace_back(apices[i],maximum_node+2+i+node_offset);
          if(height_apex!=UINT64_MAX) {
            candidate=ReconstructHeightStar(old,height_apex,maximum_node+1+node_offset,maximum_cell+1+offset,target,
                geometry,options.wall_heights,fresh,report,result.reason,allowance);
            stats.wall_reconstruction_trials+=report.trials;stats.wall_topology_trials+=report.trials;
          } else candidate=PlaceSplitPatch(old,choice.edge,point,reserved_apices,maximum_cell+1+offset,target,geometry,options.wall_heights,
              fresh,report,result.reason,allowance);
          stats.repair_proposals+=report.trials;stats.placement_trials+=report.trials;
          stats.placement_connectivity_trials+=report.connectivity_trials;stats.placement_flips+=report.flips;stats.placement_moves+=report.moves;
          stats.metric_linearizations+=report.linearizations;stats.metric_probes+=report.metric_probes;
          stats.metric_linear_iterations+=report.linear_iterations;stats.metric_solve_trials+=report.solve_trials;
          placement_obstruction=report.blocked_interior_vertex;
          if(!candidate && !report.best.cells.empty()){fresh=std::move(report.best);candidate=true;}
          candidate=guarded_geometry(candidate);
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        stats.global_work+=concurrent ? trial_reduce(uint64_t(report.trials),CPassiveComm::Op::SUM) : trial_maximum(report.trials);
        const auto retained_metric=certified;
        const bool passed=validate_private(candidate,choice.geometric?MetricChange::GeometryRefine:MetricChange::Refine,false,false,
            height_apex==UINT64_MAX && candidate ? reserved_relocations() : 0);
        if(search && !approved){approved=passed;stats.placement_validated+=passed;}
        else if(!search)certified=retained_metric;
        if(!ready)return false;
        if(search && approved){cavity_inserted=true;joint=false;}
        return true;
      };
      Id height_apex=UINT64_MAX;
      if(joint && composition && !boundary_edge && !choice.geometric && !options.wall_heights.empty())
        for(Id vertex:choice.edge) {
          size_t walls=0;
          for(const auto& f:old.surface)if(options.wall_heights.count(geometry.Get(f.facet).marker) &&
              std::find(f.v.begin(),f.v.end(),vertex)==f.v.end())
            for(const auto& c:old.cells) {
              unsigned matches=0;bool apex=false;
              for(auto n:c.v){matches+=std::find(f.v.begin(),f.v.end(),n.id)!=f.v.end();apex=apex || n.id==vertex;}
              walls+=matches==3 && apex;
            }
          if(walls>=2){height_apex=vertex;break;}
        }
      if(!place_patch(height_apex!=UINT64_MAX,{height_apex},height_apex))return false;
      if(!place_patch(joint && composition && (!boundary_edge || (flat_edge && wallApices.empty())) && !choice.geometric,{}))return false;
      const Id initial_placement_obstruction=placement_obstruction;
      strip=strip && !wallSplit && !approved;  // Admit the required wall region before optional unrelated movers.
      std::vector<Id> movers;
      if(strip)for(const auto& f:old.surface) {
        if(std::find(f.v.begin(),f.v.end(),choice.edge[0])==f.v.end() || std::find(f.v.begin(),f.v.end(),choice.edge[1])==f.v.end())continue;
        for(auto id:f.v)if(id!=choice.edge[0] && id!=choice.edge[1])movers.push_back(id);
      }
      if(strip && !boundary_edge)movers={choice.edge[0],choice.edge[1]};
      if(strip && boundary_edge) {
        std::map<Id,unsigned> interior;
        for(const auto& c:old.cells)for(auto n:c.v)if(n.id!=choice.edge[0] && n.id!=choice.edge[1] &&
            std::none_of(old.surface.begin(),old.surface.end(),[&](const auto& f){return std::find(f.v.begin(),f.v.end(),n.id)!=f.v.end();}))++interior[n.id];
        const auto best=std::max_element(interior.begin(),interior.end(),[](const auto& a,const auto& b){return a.second<b.second;});
        if(best!=interior.end() && best->second>=2)movers.push_back(best->first);
      }
      std::sort(movers.begin(),movers.end());movers.erase(std::unique(movers.begin(),movers.end()),movers.end());
      strip=strip && movers.size()>=2 && movers.size()<=3;
      if(trial_maximum(strip || wallSplit)) {
        std::vector<Feature> features;
        if(strip || wallSplit) {
          features.push_back({{choice.edge[0],choice.edge[1],0},2});
          if(strip)for(auto id:movers)features.push_back({{id,0,0},1});
          for(auto id:wallApices)features.push_back({{id,0,0},1});
        }
        Dependencies joined;
        {Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
          joined=directory->Lookup(features,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));}
        if(!joined.valid) {
          if(joined.reason=="Native 3D dependency star exceeds budget." || joined.reason=="Native 3D dependency union exceeds budget.")strip=wallSplit=false;
          else failure.Set(1,0,joined.reason);
        }
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        if(!strip && !wallSplit){joined.valid=true;joined.cells.clear();}
        Imported more;
        {Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
          more=directory->Fetch(joined,working,options.memory_ceiling,
              transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));}
        if(!more.valid){result.reason=more.reason;return false;}
        if(strip || wallSplit)try {
          for(const auto& olddep:dependencies.cells) {
            const auto found=std::find_if(joined.cells.begin(),joined.cells.end(),[&](const auto& dep){return dep.cell==olddep.cell;});
            if(found==joined.cells.end() || found->version!=olddep.version || found->owner!=olddep.owner)
              throw std::runtime_error("Native3D strip lost an original complete/versioned edge dependency.");
          }
          dependencies=std::move(joined);imported=std::move(more);old=GeometryPatch(imported, &geometry);reuse.clear();
          for(const auto& c:old.cells)selection.Cached(c,reuse);
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        bool reserved=false;
        {Timer timer(stats.reservation_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
          reserved=reserve_dependencies(imported,strip || wallSplit,result.reason,options.memory_ceiling,
              transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch),choice.reservation_priority);}
        if((strip || wallSplit) && !reserved) {
          if(directory->PassDeferred()) {++stats.conflicts;strip=false;wallSplit=false;joint=false;approved=false;}
          else if(concurrent && result.reason=="Native 3D conflicting dependency reservation.")++stats.conflicts;
          else failure.Set(1,0,"Native3D strip lost its complete-star reservation.");
        }
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        const bool measured=measure_private(joint?old.cells:empty,before,false,reuse,&old);
        if(!ready)return false;
        if(joint && !measured)failure.Set(1,0,result.reason);
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        DonorPatch donors;
        {Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);++stats.donor_batches;
          donors=trial_import_cells(strip?old.cells:empty,options.memory_ceiling,
              transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch));}
        if(!donors.valid) {
          if(DonorCap(donors.reason))strip=false;
          else {result.reason=donors.reason;return false;}
        }
        std::array<Point,3> splits{};Edge extraEdge{};Node extraPoint,offEdgePoint;bool extraSplit=false;
        std::array<std::vector<std::pair<Id,Node>>,3> moveSeeds;std::vector<std::pair<Id,Node>> normalMoves;
        if(strip)try {
          Timer timer(stats.metric_seconds,options.timings, SU2NativeTiming3D::Operation::MetricNormalization);CpuTimer cpu(stats.metric_cpu_seconds,options.timings);
          const auto components=AssociatedExtensions(donors.cells,geometry);
          observe_transaction("support_donors",donors.valid,&donors);
          FrozenField target(std::move(donors.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
          FieldAccounting accounting{stats,target};std::map<Id,Node> nodes;
          for(const auto& c:old.cells)for(auto n:c.v)nodes.emplace(n.id,n);
          const std::array<double,3> fractions{{.5,.55,.565}};
          if(boundary_edge)for(size_t i=0;i<fractions.size();++i)splits[i]=target.BalancedSplitPoint(nodes.at(choice.edge[0]).p,nodes.at(choice.edge[1]).p,fractions[i]);
          for(size_t i=0;i<movers.size();++i) {
            const auto id=movers[i];const auto origin=nodes.at(id).p;std::set<Id> neighbors;
            for(const auto& f:old.surface)if(std::find(f.v.begin(),f.v.end(),id)!=f.v.end())neighbors.insert(f.v.begin(),f.v.end());
            const bool physicalMover=!neighbors.empty();
            if(neighbors.empty())for(const auto& c:old.cells) {
              if(std::any_of(c.v.begin(),c.v.end(),[&](Node n){return n.id==id;}))for(auto n:c.v)neighbors.insert(n.id);
            }
            neighbors.erase(id);std::vector<std::pair<Point,Tensor>> values;
            for(auto neighbor:neighbors) {
              const auto q=nodes.at(neighbor).p;
              values.emplace_back(q,target.QueryMidpoint(origin,q).target);
            }
            const Node mean=ConstrainMovePoint(old,id,{maximum_node+2+i+node_offset,MetricMeanPoint(origin,values)},options.wall_heights,geometry);
            for(size_t damping=0;damping<3;++damping) {
              auto proposal=mean;
              const double stiffness=physicalMover ? (damping==1?1.:damping==2?3.:0.) : (damping==2?1.:0.);
              if(stiffness) {
                auto t=target.Query(origin).target;
                const auto scale=std::max({std::abs(t.xx),std::abs(t.xy),std::abs(t.xz),std::abs(t.yy),std::abs(t.yz),std::abs(t.zz)});
                const auto factor=stiffness/scale;t={t.xx*factor,t.xy*factor,t.xz*factor,t.yy*factor,t.yz*factor,t.zz*factor};
                proposal.p=MetricMeanPoint(origin,{{mean.p,Tensor{}},{origin,t}});
                proposal=ConstrainMovePoint(old,id,proposal,options.wall_heights,geometry);
              }
              moveSeeds[damping].emplace_back(id,proposal);
            }
          }
          if(boundary_edge) {
            std::vector<SurfaceFace> incident;
            for(const auto& f:old.surface)if(std::find(f.v.begin(),f.v.end(),choice.edge[0])!=f.v.end() &&
                std::find(f.v.begin(),f.v.end(),choice.edge[1])!=f.v.end())incident.push_back(f);
            if(incident.size()==2 && geometry.Canonical(incident[0].facet)==geometry.Canonical(incident[1].facet)) {
              const auto a=nodes.at(incident[0].v[0]).p,b=nodes.at(incident[0].v[1]).p,c=nodes.at(incident[0].v[2]).p;
              const long double u[3]={(long double)b.x-a.x,(long double)b.y-a.y,(long double)b.z-a.z};
              const long double v[3]={(long double)c.x-a.x,(long double)c.y-a.y,(long double)c.z-a.z};
              std::array<long double,3> normal{{u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0]}};
              const auto norm=std::hypot(normal[0],normal[1],normal[2]);
              if(!(norm>0))throw std::runtime_error("Native3D strip has a degenerate physical face.");
              for(auto& x:normal)x/=norm;
              std::vector<std::pair<Id,Node>> inward;
              for(size_t i=0;i<movers.size();++i) {
                const Id id=movers[i];
                if(std::any_of(old.surface.begin(),old.surface.end(),[&](const auto& f){return std::find(f.v.begin(),f.v.end(),id)!=f.v.end();}))continue;
                const auto origin=nodes.at(id).p;const auto m=target.Query(origin).target;
                const auto side=normal[0]*((long double)origin.x-a.x)+normal[1]*((long double)origin.y-a.y)+normal[2]*((long double)origin.z-a.z);
                const auto quadratic=m.xx*normal[0]*normal[0]+m.yy*normal[1]*normal[1]+m.zz*normal[2]*normal[2]+
                    2*(m.xy*normal[0]*normal[1]+m.xz*normal[0]*normal[2]+m.yz*normal[1]*normal[2]);
                if(!(quadratic>0) || !std::isfinite(quadratic))throw std::runtime_error("Native3D strip normal metric is unrepresentable.");
                if(side==0)continue;
                const auto step=std::copysign(.25L/std::sqrt(quadratic),side);
                Node proposal{maximum_node+2+i+node_offset,{double(origin.x+step*normal[0]),double(origin.y+step*normal[1]),double(origin.z+step*normal[2])}};
                inward.emplace_back(id,ConstrainMovePoint(old,id,proposal,options.wall_heights,geometry));
              }
              // A fixed cap's free apex can need depth freedom without moving its neighboring surface points.
              normalMoves=std::move(inward);
            }
          }
          if(boundary_edge)for(size_t i=0;i<movers.size();++i) {
            const Id id=movers[i];
            if(std::any_of(old.surface.begin(),old.surface.end(),[&](const auto& f){return std::find(f.v.begin(),f.v.end(),id)!=f.v.end();}))continue;
            long double longest=MaximumMetricEdge;
            for(Id endpoint:choice.edge) {
              const Edge edge{std::min(id,endpoint),std::max(id,endpoint)};
              const auto found=before.edges.find(edge);
              if(found!=before.edges.end() && found->second.length>longest){extraEdge=edge;longest=found->second.length;extraSplit=true;}
            }
            if(extraSplit) {
              extraPoint={maximum_node+2+i+node_offset,target.BalancedSplitPoint(nodes.at(extraEdge[0]).p,nodes.at(extraEdge[1]).p)};
              std::set<Id> neighbors;
              for(const auto& c:old.cells) {
                unsigned count=0;for(auto n:c.v)count+=n.id==extraEdge[0] || n.id==extraEdge[1];
                if(count==2)for(auto n:c.v)neighbors.insert(n.id);
              }
              std::vector<std::pair<Point,Tensor>> values;
              for(auto neighbor:neighbors) {
                const auto q=nodes.at(neighbor).p;const auto a=extraPoint.p;
                values.emplace_back(q,target.QueryMidpoint(a,q).target);
              }
              const auto mean=MetricMeanPoint(extraPoint.p,values);const auto a=extraPoint.p;
              offEdgePoint={extraPoint.id,{double(((long double)a.x+mean.x)/2),double(((long double)a.y+mean.y)/2),double(((long double)a.z+mean.z)/2)}};
            }
          }
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        std::vector<Patch> frames;std::vector<unsigned> extraFrames;
        if(strip)try {
          Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
          frames.push_back(old);extraFrames.push_back(0);
          if(extraSplit){frames.push_back(old);extraFrames.push_back(2);}
          if(boundary_edge) {
            Patch seed;
            for(const auto& c:old.cells) {
              unsigned count=0;for(auto n:c.v)count+=n.id==choice.edge[0] || n.id==choice.edge[1];
              if(count==2)seed.cells.push_back(c);
            }
            const auto skin=Incidence(seed.cells).Boundary();
            for(const auto& f:old.surface)if(std::any_of(skin.begin(),skin.end(),[&](Face face){return Key(face)==Key(f.v);}))seed.surface.push_back(f);
            const auto apex=std::find_if(movers.begin(),movers.end(),[&](Id id){
              return std::any_of(seed.surface.begin(),seed.surface.end(),[&](const auto& f){return std::find(f.v.begin(),f.v.end(),id)!=f.v.end();});
            });
            Patch fan;
            if(apex!=movers.end() && Reconnect(seed,*apex,maximum_cell+1+offset,geometry,fan,result.reason)) {
              auto frame=old;
              frame.cells.erase(std::remove_if(frame.cells.begin(),frame.cells.end(),[&](const auto& c){
                return std::any_of(seed.cells.begin(),seed.cells.end(),[&](const auto& d){return c.id==d.id;});
              }),frame.cells.end());
              frame.cells.insert(frame.cells.end(),fan.cells.begin(),fan.cells.end());
              // Only the complete replacement is metric-certified; an intermediate reconnection may worsen shape.
              if(frame.cells.size()<=MaximumCavityCells) {
                frames.push_back(frame);extraFrames.push_back(0);
                if(extraSplit){frames.push_back(std::move(frame));extraFrames.push_back(1);}
              }
            }
          }
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        const unsigned frameCount=trial_maximum(strip?unsigned(frames.size()):0);
        const unsigned originalTrials=36*frameCount;
        const unsigned normalTrials=trial_maximum(strip && !normalMoves.empty() ? 12u : 0u);
        // Preserve the established search before a bounded cap-depth escape using the shared refinement progress gate.
        for(unsigned trial=0;trial<originalTrials+normalTrials && trial_maximum(strip && !approved);++trial) {
          const bool normalTrial=trial>=originalTrials;
          const unsigned frame=normalTrial?0:trial/36;
          const bool participating=strip && !approved && frame<frames.size() && (!normalTrial || !normalMoves.empty());
          const auto work=concurrent ? trial_reduce(uint64_t(participating),CPassiveComm::Op::SUM) : uint64_t(1);
          if(work>stats.work_limit-stats.global_work){stats.stop=EngineStop::WorkBudget;result.reason="Native3D joint strip exhausted the global work budget.";return false;}
          stats.global_work+=work;
          if(options.maximum_seconds && trial_maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
            stats.stop=EngineStop::TimeBudget;result.reason="Native3D joint strip exhausted the elapsed budget.";return false;
          }
          bool candidate=false;
          if(participating)try {
            const unsigned slotTrial=normalTrial?12*((trial-originalTrials)/4)+(trial-originalTrials)%4:trial%36;
            Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
            ++stats.repair_proposals;auto moves=normalTrial?normalMoves:moveSeeds[(slotTrial%12)/4];const double alpha=std::array<double,4>{{1.,.5,.25,.125}}[slotTrial%4];
            for(auto& move:moves) {
              Point origin{};bool found=false;for(const auto& c:old.cells)for(auto n:c.v)if(n.id==move.first){origin=n.p;found=true;}
              if(!found)throw std::runtime_error("Native3D joint strip misses a moved identity.");
              const auto q=move.second.p;
              move.second.p={double(origin.x+alpha*((long double)q.x-origin.x)),double(origin.y+alpha*((long double)q.y-origin.y)),double(origin.z+alpha*((long double)q.z-origin.z))};
            }
            if(!normalTrial && trial>=36)moves.erase(std::remove_if(moves.begin(),moves.end(),[&](const auto& move){
              return std::none_of(old.surface.begin(),old.surface.end(),[&](const auto& f){return std::find(f.v.begin(),f.v.end(),move.first)!=f.v.end();});
            }),moves.end());
            point.p=splits[slotTrial/12];
            if(!boundary_edge) {
              Point a{},b{};for(const auto& c:old.cells)for(auto n:c.v) {
                if(n.id==choice.edge[0])a=n.p;if(n.id==choice.edge[1])b=n.p;
              }
              for(const auto& move:moves){if(move.first==choice.edge[0])a=move.second.p;if(move.first==choice.edge[1])b=move.second.p;}
              const long double t=std::array<long double,3>{{.5L,.25L,.75L}}[slotTrial/12];
              point.p={double((1-t)*a.x+t*b.x),double((1-t)*a.y+t*b.y),double((1-t)*a.z+t*b.z)};
            }
            // Preserve fixed identities: relabelling a stationary corner would manufacture changed-edge debt.
            moves.erase(std::remove_if(moves.begin(),moves.end(),[&](const auto& move){
              for(const auto& c:old.cells)for(auto n:c.v)if(n.id==move.first)
                return n.p.x==move.second.p.x && n.p.y==move.second.p.y && n.p.z==move.second.p.z;
              return false;
            }),moves.end());
            if(!moves.empty()) {
              candidate=SplitSurfaceStrip(frames[frame],choice.edge,point,moves,maximum_cell+1+offset,geometry,fresh,result.reason);
              if(candidate && extraFrames[frame]) {
                Patch star;
                for(const auto& c:fresh.cells) {
                  unsigned count=0;for(auto n:c.v)count+=n.id==extraEdge[0] || n.id==extraEdge[1];
                  if(count==2)star.cells.push_back(c);
                }
                const auto skin=Incidence(star.cells).Boundary();
                for(const auto& f:fresh.surface)if(std::any_of(skin.begin(),skin.end(),[&](Face face){return Key(face)==Key(f.v);}))star.surface.push_back(f);
                // Mapped mode: the strip's private bindings (including its new split point) must reach the sub-patch.
                star.parameters=fresh.parameters;
                Patch children;
                candidate=extraFrames[frame]==2 ?
                    InsertEdgeCavity(star,extraEdge,offEdgePoint,maximum_cell+1+offset,geometry,children,result.reason) :
                    SplitEdge(star,extraEdge,extraPoint,maximum_cell+1+offset,geometry,children,result.reason);
                if(candidate) {
                  fresh.cells.erase(std::remove_if(fresh.cells.begin(),fresh.cells.end(),[&](const auto& c){
                    return std::any_of(star.cells.begin(),star.cells.end(),[&](const auto& d){return c.id==d.id;});
                  }),fresh.cells.end());
                  fresh.cells.insert(fresh.cells.end(),children.cells.begin(),children.cells.end());
                  for(const auto& row:children.parameters)fresh.parameters.insert_or_assign(row.first,row.second);
                  if(fresh.cells.size()>MaximumReplacementCells)candidate=false;
                  else for(size_t i=0;i<fresh.cells.size();++i)fresh.cells[i].id=maximum_cell+1+offset+i;
                }
              }
              candidate=guarded_geometry(candidate);
            }
          }catch(const std::exception& e){failure.Set(2,0,e.what());}
          if(!(ready=context.exchange.Vote(context, failure)))return false;
          // A split may retain long changed edges only when their sorted length frontier strictly
          // descends; the metric certificate also handles every removed vertex.
          const bool passed=validate_private(candidate,MetricChange::Refine,
              !normalTrial && GetRefineAcceptance()==RefineAcceptance::StrictExcess);
          if(strip && !approved)approved=passed;
          if(!ready)return false;
        }
        if(strip && approved){cavity_inserted=true;joint=false;}
      }
      auto movable_star=[&](const Imported& star,Id vertex) {
        std::set<Id> components;
        for(const auto& row:star.cells)for(unsigned f=0;f<4;++f)
          if(row.physical[f].present && row.cell.v[f].id!=vertex)components.insert(geometry.Canonical(row.physical[f].facet));
        if(choice.geometric)return components.empty();  // Geometry placement moves free volume support, not its prescribed surface.
        return components.size()<=1;  // Smooth physical vertices share the same complete-star admission as interior points.
      };
      bool search=joint && (choice.geometric || (composition && flat_edge)) && wallApices.empty() && !approved;
      std::vector<Id> apices;
      if(trial_maximum(search)) {
        std::vector<Id> candidates;std::vector<Feature> features;
        if(search)try {
          std::set<Id> vertices;
          for(const auto& c:old.cells)if(std::count_if(c.v.begin(),c.v.end(),[&](Node n){return n.id==choice.edge[0] || n.id==choice.edge[1];})==2)
            for(auto n:c.v)if(n.id!=choice.edge[0] && n.id!=choice.edge[1])vertices.insert(n.id);
          candidates.assign(vertices.begin(),vertices.end());for(Id id:candidates)features.push_back({{{id,0,0}},1});
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        {Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
          auto metadata=directory->LookupBatch(features,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));
          if(!metadata.valid){result.reason=metadata.reason;return false;}
          auto payload=directory->FetchBatch(metadata,working,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));
          if(!payload.valid){result.reason=payload.reason;return false;}
          if(search)try {
            std::map<Id,size_t> costs;
            for(size_t i=0;i<candidates.size();++i) {
              const auto& star=payload.candidates.at(i);
              if(!star.valid) {
                if(star.reason=="Native 3D dependency star exceeds budget.")continue;
                throw std::runtime_error(star.reason);
              }
              ++stats.placement_classified_vertices;
              if(movable_star(star,candidates[i]))costs.emplace(candidates[i],star.cells.size());
            }
            apices=SplitPatchApices(old,choice.edge,&costs);
            if(costs.count(initial_placement_obstruction)) {
              auto admitted_cells=[&](const std::vector<Id>& movers) {
                std::set<Id> cells;
                for(const auto& c:old.cells)if(std::count_if(c.v.begin(),c.v.end(),[&](Node n){
                    return n.id==choice.edge[0] || n.id==choice.edge[1];})==2)cells.insert(c.id);
                for(size_t i=0;i<candidates.size();++i)if(std::find(movers.begin(),movers.end(),candidates[i])!=movers.end())
                  for(const auto& row:payload.candidates.at(i).cells)cells.insert(row.cell.id);
                return cells.size();
              };
              // Admit an actual blocking star when the all-cell cover cannot fit, without raising the cavity bound.
              const std::vector<Id> targeted{initial_placement_obstruction};
              if((apices.empty() || admitted_cells(apices)>MaximumCavityCells) && admitted_cells(targeted)<=MaximumCavityCells) {
                apices=targeted;++stats.placement_dependency_expansions;
              }
            }
            search=!apices.empty();
          }catch(const std::exception& e){failure.Set(2,0,e.what());}
        }
      }
      if(!(ready=context.exchange.Vote(context, failure)))return false;
      for(unsigned attempt=0;attempt<8 && trial_maximum(search && !approved);++attempt) {
        placement_obstruction=UINT64_MAX;
        if(!place_patch(search,apices))return false;
        bool expand=search && !approved && stats.global_work<stats.work_limit && apices.size()<8 &&
            placement_obstruction!=UINT64_MAX && placement_obstruction!=choice.edge[0] && placement_obstruction!=choice.edge[1] &&
            std::find(apices.begin(),apices.end(),placement_obstruction)==apices.end();
        if(!trial_maximum(expand))break;
        {Timer timer(stats.dependency_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
          const std::vector<Feature> hints=expand?std::vector<Feature>{{{{placement_obstruction,0,0}},1}}:std::vector<Feature>{};
          auto metadata=directory->LookupBatch(hints,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));
          if(!metadata.valid){result.reason=metadata.reason;return false;}
          auto payload=directory->FetchBatch(metadata,working,options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));
          if(!payload.valid){result.reason=payload.reason;return false;}
          if(expand)try {
            const auto& star=payload.candidates.at(0);
            if(!star.valid) {
              if(star.reason=="Native 3D dependency star exceeds budget.")expand=false;
              else throw std::runtime_error(star.reason);
            } else {
              ++stats.placement_classified_vertices;
              expand=movable_star(star,placement_obstruction);
            }
            if(expand){apices.push_back(placement_obstruction);++stats.placement_dependency_expansions;}
          }catch(const std::exception& e){failure.Set(2,0,e.what());}
        }
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        search=expand;
      }
      joint=joint && boundary_edge;
      Tensor placement,nearPlacement;
      if(trial_maximum(joint)) {
        std::vector<Point> query;
        if(joint)try {
          if(std::none_of(old.cells.begin(),old.cells.end(),[&](const Cell& cell){unsigned matches=0;for(auto n:cell.v)matches+=n.id==choice.edge[0] || n.id==choice.edge[1];return matches==2;}))
            throw std::runtime_error("Native3D joint patch lacks its complete split edge.");
          query.push_back(Centroid(old.cells.front()));if(!choice.geometric)query.push_back(point.p);
        }
        catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        DonorSamples proxy;
        {Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);++stats.donor_batches;
          proxy=trial_sample_points(query,eligible_extensions,options.memory_ceiling,
              transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch));}
        if(!proxy.valid){result.reason=proxy.reason;return false;}
        if(joint)try {
          placement=EngineTrial::ComposedSample(context, query[0],proxy.samples.at(0).sensor);
          nearPlacement=choice.geometric ? placement : EngineTrial::ComposedSample(context, query[1],proxy.samples.at(1).sensor);
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
      }
      for(unsigned growth=0;growth<12 && trial_maximum(joint && !approved);++growth) {
        const auto work=concurrent ? trial_reduce(uint64_t(joint && !approved),CPassiveComm::Op::SUM) : uint64_t(1);
        if(work>stats.work_limit-stats.global_work) {
          stats.stop=EngineStop::WorkBudget;result.reason="Native3D joint repair exhausted the global work budget.";return false;
        }
        stats.global_work+=work;
        if(options.maximum_seconds && trial_maximum(std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)) {
          stats.stop=EngineStop::TimeBudget;result.reason="Native3D joint repair exhausted the elapsed budget.";return false;
        }
        bool candidate=false;Face obstruction{};Feature refit_obstruction,preferred_obstruction;
        const bool retained_frame=trial_maximum(joint && wallSplit);
        const unsigned retained_frames=retained_frame?2:0;
        const unsigned frames=(trial_maximum(joint && !choice.geometric)?2:1)+retained_frames;
        for(unsigned frame=0;frame<frames;++frame) {
          const bool participating=joint && !approved;candidate=false;
          {
            Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
            if(participating)try {
              ++stats.repair_proposals;
              const bool wall=std::any_of(old.surface.begin(),old.surface.end(),[&](const auto& f) {
                return options.wall_heights.count(geometry.Get(f.facet).marker);
              });
              stats.wall_reconstruction_trials+=wall;
              if(retained_frame && frame<retained_frames && wallSplit) {
                ++stats.wall_topology_trials;
                if(frame==0)candidate=guarded_geometry(wall_counters.TimeFrame("RefitWallSplit", [&] {
                    return RefitWallSplit(old,choice.edge,point,maximum_node+2+node_offset,
                        maximum_cell+1+offset,options.wall_heights,geometry,fresh,refit_obstruction,result.reason);
                  }),"RefitWallSplit");
                else candidate=guarded_geometry(wall_counters.TimeFrame("ReconstructWallSplit", [&] {
                    return ReconstructWallSplit(old,choice.edge,point,maximum_node+2+node_offset,
                        maximum_cell+1+offset,options.wall_heights,geometry,fresh,obstruction,result.reason,nullptr,
                        options.surface_tolerance);
                  }),"ReconstructWallSplit");
              } else if(!retained_frame || frame>=retained_frames) {
                candidate=guarded_geometry(wall_counters.TimeFrame("ReconstructSplitPatch", [&] {
                    return ReconstructSplitPatch(old,choice.edge,point,{maximum_node+2+node_offset,{}},
                        frame>retained_frames?nearPlacement:placement,maximum_cell+1+offset,geometry,
                        fresh,obstruction,result.reason,nullptr,options.wall_heights);
                  }),"ReconstructSplitPatch");

              }
            }catch(const std::exception& e){failure.Set(2,0,e.what());}
            ready=context.exchange.Vote(context, failure);
          }
          if(!ready)return false;
          const bool compound_refit=retained_frame && frame==0;
          // SplitInsertion uses strict lexicographic descent of the changed-edge length frontier,
          // including refitted wall splits; it is not an unconditional size-progress exemption.
          const bool split_refit=compound_refit && !choice.geometric &&
              GetRefineAcceptance()==RefineAcceptance::SplitInsertion;
          auto validate_joint = [&](bool available,
                                    wall_diagnostics::PatchSource source = wall_diagnostics::PatchSource::Unreported) {
            return split_refit ? validate_private(available, MetricChange::Refine, false, false,
                                                  available ? reserved_relocations() : 0, source)
                               : validate_private(available,
                                                  compound_refit     ? MetricChange::Refine
                                                  : choice.geometric ? MetricChange::GeometryRefine
                                                                     : MetricChange::Refine,
                                                  false, compound_refit && !choice.geometric, 0, source);
          };
          const auto source = retained_frame && frame < retained_frames
                                  ? (frame == 0 ? wall_diagnostics::PatchSource::RefitWallSplit
                                                : wall_diagnostics::PatchSource::ReconstructWallSplit)
                                  : wall_diagnostics::PatchSource::ReconstructSplitPatch;
          bool passed = validate_joint(candidate, source);
          if(!ready)return false;
          const bool missing_closure=participating && retained_frame && frame<retained_frames && wallSplit && !candidate &&
              (compound_refit?refit_obstruction.count>0:obstruction!=Face{});
          bool close_first=trial_maximum(missing_closure);
          if(missing_closure)preferred_obstruction=compound_refit?refit_obstruction:Feature{obstruction,3};
          const bool repair=phase==Phase::Improvement && !close_first && participating && candidate && !passed && certified.failure==MetricFailure::Shape &&
              fresh.cells.size()<=MaximumReplacementCells && !options.wall_heights.empty() && stats.global_work<stats.work_limit;
          if(trial_maximum(repair)) {
            const auto repair_limit=std::min<uint64_t>(256,(stats.work_limit-stats.global_work)/
                trial_reduce(uint64_t(repair),CPassiveComm::Op::SUM));
            Patch repair_seed;if(repair)repair_seed=fresh;
            uint64_t repair_used=0;bool retry=repair;
            for(unsigned strategy=0;strategy<2 && trial_maximum(retry);++strategy) {
              const bool active=retry;if(strategy && active)fresh=repair_seed;
              // Movement needs the whole admitted domain, not donors for the previous proposal's queries.
              DonorPatch donors;
              { Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);
                ++stats.donor_batches;
                donors=trial_import_cells(active ? old.cells : std::vector<Cell>{},options.memory_ceiling,
                    transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch));
              }
              CLocalFailure local;ConnectivityRepairReport report;bool repaired=false,missing_metric_star=false;
              if(!donors.valid && !DonorCap(donors.reason))local.Set(1,0,donors.reason);
              if(!(ready=context.exchange.Vote(context, local)))return false;
              if(active && donors.valid)try {
                const auto components=AssociatedExtensions(donors.cells,geometry);
                observe_transaction("support_donors",donors.valid,&donors);
                FrozenField target(std::move(donors.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
                FieldAccounting accounting{stats,target};
                Patch proposal;std::string rejected;
                { Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
                  // Probe the whole actual-field interface before exhausting repair on a fixed support point.
                  RepairMetricConnectivity(fresh,target,geometry,options.wall_heights,
                      maximum_cell+1+offset,proposal,report,rejected,0);
                  missing_metric_star=report.blocked_interior_vertex!=UINT64_MAX;
                  if(missing_metric_star && !preferred_obstruction.count)
                    preferred_obstruction={{{report.blocked_interior_vertex,0,0}},1};
                  if(!missing_metric_star)repaired=RepairMetricConnectivity(fresh,target,geometry,options.wall_heights,
                      maximum_cell+1+offset,proposal,report,rejected,repair_limit-repair_used,strategy==0);
                }
                stats.wall_joint_trials+=report.trials;stats.wall_joint_moves+=report.moves;stats.wall_joint_removals+=report.removals;
                stats.wall_joint_flips+=report.flips;stats.wall_joint_vertex_moves+=report.vertex_moves;
                stats.wall_joint_coordinated+=report.coordinated;stats.wall_joint_solve_rejected+=report.solve_rejected;
                stats.wall_joint_move_geometry_rejected+=report.move_geometry_rejected;
                stats.wall_joint_move_height_rejected+=report.move_height_rejected;
                stats.wall_joint_move_loss_rejected+=report.move_loss_rejected;
                stats.metric_linearizations+=report.linearizations;stats.metric_probes+=report.metric_probes;
                stats.metric_linear_iterations+=report.linear_iterations;stats.metric_solve_trials+=report.solve_trials;
                if(repaired) {
                  std::map<Id,Point> previous;std::set<Id> used;
                  for(const auto& c:old.cells)for(auto n:c.v)previous.emplace(n.id,n.p);
                  for(const auto& c:proposal.cells)for(auto n:c.v)used.insert(n.id);
                  std::map<Id,Id> renamed;size_t cursor=0;const Id first_node=maximum_node+1+node_offset;
                  for(const auto& c:proposal.cells)for(auto n:c.v) {
                    const auto found=previous.find(n.id);
                    if(found==previous.end() || renamed.count(n.id))continue;
                    const auto p=found->second;
                    if(p.x==n.p.x && p.y==n.p.y && p.z==n.p.z)continue;
                    while(cursor<construction_nodes && used.count(first_node+cursor))++cursor;
                    if(cursor==construction_nodes)throw std::invalid_argument("Native3D joint movement exceeds reserved node identities.");
                    renamed.emplace(n.id,first_node+cursor);used.insert(first_node+cursor++);
                  }
                  // Fresh identities invalidate selection reuse and preserve transfer's unchanged-node contract.
                  for(auto& c:proposal.cells)for(auto& n:c.v)if(renamed.count(n.id))n.id=renamed.at(n.id);
                  for(auto& f:proposal.surface)for(auto& id:f.v)if(renamed.count(id))id=renamed.at(id);
                  fresh=std::move(proposal);repaired=guarded_geometry(true);
                }
              }catch(const std::exception& e){local.Set(2,0,e.what());}
              repair_used+=report.trials;
              stats.global_work+=trial_reduce(uint64_t(report.trials),CPassiveComm::Op::SUM);
              if(!(ready=context.exchange.Vote(context, local)))return false;
              close_first=close_first || trial_maximum(missing_metric_star);
              if(trial_maximum(repaired)) {
                const bool accepted=validate_joint(repaired);
                if(active)passed=accepted;
                stats.wall_joint_accepted+=repaired && accepted;
                if(!ready)return false;
              }
              if(active && !passed && report.blocked_interior_vertex!=UINT64_MAX && !preferred_obstruction.count)
                preferred_obstruction={{{report.blocked_interior_vertex,0,0}},1};
              // Shape-only retirement may lose required size resolution; backtrack within the same trial allocation.
              retry=active && strategy==0 && repaired && !passed && report.complete_shape && report.removals &&
                  certified.failure==MetricFailure::Progress && repair_used<repair_limit;
            }
          }
          if(participating && !passed)try {
            if(candidate && certified.failure==MetricFailure::Shape) {
              const auto boundary=Incidence(old.cells).Boundary();std::set<Face> artificial;std::set<Id> fixed,physical;
              for(const auto& f:old.surface)physical.insert(f.v.begin(),f.v.end());
              for(auto f:boundary)if(std::none_of(old.surface.begin(),old.surface.end(),[&](const auto& p){return Key(p.v)==Key(f);})) {
                artificial.insert(Key(f));fixed.insert(f.begin(),f.end());
              }
              for(const auto& c:fresh.cells)if(c.id==certified.weakest_cell || c.id==certified.sliver_cell) {
                const auto faces=Faces(c);
                const auto found=std::find_if(faces.begin(),faces.end(),[&](Face f){return artificial.count(Key(f));});
                if(found!=faces.end()){obstruction=Key(*found);if(!preferred_obstruction.count)preferred_obstruction={obstruction,3};break;}
                for(auto n:c.v)if(fixed.count(n.id) && !physical.count(n.id) && !preferred_obstruction.count)
                  preferred_obstruction={{{n.id,0,0}},1};
              }
            }
            // Preserve the first mechanism's actual blockage; a later fallback must not overwrite its dependency.
            if(!preferred_obstruction.count && obstruction!=Face{})preferred_obstruction={obstruction,3};
          }catch(const std::exception& e){failure.Set(2,0,e.what());}
          if(!(ready=context.exchange.Vote(context, failure)))return false;
          if(participating) {
            stats.wall_topology_accepted+=passed && retained_frame && frame<retained_frames && wallSplit;
            approved=passed;
            if(passed && std::any_of(old.surface.begin(),old.surface.end(),[&](const auto& f) {
              return options.wall_heights.count(geometry.Get(f.facet).marker);
            }))++stats.wall_reconstruction_accepted;
          }
          if(!ready)return false;
          // Resolve a required retained-row interface before spending trials on incomplete fallback fans.
          if(close_first || !trial_maximum(joint && !approved))break;
        }
        if(joint && approved){cavity_inserted=true;joint=false;}
        else if(joint && candidate && certified.failure==MetricFailure::Measurement)joint=false;
        if(!trial_maximum(joint && !approved))break;
        if(!preferred_obstruction.count && std::adjacent_find(obstruction.begin(),obstruction.end())==obstruction.end())preferred_obstruction={obstruction,3};
        const bool grow=joint && preferred_obstruction.count;
        const auto added_dependencies=directory->LookupBatch(grow ? std::vector<Feature>{preferred_obstruction} : std::vector<Feature>{},
            options.memory_ceiling,transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));
        if(!added_dependencies.valid){result.reason=added_dependencies.reason;return false;}
        Dependencies neighbor;neighbor.valid=true;
        if(grow) {
          neighbor=added_dependencies.candidates.at(0);
          if(!neighbor.valid) {
            if(neighbor.reason=="Native 3D dependency star exceeds budget.")joint=false;
            else failure.Set(1,0,neighbor.reason);
          }
        } else joint=false;
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        if(!trial_maximum(joint))break;
        if(!joint)neighbor.cells.clear();
        neighbor.valid=true;
        const auto more=directory->Fetch(neighbor,working,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch));
        if(!more.valid){result.reason=more.reason;return false;}
        if(joint)try {
          auto joined=dependencies.cells;auto payload=imported.cells;
          for(const auto& dep:neighbor.cells) {
            const auto found=std::find_if(joined.begin(),joined.end(),[&](const auto& d){return d.cell==dep.cell;});
            if(found!=joined.end()) {
              if(found->version!=dep.version || found->owner!=dep.owner)throw std::runtime_error("Native3D joint dependency changed ownership/version.");
            } else joined.push_back(dep);
          }
          if(joined.size()==dependencies.cells.size() || joined.size()>MaximumCavityCells)joint=false;
          if(joint) {
            for(const auto& row:more.cells)if(std::none_of(payload.begin(),payload.end(),[&](const auto& c){return c.cell.id==row.cell.id;}))payload.push_back(row);
            dependencies.cells.swap(joined);imported.cells.swap(payload);old=GeometryPatch(imported, &geometry);reuse.clear();
            for(const auto& c:old.cells)selection.Cached(c,reuse);
          }
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        if(!trial_maximum(joint))break;
        const bool reserved=reserve_dependencies(imported,joint,result.reason,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch),choice.reservation_priority);
        CLocalFailure reservation_failure;
        if(joint && !reserved) {
          if(directory->PassDeferred()) {++stats.conflicts;joint=false;approved=false;}
          else if(concurrent && result.reason=="Native 3D conflicting dependency reservation.")++stats.conflicts;
          else reservation_failure.Set(1,0,"Native3D joint patch lost complete dependency reservation.");
        }
        if(!(ready=context.exchange.Vote(context, reservation_failure)))return false;
        if(!trial_maximum(joint))break;
        try {observe_transaction("growth_reserved",reserved);}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(capture && !context.exchange.Vote(context, failure))return false;
        const bool measured=measure_private(joint ? old.cells : empty,before,false,reuse,&old);
        if(!ready)return false;
        CLocalFailure old_invalid;if(joint && !measured)old_invalid.Set(1,0,result.reason);
        if(!(ready=context.exchange.Vote(context, old_invalid)))return false;
      }
      const bool fallback=metric_needed && old_measured && repairing && !selection.size_repairs;
      if (fallback && !repairing) ++stats.repair_fallbacks;
      const bool move=repairing ? choice.feature.count==1 : coarsening;
      const Id vertex=repairing ? choice.feature.vertices[0] : choice.edge[1];
      std::map<Id,Node> nodes;
      { Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);
        try { if (fallback) for (const auto& cell:old.cells) for (auto node:cell.v) nodes.emplace(node.id,node); }
        catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        ready=context.exchange.Vote(context, failure);
      }
      if (!ready) return false;
      Point moveCenter{};
      if(composition && trial_maximum(fallback && move && !approved)) {
        const bool participating=fallback && move && !approved;
        std::set<Id> neighbors;std::map<Id,Tensor> samples;Point origin{};
        try {if(participating) {
          origin=nodes.at(vertex).p;
          for(const auto& f:old.surface)if(std::find(f.v.begin(),f.v.end(),vertex)!=f.v.end())neighbors.insert(f.v.begin(),f.v.end());
          if(neighbors.empty())for(const auto& n:nodes)neighbors.insert(n.first);
          neighbors.erase(vertex);
        }}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        std::vector<Id> query_ids;
        try {query_ids.assign(neighbors.begin(),neighbors.end());}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        const auto count=trial_reduce(query_ids.size(),CPassiveComm::Op::MAX);
        for(size_t at=0;at<count;at+=MaximumCavityCells) {
          std::vector<std::array<Point,2>> queries;
          try {for(size_t i=at;i<std::min(at+MaximumCavityCells,query_ids.size());++i)queries.push_back({origin,nodes.at(query_ids[i]).p});}
          catch(const std::exception& e){failure.Set(2,0,e.what());}
          if(!(ready=context.exchange.Vote(context, failure)))return false;
          DonorSamples answer;
          {Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);++stats.donor_batches;
            answer=trial_sample_midpoints(queries,eligible_extensions,options.memory_ceiling,
                transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch));}
          if(!answer.valid){result.reason=answer.reason;return false;}
          try {for(size_t i=0;i<queries.size();++i) {
            const auto a=queries[i][0],b=queries[i][1];
            const Point p{double(((long double)a.x+b.x)/2),double(((long double)a.y+b.y)/2),double(((long double)a.z+b.z)/2)};
            samples.emplace(query_ids[at+i],EngineTrial::ComposedSample(context, p,answer.samples.at(i).sensor));
          }}catch(const std::exception& e){failure.Set(2,0,e.what());}
          if(!(ready=context.exchange.Vote(context, failure)))return false;
        }
        try {if(participating && !neighbors.empty()) {
          std::vector<std::pair<Point,Tensor>> values;for(auto id:neighbors)values.emplace_back(nodes.at(id).p,samples.at(id));
          moveCenter=MetricMeanPoint(origin,values,coordinate_only ? 4*old.cells.size() : 4*MaximumCavityCells);
        }}catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
      }
      auto optimize_repair=[&]() {
        if(surface_target || selection.geometry_repairs || !repairing || !trial_maximum(!coordinate_only && repair_work<160 && chosen && !approved))return true;
        const auto began=Clock::now();const auto calls_before=stats.optimization_trials;const auto work_before=repair_work;
        const auto geometry_before=stats.geometry_rejected,height_before=stats.height_rejected+stats.footprint_rejected;
        bool validated=false;
        reserve_optimization(!coordinate_only && repair_work<160 && chosen && !approved);
        DonorPatch donors;
        {Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);++stats.donor_batches;
          donors=trial_import_cells(!coordinate_only && repair_work<repair_budget && !approved?old.cells:empty,options.memory_ceiling,
              transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch));}
        bool candidate=false;
        if(!donors.valid && !DonorCap(donors.reason)){result.reason=donors.reason;return false;}
        if(!coordinate_only && repair_work<repair_budget && !approved && donors.valid)try {
          const auto components=AssociatedExtensions(donors.cells,geometry);
          observe_transaction("support_donors",donors.valid,&donors);
          FrozenField proposal_field(std::move(donors.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
          FieldAccounting accounting{stats,proposal_field};
          Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
          candidate=guarded_geometry(optimize_patch(old,RegionMetric(proposal_field),false),"OptimizeMetricMesh");
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!(ready=context.exchange.Vote(context, failure)))return false;
        release_optimization();
        if(trial_maximum(candidate || (selection.size_repairs && chosen))) {
          const bool placed=validate_private(candidate,MetricChange::Repair);
          if(!ready)return false;
          if(placed){approved=repair_approved=true;moved=false;optimization_approved=true;++stats.optimization_validated;validated=true;}
        }
        if(stats.optimization_trials>calls_before)note_ladder(1,validated,began,geometry_before,height_before,repair_work-work_before);
        return true;
      };
      for (unsigned trial=0;trial<19;++trial) {
        // Keep cheap coordinate trials first; one bounded coupled solve precedes serial topology guesses.
        if(trial==3 && !optimize_repair())return false;
        if (!trial_maximum(fallback && !approved)) break;
        const bool move_trial=trial<3;
        const bool participating=fallback && !approved && (!coordinate_only || move_trial) &&
            (move_trial ? move : (!move || (repairing && choice.feature.count==1) || (!repairing && coarsening))) &&
            (move_trial || trial-3<nodes.size());
        if (!trial_maximum(participating)) continue;
        const auto trial_started=Clock::now();const auto geometry_before=stats.geometry_rejected,height_before=stats.height_rejected+stats.footprint_rejected;
        bool candidate=false;
        { Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);
          if (participating) try {
            CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
            ++stats.repair_proposals;
            const Id first=maximum_cell+1+offset;
            if (move_trial && maximum_node<=UINT64_MAX-node_stride && node_offset<=UINT64_MAX-maximum_node-node_stride) {
              std::set<Id> neighbors;
              for (auto face:old.surface) if (std::find(face.v.begin(),face.v.end(),vertex)!=face.v.end())
                neighbors.insert(face.v.begin(),face.v.end());
              if (neighbors.empty()) for (const auto& row:nodes) neighbors.insert(row.first);
              neighbors.erase(vertex);
              long double x=0,y=0,z=0;
              for (Id id:neighbors) { auto p=nodes.at(id).p; x+=p.x; y+=p.y; z+=p.z; }
              if (!neighbors.empty()) {
                const auto p=nodes.at(vertex).p; const long double step=trial==0 ? 1.L : (trial==1 ? .5L : .25L);
                point={maximum_node+1+node_offset,{double(p.x+step*(x/neighbors.size()-p.x)),
                    double(p.y+step*(y/neighbors.size()-p.y)),double(p.z+step*(z/neighbors.size()-p.z))}};
                if(composition) {
                  point.p={double(p.x+step*(moveCenter.x-p.x)),double(p.y+step*(moveCenter.y-p.y)),double(p.z+step*(moveCenter.z-p.z))};
                  point=ConstrainMovePoint(old,vertex,point,options.wall_heights,geometry);
                }
                candidate=guarded_geometry(MoveVertex(old,vertex,point,first,geometry,fresh,result.reason,nullptr,
                    coordinate_only ? old.cells.size() : MaximumCavityCells),"MoveVertex");
              }
            } else if (!move_trial) {
              auto apex=nodes.begin(); std::advance(apex,trial-3);
              if(move && repairing && choice.feature.count==1) {
                if(apex->first!=vertex)
                  candidate=guarded_geometry(CollapseVertex(old,vertex,apex->first,first,geometry,fresh,result.reason),"CollapseVertex");
              }
              else candidate=guarded_geometry(Reconnect(old,apex->first,first,geometry,fresh,result.reason),"Reconnect");
            }
          } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
          ready=context.exchange.Vote(context, failure);
        }
        if (!ready) return false;
        const bool valid=validate_private(candidate,MetricChange::Repair);
        if (!ready) return false;
        if (valid) { approved=true; repair_approved=true; moved=move_trial; }
        if(participating)note_ladder(move_trial?0:2,valid,trial_started,geometry_before,height_before);
      }
      if(selection.geometry_repairs && !coordinate_only && chosen && !approved && curved &&
          maximum_node<=UINT64_MAX-node_stride && node_offset<=UINT64_MAX-maximum_node-node_stride) {
        reserve_optimization(true);
        std::map<Id,Node> nodes;std::set<Edge> edges;
        for(const auto& cell:old.cells)for(auto n:cell.v)nodes.emplace(n.id,n);
        auto geometry_counts=[&](const Patch& patch,std::set<Edge>* failed_edges=nullptr) {
          Timer timer(stats.geometry_guidance_seconds,options.timings, SU2NativeTiming3D::Operation::GeometryBound);
          auto parameters=geometry.PrivateParameters(patch);const auto& reference=parameters?*parameters:geometry;
          std::map<Face,Id> facets;for(const auto& face:patch.surface)facets.emplace(Key(face.v),face.facet);
          std::pair<size_t,size_t> counts{};
          for(const auto& cell:patch.cells) {
            atlas_budget.CheckTime();
            bool bad=false;
            for(const auto& face:Faces(cell)) {
              const auto found=facets.find(Key(face));if(found==facets.end())continue;
              std::array<Point,3> triangle;
              for(unsigned k=0;k<3;++k)for(auto n:cell.v)if(n.id==face[k])triangle[k]=n.p;
              const auto error=reference.SurfaceDeviation(found->second,triangle,SU2NativeGeometry::SurfaceQueryNeed::Classify());++stats.geometry_guidance_faces;
              if(!std::isfinite(error))throw std::runtime_error("Native3D coupled repair lacks a complete face certificate.");
              if(error<=options.surface_tolerance)continue;
              bad=true;++counts.second;
              if(failed_edges)for(unsigned k=0;k<3;++k) {
                Edge edge{face[k],face[(k+1)%3]};std::sort(edge.begin(),edge.end());failed_edges->insert(edge);
              }
            }
            counts.first+=bad;
          }
          return counts;
        };
        const auto old_counts=geometry_counts(old,&edges);
        std::set<Face> physical;for(const auto& face:old.surface)physical.insert(Key(face.v));
        for(const auto& face:Incidence(old.cells).Boundary())if(!physical.count(Key(face)))
          for(unsigned k=0;k<3;++k) {
            Edge edge{face[k],face[(k+1)%3]};std::sort(edge.begin(),edge.end());edges.erase(edge);
          }
        DonorPatch donors;
        {Timer timer(stats.donor_seconds,options.timings, SU2NativeTiming3D::Operation::Import);++stats.donor_batches;
          donors=trial_import_cells(repair_work<repair_budget?old.cells:empty,options.memory_ceiling,
              transfer_memory::Add(context.exchange.Bytes(context),directory->ResidentBytes(),private_scratch));}
        if(!donors.valid && !DonorCap(donors.reason)){result.reason=donors.reason;return false;}
        if(donors.valid && repair_work<repair_budget) {
          const auto components=AssociatedExtensions(donors.cells,geometry);
          observe_transaction("support_donors",true,&donors);
          FrozenField target(std::move(donors.cells),composition,options.timings,components,options.edge_breakpoints,field_identity,true,MaximumDonors,true);
          FieldAccounting accounting{stats,target};
          for(const auto& edge:edges) {
            if(approved || repair_work>=repair_budget ||
                (options.maximum_seconds && std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds))break;
            const auto began=Clock::now();const auto geometry_before=stats.geometry_rejected;
            const auto height_before=stats.height_rejected+stats.footprint_rejected;const auto work_before=repair_work;
            ++repair_work;++stats.repair_proposals;
            const auto a=nodes.at(edge[0]).p,b=nodes.at(edge[1]).p;
            point={maximum_node+1+node_offset,{double(((long double)a.x+b.x)/2),
                double(((long double)a.y+b.y)/2),double(((long double)a.z+b.z)/2)}};
            bool candidate;
            {Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
              candidate=guarded_geometry(SplitSurfaceStrip(old,edge,point,{},maximum_cell+1+offset,
                  geometry,fresh,result.reason),"SplitSurfaceStrip");}
            if(candidate) {
              const auto counts=geometry_counts(fresh);
              candidate=EngineTrial::GeometryTrial(context, counts.first<=old_counts.first && counts.second<old_counts.second);
            }
            bool valid=validate_private(candidate,MetricChange::GeometryRepair);
            if(!ready)return false;
            // Reclose shape privately; only the complete replacement is eligible for publication.
            if(candidate && !valid && geometric_progress && certified.shape_measured &&
                (certified.minimum_mean_ratio<MinimumMeanRatio || certified.minimum_scaled_jacobian<MinimumScaledJacobian) &&
                repair_work<repair_budget) {
              const Patch split=fresh;
              {Timer timer(stats.reconstruction_seconds,options.timings, SU2NativeTiming3D::Operation::Candidate);CpuTimer cpu(stats.reconstruction_cpu_seconds,options.timings);
                candidate=guarded_geometry(optimize_patch(split,RegionMetric(target),false),"OptimizeGeometrySplit");}
              valid=validate_private(candidate,MetricChange::GeometryRepair);
              if(!ready)return false;
              if(valid) {
                const auto counts=geometry_counts(fresh);
                valid=EngineTrial::GeometryTrial(context, counts.first<=old_counts.first && counts.second<old_counts.second);
                if(valid){optimization_approved=true;++stats.optimization_validated;}
              }
            }
            if(valid){approved=repair_approved=true;moved=false;}
            note_ladder(2,valid,began,geometry_before,height_before,repair_work-work_before);
          }
        }
        release_optimization();
      }
      if(selection.size_repairs && !optimize_repair())return false;
      if (repair_approved && !repairing) ++stats.fallback_accepted;
    }
    try {observe_transaction("construction_end",approved);}catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(options.transaction_observer && !context.exchange.Vote(context, failure))return false;
      return true;
    };
    if(repairing) {
      if(options.maximum_seconds&&std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds) {
        private_deadline=true;private_failure.Set(1,0,"Native3D private repair round exhausts elapsed-time budget.");break;
      }
      bool evaluated=false;private_repair=true;
      try {
        evaluated=evaluate_candidate();
        if(evaluated) {
          // Coverage has variable piece/limb storage; the per-cell reserve cannot bound retained overlays.
          size_t retained_coverage=0;
          auto admit_coverage=[&]() {
            const auto live=transfer_memory::Add(BoundaryCoverageBytes(old.coverage),BoundaryCoverageBytes(fresh.coverage));
            if(live==SIZE_MAX||live<retained_coverage)throw std::length_error("Native3D retained repair coverage exceeds storage admission.");
            batch_bytes=transfer_memory::Add(batch_bytes,live-retained_coverage);retained_coverage=live;
            return context.exchange.Admit(context, private_scratch);
          };
          evaluated=admit_coverage();
          if(evaluated&&approved&&geometry.Mapped()) {
            geometry.ExportParameters(old);evaluated=admit_coverage();
            if(evaluated){geometry.ExportParameters(fresh);evaluated=admit_coverage();}
          }
          if(evaluated&&approved&&!boundary_replacement_ready()) {
            EngineTrial::GeometryTrial(context, false);
            approved=repair_approved=optimization_approved=geometric_progress=false;
            if(accepted_ladder<3)++stats.quality.ladder[accepted_ladder].rejected[0];
          }
        }
      }catch(const std::exception& e){result.reason=e.what();evaluated=false;}
      private_repair=false;private_work_used+=repair_work;
      if(!evaluated){private_failure.Set(2,0,result.reason);break;}
      lane_counters.Approved(true, lane_slots[slot], approved);
      try {
        auto& proposal=repair_proposals.at(slot);proposal.choice=choice;
        proposal.dependencies=std::move(dependencies);proposal.imported=std::move(imported);
        proposal.old=std::move(old);proposal.fresh=std::move(fresh);proposal.point=point;proposal.certified=certified;
        proposal.optimization=repair_optimization;proposal.chosen=chosen;proposal.approved=approved;
        proposal.coordinate_only=coordinate_only;proposal.moved=moved;proposal.repair_approved=repair_approved;
        proposal.cavity_inserted=cavity_inserted;proposal.optimization_approved=optimization_approved;
        proposal.geometric_progress=geometric_progress;proposal.capture=capture;proposal.capture_selected=capture_selected;
        proposal.first_cell=maximum_cell+1+offset;proposal.first_node=maximum_node+1+node_offset;
        proposal.optimizer_work=repair_work;proposal.rejection=approved?std::string{}:result.reason;
        proposal.ladder=accepted_ladder;proposal.old_flags=std::move(old_flags);proposal.fresh_flags=std::move(fresh_flags);
      }catch(const std::exception& e){private_failure.Set(2,0,e.what());break;}
      continue;
    }
    if(surface_target && coarsening && !repairing && !observe_rejections) {
      // The complete reserved collapse cavity supplies every retained node. Opaque callbacks keep the collective path.
      const auto elections=world.election_collective_calls,collectives=world.collective_calls,work=stats.global_work;
      CLocalFailure local;bool evaluated=false;private_repair=true;
      try{evaluated=evaluate_candidate();}catch(const std::exception& e){result.reason=e.what();}
      if(atlas_budget.within_time && !atlas_budget.within_time())atlas_budget.time_exhausted=true;
      private_repair=false;
      if(!evaluated)local.Set(2,0,result.reason.empty()?"Native3D private surface collapse evaluation failed.":result.reason);
      if(world.election_collective_calls!=elections || world.collective_calls!=collectives || stats.global_work!=work)
        local.Set(2,0,"Native3D private surface collapse performed collective or unreserved operator work.");
      if(!(ready=context.exchange.Vote(context, local)))return finish();
    } else if(!evaluate_candidate())return finish();
    lane_counters.Approved(false, lane_slots[slot], approved);
    if(chosen&&!approved&&!collapse_correction_refusal.empty())
      result.reason+=" Bounded correction: "+collapse_correction_refusal;
    // Successful peer contact/reservation votes must not erase this worker's construction refusal.
    ContextValue pending_rejection_lifetime(slot_state.pending_rejection,
                                            chosen && !approved ? result.reason : std::string{});
    const std::string& pending_rejection = pending_rejection_lifetime.Get();
    ContextValue surface_edit_lifetime(slot_state.surface_edit, approved && !SameSkin(old, fresh));
    const bool& surface_edit = surface_edit_lifetime.Get();
    if(timed_lane==2&&surface_edit&&!physical_edge)++stats.interior_boundary_discoveries;
    if((curved && world.maximum(surface_edit)) || world.maximum(coordinate_only && approved) ||
        world.maximum(collapse_corrected && approved)) {
      const bool prior=approved;bool deferred=false;
      if(!directory->Clearance(working,old,fresh,approved,result.reason,options.memory_ceiling,
          transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch),&deferred,choice.reservation_priority,
          coordinate_only ? imported.coordinate_star : Feature{}))return finish();
      if(deferred){chosen=false;++stats.conflicts;++stats.rejected;++stats.proposal_deferred;}
      else if(prior && !approved)EngineTrial::GeometryTrial(context, false);
    }
    if((concurrent || world.maximum(collapse_corrected)) && world.maximum(approved)) {
      Timer timer(stats.reservation_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);CLocalFailure final_failure;
      // Every approved proposal claims its final old footprint together, including completed peers.
      if(approved)try {
        if(old.cells.size()!=imported.cells.size() || dependencies.cells.size()!=imported.cells.size())
          throw std::runtime_error("Native3D final proposal lacks complete imported dependencies.");
        std::set<Id> cells;for(const auto& c:old.cells)if(!cells.insert(c.id).second)
          throw std::runtime_error("Native3D final proposal repeats an old cell.");
        for(const auto& d:dependencies.cells) {
          const auto row=std::find_if(imported.cells.begin(),imported.cells.end(),[&](const auto& c){return c.cell.id==d.cell;});
          if(!cells.erase(d.cell) || row==imported.cells.end() || row->version!=d.version)
            throw std::runtime_error("Native3D final proposal lost a versioned old cell.");
        }
      }catch(const std::exception& e){final_failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, final_failure))return finish();
      ++stats.final_reservations;
      const bool admitted=reserve_dependencies(imported,approved,result.reason,options.memory_ceiling,
          transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),private_scratch),choice.reservation_priority);
      if(approved && !admitted) {
        if(directory->PassDeferred() || result.reason=="Native 3D conflicting dependency reservation.") {
          approved=false;chosen=false;++stats.conflicts;++stats.rejected;++stats.proposal_deferred;
        }else final_failure.Set(1,0,"Native3D final proposal reservation failed: "+result.reason);
      }
      if(!context.exchange.Vote(context, final_failure))return finish();
      const auto commits=TimedAllreduce(uint64_t(approved),CPassiveComm::Op::SUM,world.comm);
      stats.maximum_parallel_commits=std::max(stats.maximum_parallel_commits,commits);

    }
    if(chosen && !approved && !pending_rejection.empty())result.reason=pending_rejection;
    ContextValue parameter_edits_lifetime(slot_state.parameter_edits);
    std::vector<BoundaryParameterEdit>& parameter_edits = parameter_edits_lifetime.Get();
    if(approved && geometry.Mapped())try {
      geometry.ExportParameters(old);geometry.ExportParameters(fresh);
      parameter_edits=BoundaryParameterState::Changes(old,fresh,geometry.Parameters()->Revision());
    }catch(const std::exception& e){approved=false;result.reason=e.what();}
    if(approved && !coarsening && !repairing && !repair_approved)
      for(const auto& cell:fresh.cells)for(auto node:cell.v)if(node.id==point.id)point=node;
    try {observe_transaction("transaction_end",approved);}catch(const std::exception& e){failure.Set(2,0,e.what());}
    if(options.transaction_observer && !context.exchange.Vote(context, failure))return finish();
    if (chosen && !approved) {
      // Keep the completed rejection consistent with the earlier private/budget-exit sample.
      stats.last_metric_rejection=certified;
      stats.last_rejected_feature=repairing ? choice.feature : Feature{{choice.edge[0],choice.edge[1],0},2};
      if (!old.cells.empty()) stats.last_rejected_cavity_centroid=Centroid(old.cells.front());
    }
    if (chosen && !approved) last_rejection = (repairing ? "feature " + std::to_string(choice.feature.count) + ":" +
        std::to_string(choice.feature.vertices[0]) : "edge " + std::to_string(choice.edge[0]) + "," + std::to_string(choice.edge[1])) + ": " + result.reason;
    if(chosen && !approved)EngineReports::RecordRejection(context, diagnostic_rejection_limit, stats.last_rejected_feature,&old,&certified,result.reason);
    ContextValue removals_lifetime(slot_state.removals, world.size);
    std::vector<std::vector<Dependency>>& removals = removals_lifetime.Get();
    ContextValue additions_lifetime(slot_state.additions, world.size);
    std::vector<std::vector<OwnedCell>>& additions = additions_lifetime.Get();
    ContextValue blocked_lifetime(slot_state.blocked, world.size);
    std::vector<std::vector<BlockedEdge>>& blocked = blocked_lifetime.Get();
    ContextValue removed_lifetime(slot_state.removed);
    std::vector<Dependency>& removed = removed_lifetime.Get();
    ContextValue added_lifetime(slot_state.added);
    std::vector<OwnedCell>& added = added_lifetime.Get();
    ContextValue failures_lifetime(slot_state.failures);
    std::vector<BlockedEdge>& failures = failures_lifetime.Get();
    {
      Timer timer(stats.routing_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
      if (chosen && !approved) ++stats.rejected;
      try {
        if (approved) {
          std::vector<Id> parents;
          if(coordinate_only) {
            if(fresh.cells.size()!=old.cells.size())throw std::logic_error("Native coordinate-star movement changed cell count.");
            for(const auto& cell:fresh.cells)parents.push_back(cell.id);
          } else if (repair_approved || cavity_inserted || collapse_corrected) {
            for (size_t i=0;i<fresh.cells.size();++i) parents.push_back(old.cells[i%old.cells.size()].id);
          } else for (const auto& cell:old.cells) {
            bool keep=false;
            for (auto node:cell.v) keep=keep || node.id==choice.edge[0];
            if (!coarsening || !keep) parents.push_back(cell.id);
            if (!coarsening) parents.push_back(cell.id);
          }
          if (fresh.cells.size()!=parents.size()) throw std::logic_error("Unexpected native tetrahedral edit layout.");
          std::map<Id,int> owners;std::map<Id,uint64_t> versions;
          for (const auto& row : dependencies.cells) {
            owners.emplace(row.cell,row.owner);versions.emplace(row.cell,row.version);removals[row.owner].push_back(row);
          }
          std::vector<OwnedCell> metric_rows;
          for(const auto& cell:fresh.cells){OwnedCell row;row.cell=cell;metric_rows.push_back(row);}
          PublishMetrics(imported.cells,metric_rows);
          std::map<Face,Id> physical;
          for (auto face : fresh.surface) physical.emplace(Key(face.v),face.facet);
          for (size_t i=0; i<fresh.cells.size(); ++i) {
            OwnedCell row=metric_rows.at(i);
            if(coordinate_only) {
              const auto version=versions.at(row.cell.id);
              if(version==UINT64_MAX)throw std::overflow_error("Native coordinate-star cell version overflows.");
              row.version=version+1;
            }
            const auto faces=Faces(row.cell);
            for (size_t f=0; f<4; ++f) {
              const auto found=physical.find(Key(faces[f]));
              if (found!=physical.end()) row.physical[f]={true,found->second};
            }
            additions[owners.at(parents[i])].push_back(row);
          }
        } else if (chosen && !pass_deferred) {
          std::set<int> owners;
          for (const auto& row : dependencies.cells) owners.insert(row.owner);
          for (int owner : owners) blocked[owner].push_back({choice.edge,choice.feature});
        }
      } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
      ready=context.exchange.Vote(context, failure);
      if (ready) {
        bool admitted=false;
        const auto baseline=transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes(),
            transfer_memory::Bytes(imported.cells),MaximumFrozenFieldBytes);
        removed=world.exchange(removals,&admitted,options.memory_ceiling,baseline);
        ready=admitted;
        if (ready) { added=world.exchange(additions,&admitted,options.memory_ceiling,baseline); ready=admitted; }
        if (ready) { failures=world.exchange(blocked,&admitted,options.memory_ceiling,baseline); ready=admitted; }
        if (!ready) result.reason="Native 3D publication routing exceeds storage budget.";
      }
    }
    if (!ready) return finish();
    {
      Timer timer(stats.publication_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
      ready=directory->Publish(working,removed,added,true,result.reason,options.memory_ceiling,
          transfer_memory::Add(context.exchange.RealBytes(context),source.ResidentBytes(),MaximumFrozenFieldBytes),parameter_edits,approved?fresh.coverage:no_coverage,geometry.AtlasReservation(),repairing);
    }
    if (!ready) return finish();
    EngineReports::UpdateFixedMetricCells(context, removed,added);
    if(bidirectional&&phase==Phase::Construction&&!coarsening) {
      const auto split_commits=TimedAllreduce(uint64_t(approved),CPassiveComm::Op::SUM,world.comm);
      stats.maximum_parallel_split_commits=std::max(stats.maximum_parallel_split_commits,split_commits);
    }
    if(!removed.empty() || !added.empty())selection.progress_consistent=false;
    // A completed attempt is served once on every replica. Conflict/deferred candidates never
    // enter this receipt stream and retain their waiting age.
    stats.length_pass_deferred+=pass_deferred&&!approved;
    const unsigned disposition=pass_deferred&&!chosen?2:certified.failure==MetricFailure::None?4:10+unsigned(certified.failure);
    if(!service_frontier(repairing ? choice.feature : Feature{{choice.edge[0],choice.edge[1],0},2},chosen||pass_deferred,approved,nullptr,0,disposition))return finish();
    ContextValue changed_lifetime(slot_state.changed);
    std::vector<Id>& changed = changed_lifetime.Get();
    {
      Timer timer(stats.update_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
      ready=context.exchange.Admit(context, transfer_memory::Add(
          batched&&repairing ? transfer_memory::Add(
              transfer_memory::GrowthBound(transfer_memory::Add(batch_changed.size(),added.size()),sizeof(Id)),
              transfer_memory::Mul(transfer_memory::Add(batch_touched.size(),directory->ChangedVertices().size()),sizeof(Id)+4*sizeof(void*)),
              transfer_memory::Mul(transfer_memory::Add(batch_supports.size(),directory->ChangedRepairSupports().size()),sizeof(std::array<Id,4>)+4*sizeof(void*))) : 0,
          checkpoint.valid ? transfer_memory::Mul(transfer_memory::Mul(4,transfer_memory::Add(removed.size(),added.size())),sizeof(Id)+4*sizeof(void*)) : 0,
          transfer_memory::Mul(working.size(),context.control.SelectionBound(context, selection.track_repairs)),
          transfer_memory::Mul(transfer_memory::Mul(6,removed.size()),sizeof(std::pair<const Edge,EdgeMeasure>)+4*sizeof(void*)),
          selection.track_repairs ? transfer_memory::Mul(transfer_memory::Mul(14,removed.size()),sizeof(RepairFeature)+4*sizeof(void*)) : 0,
          transfer_memory::Mul(failures.size(),2*(sizeof(std::pair<const Id,std::set<Id>>)+sizeof(Id)+8*sizeof(void*)))));
      if (ready) try {
        if(checkpoint.valid) {
          for(const auto& row:removed) {
            const auto found=selection.cells.find(row.cell);
            if(found==selection.cells.end())throw std::logic_error("Checkpoint trial lost a changed owned support row.");
            checkpoint.changed.insert(found->second.vertices.begin(),found->second.vertices.end());
          }
          for(const auto& row:added)for(auto node:row.cell.v)checkpoint.changed.insert(node.id);
        }
        // Retain retired scalars until all children are measured against this event's immutable source.
        for (const auto& row : removed) {
          const auto cached=selection.cells.find(row.cell);
          if(cached==selection.cells.end()){++stats.unmeasured_retired;continue;}
          for (auto key : cached->second.edges)retired_edges.emplace(key,selection.edges.at(key).measure);
          selection.Drop(row.cell);
        }
        selection.progress_consistent=!(batched&&repairing);
        for (const auto& row : added) changed.push_back(row.cell.id);
        for (auto row : failures) selection.Block(row.edge,row.feature,repairing);
        if (approved) {
          if(standalone_coarsening && checkpoint.valid)checkpoint.trial=true;
          improvement_changed=improvement_changed || repairing;
          construction_changed=construction_changed || !repairing;
          construction_generation_changed=construction_generation_changed || !repairing;
          ++stats.accepted;
          wall_counters.Accepted();
          if(!repairing && !coarsening)wall_counters.ObserveSplit(choice.geometric);
          if(options.timings && lane_slots[slot].required_primary_split)
            wall_counters.AcceptRequiredSplit(old,fresh,choice.edge,point.id);
          if(options.timings && lane_slots[slot].checked_primary_split)wall_counters.AcceptCheckedSplit();
          if (options.timings)
            lane_counters.Commit(false, lane_slots[slot], !surface_edit, parameter_edits.empty(),
                                 fresh.coverage.faces.empty() && fresh.coverage.traces.empty());
          if(!repairing){if(coarsening)++stats.length_collapses;else ++stats.length_splits;}
          if(optimization_approved) {
            stats.optimization_moves+=repair_optimization.moves;
            stats.optimization_insertions+=repair_optimization.insertions;
            stats.optimization_collapses+=repair_optimization.collapses;
            stats.optimization_swaps+=repair_optimization.swaps;
          }
          stats.geometry_progress+=geometric_progress;
          stats.size_progress+=certified.size_progress;
          stats.quality_progress+=certified.quality_progress;
          stats.cell_removals+=coarsening && !repair_approved && certified.cell_removal;
          if (cavity_inserted) ++stats.inserted;
          else if (repair_approved) { if (moved) ++stats.moved; else ++stats.reconnected; }
          else if (coarsening) result.collapses.push_back(choice.edge); else result.splits.push_back({choice.edge,point});
        }
        stats.maximum_owned=std::max(stats.maximum_owned,working.size());
        if(chosen&&approved&&!repairing&&!coarsening&&!repair_approved&&choice.measure.length>0) {
          Edge a{choice.edge[0],point.id},b{choice.edge[1],point.id};std::sort(a.begin(),a.end());std::sort(b.begin(),b.end());
          const auto first=campaign_edges.find(a),second=campaign_edges.find(b);
          if(first!=campaign_edges.end()&&second!=campaign_edges.end()) {
            ++stats.child_ratio_measured;
            stats.maximum_child_parent_ratio=std::max(stats.maximum_child_parent_ratio,
                double(std::max(first->second.length,second->second.length)/choice.measure.length));
          }
        }
      } catch (const std::exception& e) { failure.Set(2,0,e.what()); }
      if (ready) ready=context.exchange.Vote(context, failure);
      if(ready && batched && repairing) {
        try {
          batch_changed.insert(batch_changed.end(),changed.begin(),changed.end());
          batch_touched.insert(directory->ChangedVertices().begin(),directory->ChangedVertices().end());
          batch_supports.insert(directory->ChangedRepairSupports().begin(),directory->ChangedRepairSupports().end());
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        ready=context.exchange.Vote(context, failure);
      } else if (ready) ready=measure(changed,false,&stats.update_seconds);
      if (ready && !(batched&&repairing)) {
        try {
          selection.FinishRepairs();
          for(const auto& support:directory->ChangedRepairSupports())selection.TouchRepairSupport(support);
          for (Id vertex:directory->ChangedVertices()) selection.Touch(vertex);
          // Retire known conflicts in this pass without another global reservation per edge.
          // Unmeasured/remote support and expanded cavities remain guarded by Directory claims.
          if(bidirectional && (phase==Phase::Construction || metric_cleanup)&&construction_claims)
            for(Id vertex:directory->ChangedVertices())stats.length_pass_deferred+=selection.ServiceClaimedVertex(vertex);
        }
        catch (const std::exception& e) { failure.Set(2,0,e.what()); }
        ready=context.exchange.Vote(context, failure);
      }
      if(!(batched&&repairing))retired_edges.clear();
    }
    if (!ready) return finish();
    }
    if(repairing) {
      const double private_busy_seconds = std::chrono::duration<double>(Clock::now()-private_started).count();
      stats.quality.busy_seconds += private_busy_seconds;
      stats.quality.private_work_used += private_work_used;
      if (options.timings) {
        SU2NativeTiming3D::Scope output_timer(SU2NativeTiming3D::Operation::Output);
        std::cout << "NATIVE3D_PRIVATE_WORK rank=" << world.rank << " round=" << stats.rounds
                  << " private_work_used=" << private_work_used << " busy_seconds=" << private_busy_seconds << '\n';
      }
      stats.quality.private_tracked_collectives+=world.collective_calls+world.election_collective_calls-private_collectives;
      const auto joined=Clock::now();
      // The legacy counter still surrounds the same call; F3 names its join wait separately.
      const auto used = [&]() {
        SU2NativeTiming3D::Scope join_timer(SU2NativeTiming3D::Operation::JoinWait);
        return CPassiveComm::Allreduce(private_work_used, CPassiveComm::Op::SUM, world.comm);
      }();
      stats.quality.join_wait_seconds+=std::chrono::duration<double>(Clock::now()-joined).count();
      if(used>private_work_reserved)private_failure.Set(2,0,"Native3D private repair exceeds its common work reservation.");
      else stats.global_work-=private_work_reserved-used;
      private_deadline=private_deadline||(options.maximum_seconds&&std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds);
      if(world.maximum(private_deadline)) {
        stats.stop=EngineStop::TimeBudget;
        private_failure.Set(1,0,"Native3D private repair round exhausts elapsed-time budget.");
      }
      if(!context.exchange.Vote(context, private_failure))return finish();
      CLocalFailure failure;
      std::vector<ClearanceCandidate> contact;
      bool needs_contact=false;
      {
        SU2NativeTiming3D::Scope contact_timer(SU2NativeTiming3D::Operation::Clearance);
        try {
          contact.reserve(repair_proposals.size());
          for(auto& proposal:repair_proposals) {
            if(proposal.approved) {
              if(proposal.old.cells.size()!=proposal.imported.cells.size()||proposal.dependencies.cells.size()!=proposal.imported.cells.size())
                throw std::runtime_error("Native3D final repair lacks its complete imported dependencies.");
              std::set<Id> cells;for(const auto& c:proposal.old.cells)if(!cells.insert(c.id).second)
                throw std::runtime_error("Native3D final repair repeats an old cell.");
              for(const auto& dependency:proposal.dependencies.cells) {
                const auto row=std::find_if(proposal.imported.cells.begin(),proposal.imported.cells.end(),
                    [&](const OwnedCell& c){return c.cell.id==dependency.cell;});
                if(!cells.erase(dependency.cell)||row==proposal.imported.cells.end()||row->version!=dependency.version)
                  throw std::runtime_error("Native3D final repair lost a versioned old dependency.");
              }
              needs_contact=true; // Full vertex disjointness does not certify simultaneous physical contacts.
            }
            contact.push_back({&proposal.old,&proposal.fresh,proposal.approved,false,proposal.choice.reservation_priority,
                proposal.coordinate_only?proposal.imported.coordinate_star:Feature{}, {}});
          }
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
      }
      if(!context.exchange.Vote(context, failure))return finish();
      if(world.maximum(needs_contact)) {
        if(!directory->ClearanceBatch(working,contact,result.reason,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes())))return finish();
        for(size_t i=0;i<contact.size();++i) {
          auto& proposal=repair_proposals[i];const auto& checked=contact[i];
          if(checked.deferred) {
            proposal.chosen=false;++stats.conflicts;++stats.rejected;++stats.proposal_deferred;
          } else if(proposal.approved&&!checked.candidate)EngineTrial::GeometryTrial(context, false);
          if(proposal.approved&&!checked.candidate&&proposal.ladder<3)++stats.quality.ladder[proposal.ladder].rejected[5];
          proposal.approved=checked.candidate;
          if(!checked.reason.empty())proposal.rejection=checked.reason;
        }
      }
      ImportedBatch final_inputs;std::vector<unsigned> priorities;
      try {
        final_inputs.valid=true;final_inputs.candidates.resize(repair_proposals.size());priorities.reserve(repair_proposals.size());
        for(size_t i=0;i<repair_proposals.size();++i) {
          auto& proposal=repair_proposals[i];priorities.push_back(proposal.choice.reservation_priority);
          if(proposal.approved)final_inputs.candidates[i]=std::move(proposal.imported);
        }
      }catch(const std::exception& e){failure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, failure))return finish();
      ReservationBatch final_reserved;
      {
        Timer timer(stats.reservation_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);++stats.final_reservations;
        final_reserved=directory->ReserveBatch(final_inputs,options.memory_ceiling,
            transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes()),priorities);
      }
      if(!final_reserved.valid){result.reason=final_reserved.reason;return finish();}
      uint64_t commits=0;
      for(size_t i=0;i<repair_proposals.size();++i) {
        auto& proposal=repair_proposals[i];
        if(proposal.approved) {
          proposal.imported=std::move(final_inputs.candidates[i]);
          if(!final_reserved.chosen.at(i)) {
            if(proposal.ladder<3)++stats.quality.ladder[proposal.ladder].rejected[6];
            proposal.approved=proposal.chosen=false;++stats.conflicts;++stats.rejected;++stats.proposal_deferred;
          }
        }
        commits+=proposal.approved;
      }
      commits=TimedAllreduce(commits,CPassiveComm::Op::SUM,world.comm);
      stats.maximum_parallel_commits=std::max(stats.maximum_parallel_commits,commits);
      std::vector<std::vector<Dependency>> removals;
      std::vector<std::vector<OwnedCell>> additions;
      std::vector<std::vector<BlockedEdge>> blocked;
      std::vector<BoundaryParameterEdit> parameter_edits;
      SU2NativeGeometry::BoundaryCoverage coverage;
      std::array<RepairReceipt,MaximumCandidateBatch> receipts{};size_t receipt_count=0;
      {
        Timer timer(stats.routing_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
        try {
          removals.resize(world.size);additions.resize(world.size);blocked.resize(world.size);
          for(auto& proposal:repair_proposals) {
            if(proposal.approved) {
              if(geometry.Mapped()) {
                auto edits=BoundaryParameterState::Changes(proposal.old,proposal.fresh,geometry.Parameters()->Revision());
                if (options.timings)
                  lane_slots[&proposal - repair_proposals.data()].no_parameter_edits = edits.empty();
                parameter_edits.insert(parameter_edits.end(),edits.begin(),edits.end());
              }
              for(const auto& face:proposal.fresh.coverage.faces)if(!coverage.faces.emplace(face).second)
                throw std::runtime_error("Native3D private repairs share a boundary coverage face.");
              for(const auto& trace:proposal.fresh.coverage.traces)if(!coverage.traces.emplace(trace).second)
                throw std::runtime_error("Native3D private repairs share a boundary coverage trace.");
              std::map<Id,int> owners;std::map<Id,uint64_t> versions;
              for(const auto& dependency:proposal.dependencies.cells) {
                owners.emplace(dependency.cell,dependency.owner);versions.emplace(dependency.cell,dependency.version);
                removals.at(dependency.owner).push_back(dependency);
              }
              std::vector<OwnedCell> metric_rows;
              for(const auto& cell:proposal.fresh.cells){OwnedCell row;row.cell=cell;metric_rows.push_back(row);}
              PublishMetrics(proposal.imported.cells,metric_rows);
              std::map<Face,Id> physical;for(const auto& face:proposal.fresh.surface)physical.emplace(Key(face.v),face.facet);
              if(proposal.coordinate_only&&proposal.fresh.cells.size()!=proposal.old.cells.size())
                throw std::logic_error("Native3D coordinate repair changes cell count.");
              for(size_t i=0;i<metric_rows.size();++i) {
                auto& row=metric_rows[i];
                const Id parent=proposal.coordinate_only?row.cell.id:proposal.old.cells.at(i%proposal.old.cells.size()).id;
                if(proposal.coordinate_only) {
                  const auto version=versions.at(row.cell.id);
                  if(version==UINT64_MAX)throw std::overflow_error("Native3D coordinate repair version overflows.");
                  row.version=version+1;
                }
                const auto faces=Faces(row.cell);
                for(size_t f=0;f<4;++f) {
                  const auto found=physical.find(Key(faces[f]));if(found!=physical.end())row.physical[f]={true,found->second};
                }
                additions.at(owners.at(parent)).push_back(std::move(row));
              }
            } else if(proposal.chosen) {
              ++stats.rejected;stats.last_metric_rejection=proposal.certified;stats.last_rejected_feature=proposal.choice.feature;
              if(!proposal.old.cells.empty())stats.last_rejected_cavity_centroid=Centroid(proposal.old.cells.front());
              last_rejection="feature "+std::to_string(proposal.choice.feature.count)+":"+
                  std::to_string(proposal.choice.feature.vertices[0])+": "+proposal.rejection;
              EngineReports::RecordRejection(context, diagnostic_rejection_limit, proposal.choice.feature,&proposal.old,&proposal.certified,proposal.rejection);
              std::set<int> owners;for(const auto& dependency:proposal.dependencies.cells)owners.insert(dependency.owner);
              for(int owner:owners)blocked.at(owner).push_back({proposal.choice.edge,proposal.choice.feature});
            }
            if(proposal.chosen) {
              if(receipt_count==MaximumCandidateBatch)throw std::logic_error("Native3D repair receipts exceed round bound.");
              receipts[receipt_count++]={proposal.choice.feature,proposal.approved,
                  proposal.certified.failure==MetricFailure::None?4u:10u+unsigned(proposal.certified.failure)};
            }
            if(proposal.capture)options.transaction_observer({"transaction_end",proposal.choice.feature,uint64_t(round),
                proposal.capture_selected,proposal.approved,working,geometry,proposal.dependencies,proposal.imported,
                proposal.old,proposal.fresh,proposal.point,proposal.first_cell,proposal.first_node,proposal.certified,
                proposal.rejection,nullptr,composition,options.edge_breakpoints});
          }
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
      }
      if(!context.exchange.Vote(context, failure))return finish();
      std::vector<Dependency> removed;std::vector<OwnedCell> added;std::vector<BlockedEdge> failures;
      {
        Timer timer(stats.routing_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);bool admitted=false;
        const auto baseline=transfer_memory::Add(context.exchange.Bytes(context),source.ResidentBytes(),directory->ResidentBytes());
        removed=world.exchange(removals,&admitted,options.memory_ceiling,baseline);
        if(!admitted){result.reason="Native3D round removal routing exceeds storage budget.";return finish();}
        added=world.exchange(additions,&admitted,options.memory_ceiling,transfer_memory::Add(baseline,transfer_memory::Bytes(removed)));
        if(!admitted){result.reason="Native3D round addition routing exceeds storage budget.";return finish();}
        failures=world.exchange(blocked,&admitted,options.memory_ceiling,
            transfer_memory::Add(baseline,transfer_memory::Bytes(removed),transfer_memory::Bytes(added)));
        if(!admitted){result.reason="Native3D round rejection routing exceeds storage budget.";return finish();}
      }
      batch_bytes=transfer_memory::Add(batch_bytes,transfer_memory::Bytes(removed),transfer_memory::Bytes(added),
          transfer_memory::Bytes(failures),transfer_memory::Bytes(removals),transfer_memory::Bytes(additions),
          transfer_memory::Bytes(blocked),transfer_memory::Bytes(contact),transfer_memory::Bytes(parameter_edits),
          BoundaryCoverageBytes(coverage),transfer_memory::GrowthBound(added.size(),sizeof(Id)));
      if(!context.exchange.Admit(context, 0))return finish();
      {
        Timer timer(stats.publication_seconds,options.timings, SU2NativeTiming3D::Operation::Communication);
        if(!directory->Publish(working,removed,added,true,result.reason,options.memory_ceiling,
            transfer_memory::Add(context.exchange.RealBytes(context),source.ResidentBytes(),MaximumFrozenFieldBytes),parameter_edits,coverage,geometry.AtlasReservation(),true))return finish();
      }
      EngineReports::UpdateFixedMetricCells(context, removed,added);
      if(!removed.empty()||!added.empty())selection.progress_consistent=false;
      if(!service_frontier({},false,false,&receipts,receipt_count))return finish();
      {
        Timer timer(stats.update_seconds,options.timings, SU2NativeTiming3D::Operation::Topology);
        if(!context.exchange.Admit(context, transfer_memory::Add(transfer_memory::Mul(working.size(),context.control.SelectionBound(context, true)),
            transfer_memory::Mul(transfer_memory::Mul(6,removed.size()),sizeof(std::pair<const Edge,EdgeMeasure>)+4*sizeof(void*)),
            transfer_memory::Mul(transfer_memory::Mul(14,removed.size()),sizeof(RepairFeature)+4*sizeof(void*)),
            checkpoint.valid?transfer_memory::Mul(transfer_memory::Mul(4,transfer_memory::Add(removed.size(),added.size())),sizeof(Id)+4*sizeof(void*)):0)))return finish();
        try {
          for(const auto& row:removed) {
            const auto cached=selection.cells.find(row.cell);
            if(cached==selection.cells.end()){++stats.unmeasured_retired;continue;}
            if(checkpoint.valid)checkpoint.changed.insert(cached->second.vertices.begin(),cached->second.vertices.end());
            for(const auto& edge:cached->second.edges)retired_edges.emplace(edge,selection.edges.at(edge).measure);
            selection.Drop(row.cell);
          }
          batch_changed.reserve(added.size());
          for(const auto& row:added) {
            batch_changed.push_back(row.cell.id);
            if(checkpoint.valid)for(const auto& node:row.cell.v)checkpoint.changed.insert(node.id);
          }
          for(const auto& blocked_feature:failures)selection.Block(blocked_feature.edge,blocked_feature.feature,true);
          for(const auto& proposal:repair_proposals)if(proposal.approved) {
            if(standalone_coarsening&&checkpoint.valid)checkpoint.trial=true;
            improvement_changed = true;
            ++stats.accepted;
            wall_counters.Accepted();
            ++stats.quality.commits;
            if (options.timings) {
              const auto& lane_slot = lane_slots[&proposal - repair_proposals.data()];
              lane_counters.Commit(true, lane_slot, SameSkin(proposal.old, proposal.fresh),
                                   lane_slot.no_parameter_edits,
                                   proposal.fresh.coverage.faces.empty() && proposal.fresh.coverage.traces.empty());
            }
            if(!surface_target)AccountQualityChurn(proposal.old,proposal.fresh,proposal.old_flags,proposal.fresh_flags,stats.quality);
            if(proposal.ladder<3) {
              auto& counter=stats.quality.ladder[proposal.ladder];++counter.published;
              counter.debt_removed+=proposal.certified.old_shape_debt-proposal.certified.new_shape_debt;
              counter.q_removed+=int64_t(proposal.certified.old_q_bad_cells)-int64_t(proposal.certified.new_q_bad_cells);
              counter.j_removed+=int64_t(proposal.certified.old_j_bad_cells)-int64_t(proposal.certified.new_j_bad_cells);
            }
            if(proposal.optimization_approved) {
              stats.optimization_moves+=proposal.optimization.moves;stats.optimization_insertions+=proposal.optimization.insertions;
              stats.optimization_collapses+=proposal.optimization.collapses;stats.optimization_swaps+=proposal.optimization.swaps;
            }
            stats.geometry_progress+=proposal.geometric_progress;stats.size_progress+=proposal.certified.size_progress;
            stats.quality_progress+=proposal.certified.quality_progress;
            if(proposal.cavity_inserted)++stats.inserted;
            else if(proposal.repair_approved){if(proposal.moved)++stats.moved;else ++stats.reconnected;}
          }
          stats.maximum_owned=std::max(stats.maximum_owned,working.size());
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure)||!measure(batch_changed,false,&stats.update_seconds))return finish();
        try {
          selection.FinishRepairs();
          for(const auto& support:directory->ChangedRepairSupports())selection.TouchRepairSupport(support);
          for(Id vertex:directory->ChangedVertices())selection.Touch(vertex);
          selection.progress_consistent=true;
        }catch(const std::exception& e){failure.Set(2,0,e.what());}
        if(!context.exchange.Vote(context, failure))return finish();
        batch_changed.clear();retired_edges.clear();
      }
    }
    batch_bytes=0;++round;
  }
  {
    Timer timer(stats.completion_seconds,options.timings, SU2NativeTiming3D::Operation::Certification);
    const int incomplete=world.maximum(selection.cells.size()!=working.size() ? 3 :
        (selection.invalid ? 2 : (coarsening && !selection.queue.empty() ? 1 : 0)));
    result.valid=!metric_cleanup && phase==Phase::Improvement && incomplete==0 && !world.maximum(selection.unmeasured_shape!=0 || selection.quality_invalid!=0 ||
        selection.construction_invalid!=0 || (standalone_coarsening && improvement_changed));
    stats.stop=result.valid ? EngineStop::Complete : EngineStop::RoundBudget;
    if (incomplete==1)
      result.reason="Native 3D coarsening round limit reached with valid cached metric cells and pending collapse candidates.";
    else if (incomplete==2)
      result.reason="Native 3D adaptation round limit reached before cached metric size/shape gates were satisfied.";
    else if (incomplete==3)
      result.reason="Native 3D adaptation round limit reached with incomplete metric-cell measurements.";
    else if(!result.valid)result.reason="Native 3D adaptation round limit reached before strict quality/coarsening completion.";
    else result.reason.clear();
  }
  return finish();
}
}  // namespace
bool CollapseConstraintViolation(const OwnedCell& cell,Id removed,Node retained,const PlanarReference& geometry,
                                double tolerance,const WallHeights& heights) {
  if(heights.empty() && geometry.ExtensionComponents().empty())return false;
  if(std::none_of(cell.physical.begin(),cell.physical.end(),[](FacetBinding f){return f.present;}))return false;
  if(std::any_of(cell.cell.v.begin(),cell.cell.v.end(),[&](Node n){return n.id==retained.id;}))return false;
  auto proposed=cell;bool changes=false;
  for(auto& n:proposed.cell.v)if(n.id==removed){n=retained;changes=true;}
  if(!changes)return false;
  if(!geometry.EntityGeometry()&&geometry.Mapped()&&(geometry.Mobility()||!geometry.Parameters()->Coverage().faces.empty()||!geometry.Parameters()->Coverage().traces.empty())) {
    bool changed_surface=false;
    for(unsigned k=0;k<4;++k)changed_surface=changed_surface||(cell.physical[k].present&&cell.cell.v[k].id!=removed);
    // A single-cell filter cannot remap a complete physical star; the full operator must certify its atlas.
    if(changed_surface||!geometry.AtlasReservation())return false;
  }
  // Entity faces use existing point associations; test them before exporting/reconstructing a complete cavity.
  const auto patch=GeometryPatch(Imported{{proposed},true,{}},geometry.EntityGeometry()?nullptr:&geometry);
  for(const auto& face:patch.surface) {
    std::array<Point,3> points;
    for(unsigned i=0;i<3;++i)for(auto n:proposed.cell.v)if(n.id==face.v[i])points[i]=n.p;
    if(!geometry.ContainsFace(face.facet,points))return true;
    bool direct=true;
    if(geometry.EntityGeometry())for(Id id:face.v) {
      const auto* point=geometry.Parameters()->Find(id);
      direct=direct && point && geometry.Parameters()->Geometry().Supports(face.facet,point->binding);
    }
    // Remapped faces need complete-cavity admission, not a global enclosure inside a selection shortcut.
    if(direct && geometry.Declared(geometry.Canonical(face.facet)) &&
        geometry.SurfaceDeviation(face.facet,points,SU2NativeGeometry::SurfaceQueryNeed::Classify())>tolerance)return true;
  }
  FirstHeightReport report;std::string reason;
  if(heights.empty() || CheckFirstHeight(patch,heights,geometry,report,reason))return false;
  return GetShapeAdmission()!=ShapeAdmission::ValidityOnly || !report.measured || report.missing_cells ||
         report.reference_clearance_failures;
}
EngineResult PrepareSurface(World& world,const Owned& accepted,const std::vector<DonorCell>& original,
                            const PlanarReference& geometry,BoundaryMetric target,EngineOptions options) {
  CLocalFailure local;
  if(!target||options.wall_heights.empty())local.Set(1,0,"Surface preparation needs requested walls and a boundary target.");
  const auto failure=world.elect(local);
  if(failure.any){EngineResult result;result.reason=failure.message;result.stats.stop=EngineStop::Failure;return result;}
  // Planning uses the transported core; full composed edge certification belongs to AdaptMetric after construction.
  options.edge_breakpoints={};
  return Adapt(world,accepted,original,geometry,{},options,MetricChange::Refine,true,std::move(target));
}
EngineResult AdaptMetric(World& world, const Owned& accepted, const std::vector<DonorCell>& original,
                    const PlanarReference& geometry, MetricComposition composition, EngineOptions options) {
  return Adapt(world,accepted,original,geometry,std::move(composition),options,MetricChange::Refine,true);
}
EngineResult Refine(World& world, const Owned& accepted, const std::vector<DonorCell>& original,
                    const PlanarReference& geometry, MetricComposition composition, EngineOptions options) {
  return Adapt(world,accepted,original,geometry,std::move(composition),options,MetricChange::Refine);
}
EngineResult Coarsen(World& world, const Owned& accepted, const std::vector<DonorCell>& original,
                    const PlanarReference& geometry, MetricComposition composition, EngineOptions options) {
  return Adapt(world,accepted,original,geometry,std::move(composition),options,MetricChange::Coarsen);
}
EngineResult Repair(World& world, const Owned& accepted, const std::vector<DonorCell>& original,
                    const PlanarReference& geometry, MetricComposition composition, EngineOptions options) {
  return Adapt(world,accepted,original,geometry,std::move(composition),options,MetricChange::Repair);
}
// ---- DC-12 (OPTIMIZE_PLAN sect. 4/6): mesh-wide metric optimization and the serial build-then-optimize driver ----------
namespace {
struct CoordinateHash {
  size_t operator()(const std::array<double,3>& k) const {
    uint64_t h=1469598103934665603ULL;
    for(const double v:k){uint64_t b=0;std::memcpy(&b,&v,sizeof b);h=(h^b)*1099511628211ULL;}
    return size_t(h);
  }
};
std::array<Face,4> OppositeFaces(const Cell& c) {
  const auto& v=c.v;return {{{v[1].id,v[2].id,v[3].id},{v[0].id,v[3].id,v[2].id},{v[0].id,v[1].id,v[3].id},{v[0].id,v[2].id,v[1].id}}};
}
bool CellHas(const Cell& c,Id v){for(const auto& n:c.v)if(n.id==v)return true;return false;}
struct CellQuality { double q=-1,J=-1;double Score()const{return std::min(q/MinimumMeanRatio,J/MinimumScaledJacobian);}
  bool Valid()const{return std::isfinite(q)&&std::isfinite(J)&&q>=0&&J>=0;} };
// ---- DC-13 placement engine (DC13_PLAN sect. 1.1): proposals only, every acceptance re-measures exactly ----------
// Upper Cholesky factor R of an SPD tensor (M = R^T R); ok=false if not SPD in double.
struct Factor3 { double r00=0,r01=0,r02=0,r11=0,r12=0,r22=0;bool ok=false; };
Factor3 FactorOf(const Tensor& m) {
  Factor3 c;if(!(m.xx>0))return c;c.r00=std::sqrt(m.xx);c.r01=m.xy/c.r00;c.r02=m.xz/c.r00;
  const double p11=m.yy-c.r01*c.r01;if(!(p11>0))return c;c.r11=std::sqrt(p11);c.r12=(m.yz-c.r01*c.r02)/c.r11;
  const double p22=m.zz-c.r02*c.r02-c.r12*c.r12;if(!(p22>0))return c;c.r22=std::sqrt(p22);c.ok=true;return c;
}
// Approximate minimum score or negative summed hinge debt in a constant tensor (same q/J as Measure);
// -INFINITY for a non-positive (determinant <= 0) or degenerate cell.
double FastScore(const std::array<Point,4>& p,const Factor3& f,bool debt=false) {
  double y[4][3];
  for(unsigned k=0;k<4;++k){const double d0=p[k].x-p[0].x,d1=p[k].y-p[0].y,d2=p[k].z-p[0].z;
    y[k][0]=f.r00*d0+f.r01*d1+f.r02*d2;y[k][1]=f.r11*d1+f.r12*d2;y[k][2]=f.r22*d2;}
  auto e=[&](unsigned i,unsigned j,unsigned c){return y[j][c]-y[i][c];};
  const double u[3]={e(0,1,0),e(0,1,1),e(0,1,2)},v[3]={e(0,2,0),e(0,2,1),e(0,2,2)},w[3]={e(0,3,0),e(0,3,1),e(0,3,2)};
  const double det=u[0]*(v[1]*w[2]-v[2]*w[1])-u[1]*(v[0]*w[2]-v[2]*w[0])+u[2]*(v[0]*w[1]-v[1]*w[0]);
  if(!(det>0)||!std::isfinite(det))return -INFINITY;
  double l2[4][4]={{0}},sum=0;
  for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j){double s=0;for(unsigned c=0;c<3;++c){const double d=e(i,j,c);s+=d*d;}l2[i][j]=l2[j][i]=s;sum+=s;}
  const double root=std::cbrt(det/2),q=12*root*root/sum;double J=1;
  for(unsigned k=0;k<4;++k){double den=1;for(unsigned j=0;j<4;++j)if(j!=k)den*=std::sqrt(l2[k][j]);J=std::min(J,den>0?std::sqrt(2.)*det/den:0.);}
  return debt ? -double(NormalizedShapeHingeDebt(q,J)) : std::min(q/MinimumMeanRatio,J/MinimumScaledJacobian);
}
// Boundary faces of a cell set (faces used once inside the set), oriented as in their cell (opposite vertex inside).
std::vector<Face> CavityBoundary(const std::vector<Cell>& cells) {
  std::map<Face,std::pair<int,Face>> uses;
  for(const auto& c:cells)for(auto f:OppositeFaces(c)){auto k=f;std::sort(k.begin(),k.end());auto& u=uses[k];++u.first;u.second=f;}
  std::vector<Face> out;for(const auto& u:uses)if(u.second.first==1)out.push_back(u.second.second);
  return out;
}
// Placement of one new point in a star-shaped cavity, using minimum score or summed deficit. The tensor of a
// cone cell is the arithmetic mean of the point tensors at its three face vertices and at the start point (an SPD
// proposal metric); deterministic best-improvement compass search in the metric frame of the start point (6 axes and
// 8 diagonals, step .25 halving to 1e-3). `admissible` restricts the search region (e.g. the size-split region).
struct Placement { bool ok=false;Point x;double score=-INFINITY;size_t evaluations=0; };
Placement PlaceCone(const std::vector<Face>& faces,const std::function<Point(Id)>& point,const std::function<Tensor(Point)>& at,
                    Point start,const std::function<bool(Point)>& admissible,size_t budget=160,bool debt=false) {
  Placement out;if(faces.empty())return out;
  // a start outside the target's coverage (e.g. a smoothing proposal beyond the domain) is no proposal, not an error
  Tensor t0;std::map<Id,Tensor> vt;
  try{t0=at(start);for(const auto& f:faces)for(Id v:f)if(!vt.count(v))vt.emplace(v,at(point(v)));}catch(const std::exception&){return out;}
  std::vector<std::array<Point,3>> base;std::vector<Factor3> factor;
  for(const auto& f:faces){Tensor m=t0;for(Id v:f){const auto& t=vt.at(v);m.xx+=t.xx;m.xy+=t.xy;m.xz+=t.xz;m.yy+=t.yy;m.yz+=t.yz;m.zz+=t.zz;}
    m.xx/=4;m.xy/=4;m.xz/=4;m.yy/=4;m.yz/=4;m.zz/=4;const auto c=FactorOf(m);if(!c.ok)return out;factor.push_back(c);
    base.push_back({point(f[0]),point(f[1]),point(f[2])});}
  auto F=[&](Point x)->double{++out.evaluations;if(admissible&&!admissible(x))return -INFINITY;double s=debt?0:INFINITY;
    for(size_t k=0;k<base.size()&&s>-INFINITY;++k) {
      const auto part=FastScore({x,base[k][0],base[k][1],base[k][2]},factor[k],debt);
      s=debt?s+part:std::min(s,part);
    }
    return s;};
  // metric frame of the start: d = R0^{-1} e (unit metric length)
  const auto R=FactorOf(t0);if(!R.ok)return out;
  auto frame=[&](double e0,double e1,double e2)->Point{const double z=e2/R.r22,y=(e1-R.r12*z)/R.r11,x=(e0-R.r01*y-R.r02*z)/R.r00;return {x,y,z};};
  std::vector<Point> dirs;const double r3=1/std::sqrt(3.);
  for(int a=0;a<3;++a)for(int s:{-1,1}){double e[3]={0,0,0};e[a]=s;dirs.push_back(frame(e[0],e[1],e[2]));}
  for(int sx:{-1,1})for(int sy:{-1,1})for(int sz:{-1,1})dirs.push_back(frame(sx*r3,sy*r3,sz*r3));
  Point x=start;double best=F(x),h=.25;
  while(h>=1e-3&&out.evaluations<budget){Point bx=x;double bs=best;
    for(const auto& d:dirs){const Point y{x.x+h*d.x,x.y+h*d.y,x.z+h*d.z};const double s=F(y);if(s>bs){bs=s;bx=y;}if(out.evaluations>=budget)break;}
    if(bs>best){best=bs;x=bx;}else h/=2;}
  out.ok=std::isfinite(best);out.x=x;out.score=best;return out;
}
class MeshOptimizer {
 public:
  MeshOptimizer(Owned& mesh,const RegionMetric& target,Id& next_node,Id& next_cell,const OptimizeOptions& options,OptimizeReport& report)
      : mesh(mesh),target(target),next_node(next_node),next_cell(next_cell),options(options),report(report),started(Clock::now()) {}
  bool Run();

 private:
  static constexpr double Gain=1e-6;
  static constexpr long double EstimatePass=1.4L;  // new edges estimated at most this long are not integrated
  Owned& mesh;
  const RegionMetric& target;
  Id& next_node;
  Id& next_cell;
  const OptimizeOptions& options;
  OptimizeReport& report;
  Clock::time_point started;
  std::unique_ptr<PlanarReference> moved_geometry;
  bool changed=false,limited=false,coupled=true;
  size_t stage_work_end=SIZE_MAX;
  std::unordered_map<Id,std::vector<Id>> star;   // vertex -> incident cells
  std::unordered_map<Id,Point> points;
  std::map<Face,Id> physical;                    // Current physical faces for first-height deficits.
  std::set<Id> fixed;                            // skin vertices: only geometry-certified movement may change them
  std::map<Id,std::array<double,3>> sliding;     // TEST-ONLY diagnostic sliding planes (options.diagnostic_sliding, follows moves)
  std::set<Id> keep;                             // options.keep_vertices, following moves (never collapsed)
  std::unordered_map<Id,double> height_scores;  // Current cells are immutable by identity.
  std::unordered_map<std::array<double,3>,Tensor,CoordinateHash> tensors;
  std::map<std::array<Id,4>,CellQuality> qualities;  // ordered cell vertex ids (an identity keeps its coordinates)
  std::map<std::array<double,6>,long double> exact;
  // Target/options are fixed; pure-shape rejections depend on the complete vertex star.
  std::set<Id> rejected_smoothing;
  bool Limited() {
    if(limited)return true;
    if(report.trials>=options.maximum_work)limited=true;
    if(options.maximum_seconds>0 && std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds)limited=true;
    return limited || report.trials>=stage_work_end;
  }
  void Bound() {
    if(height_scores.size()>=options.cache_entries)height_scores.clear();
    if(tensors.size()>=options.cache_entries)tensors.clear();
    if(qualities.size()>=options.cache_entries)qualities.clear();
    if(exact.size()>=options.cache_entries)exact.clear();
  }
  void Index() {
    star.clear();points.clear();fixed.clear();physical.clear();std::map<Face,int> uses;
    for(const auto& row:mesh) {
      for(const auto& n:row.second.cell.v){star[n.id].push_back(row.first);points[n.id]=n.p;}
      const auto faces=OppositeFaces(row.second.cell);
      for(unsigned k=0;k<4;++k){const auto f=Key(faces[k]);++uses[f];if(row.second.physical[k].present)physical.emplace(f,row.second.physical[k].facet);}
    }
    for(const auto& u:uses)if(u.second==1)fixed.insert(u.first.begin(),u.first.end());
    sliding=options.diagnostic_sliding;keep=options.keep_vertices;
  }
  Tensor At(Point p) {
    const std::array<double,3> key{p.x,p.y,p.z};const auto found=tensors.find(key);
    if(found!=tensors.end())return found->second;
    ++report.point_queries;const auto m=target.point(p);if(tensors.size()>=options.cache_entries)tensors.clear();tensors.emplace(key,m);return m;
  }
  // q, J in the metric at the actual centroid; q = J = -1 for a non-positive or unmeasurable cell
  CellQuality Quality(const Cell& c,bool memo=true) {
    if(!(Orientation(c.v[0].p,c.v[1].p,c.v[2].p,c.v[3].p)>0))return {};
    const std::array<Id,4> key{c.v[0].id,c.v[1].id,c.v[2].id,c.v[3].id};
    if(memo){const auto found=qualities.find(key);if(found!=qualities.end())return found->second;}
    CellQuality r;
    try{const auto m=Measure({c.v[0].p,c.v[1].p,c.v[2].p,c.v[3].p},At(Centroid(c)));r.q=m.mean_ratio;r.J=m.minimum_scaled_jacobian;}catch(const std::exception&){r=CellQuality{};}
    if(memo){if(qualities.size()>=options.cache_entries)qualities.clear();qualities.emplace(key,r);}
    return r;
  }
  double Score(const Cell& c){return Quality(c).Score();}
  // DC-17: score of a current mesh cell, from the caller's identity memo when given (same exact measure)
  Patch GeometryPatch(const std::vector<Cell>& cells) const {
    Patch patch;patch.cells=cells;
    for(const auto& c:cells)for(auto f:OppositeFaces(c)){const auto b=physical.find(Key(f));if(b!=physical.end())patch.surface.push_back({f,b->second});}
    if(options.geometry){patch.parameters=report.parameters;patch.coverage=report.coverage;RetainPhysicalCoverage(patch);
      const auto& geometry=moved_geometry?*moved_geometry:*options.geometry;geometry.ExportParameters(patch);}
    return patch;
  }
  double Height(const Patch& patch) const {
    if(!options.geometry || options.wall_heights.empty())return INFINITY;
    const auto& base=moved_geometry?*moved_geometry:*options.geometry;auto parameters=base.PrivateParameters(patch);
    return HeightScore(patch,options.wall_heights,parameters?*parameters:base);
  }
  CellQuality RowQuality(Id id,const Cell& c) {
    CellQuality q;
    if(!options.mesh_quality || !options.mesh_quality(id,q.q,q.J))q=Quality(c);
    return q;
  }
  double RowHeight(Id id,const Cell& c) {
    if(options.wall_heights.empty())return INFINITY;
    auto found=height_scores.find(id);
    if(found==height_scores.end()) {
      if(height_scores.size()>=options.cache_entries)height_scores.clear();
      found=height_scores.emplace(id,Height(GeometryPatch({c}))).first;
    }
    return found->second;
  }
  double RowScore(Id id,const Cell& c){return std::min(RowQuality(id,c).Score(),RowHeight(id,c));}
  long double RowPriority(Id id,const Cell& c) {
    if(GetShapeAdmission()!=ShapeAdmission::ValidityOnly)return RowScore(id,c);
    const auto q=RowQuality(id,c);long double debt=NormalizedShapeHingeDebt(q.q,q.J);
    const auto h=RowHeight(id,c);
    if(h<1){const auto deficit=1-static_cast<long double>(h);debt+=deficit*deficit;}
    return -debt;
  }
  double MinScore(const std::vector<Id>& ids){double m=INFINITY;for(Id id:ids)m=std::min(m,RowScore(id,mesh.at(id).cell));return m;}
  // Minimum score of finite, exact-positive fresh cells.
  double FreshScore(const std::vector<Cell>& cells,bool memo=true,const Patch* patch=nullptr) {
    double m=INFINITY;for(const auto& c:cells){const auto r=Quality(c,memo);if(!r.Valid())return -INFINITY;m=std::min(m,r.Score());}
    return options.wall_heights.empty()?m:std::min(m,Height(patch?*patch:GeometryPatch(cells)));}
  // Height repair retains its existing merit until the actual requested constraints close.
  bool DebtMode(const std::vector<Id>& ids,const Patch* patch=nullptr) const {
    if(GetShapeAdmission()!=ShapeAdmission::ValidityOnly)return false;
    if(options.wall_heights.empty())return true;
    if(patch)return Height(*patch)>=1;
    std::vector<Cell> cells;for(Id id:ids)cells.push_back(mesh.at(id).cell);
    return Height(GeometryPatch(cells))>=1;
  }
  long double OldMerit(const std::vector<Id>& ids,bool debt) {
    SU2NativeTiming3D::Scope old_cavity_scope(SU2NativeTiming3D::Operation::OldCavityMeasurement);
    if(!debt)return MinScore(ids);
    long double sum=0;
    for(Id id:ids){const auto q=RowQuality(id,mesh.at(id).cell);if(!q.Valid())return -INFINITY;sum+=NormalizedShapeHingeDebt(q.q,q.J);}
    return -sum;
  }
  long double FreshMerit(const std::vector<Cell>& cells,bool debt,bool memo=true,const Patch* patch=nullptr) {
    if(!debt)return FreshScore(cells,memo,patch);
    if(cells.empty())return -INFINITY;
    long double sum=0;
    for(const auto& c:cells){const auto q=Quality(c,memo);if(!q.Valid())return -INFINITY;sum+=NormalizedShapeHingeDebt(q.q,q.J);}
    if(!options.wall_heights.empty() && !(Height(patch?*patch:GeometryPatch(cells))>=1))return -INFINITY;
    return -sum;
  }
  bool Progress(long double after,long double before,bool debt,bool length=false) const {
    if(!std::isfinite(after))return false;
    if(debt)return std::isfinite(before)&&(length?after>=before:ShapeDebtDecreases(-before,-after));
    const double floor=length?std::min(double(before),1.)-1e-12:double(before)+Gain;
    return double(after)>floor;
  }
  long double Estimate(Point a,Point b) {
    const Point mid{double(((long double)a.x+b.x)/2),double(((long double)a.y+b.y)/2),double(((long double)a.z+b.z)/2)};
    ++report.edge_surrogates;
    return (MetricNorm(a,b,At(a))+4*MetricNorm(a,b,At(mid))+MetricNorm(a,b,At(b)))/6;
  }
  long double Exact(Point a,Point b) {
    std::array<double,6> key{a.x,a.y,a.z,b.x,b.y,b.z};
    if(std::make_tuple(b.x,b.y,b.z)<std::make_tuple(a.x,a.y,a.z))key={b.x,b.y,b.z,a.x,a.y,a.z};
    const auto found=exact.find(key);if(found!=exact.end())return found->second;
    ++report.edge_integrations;const auto l=target.edge(a,b);if(exact.size()>=options.cache_entries)exact.clear();exact.emplace(key,l);return l;
  }
  // Edge guard of an accepted candidate: the exact composed length when the estimate exceeds EstimatePass.
  bool Certified(Point a,Point b,long double limit) {
    try{const auto e=Estimate(a,b);if(e<=EstimatePass)return true;if(e>1.45L*limit)return false;return Exact(a,b)<=limit;}
    catch(const std::exception&){return false;}
  }
  bool Frozen(Id cell) const {  // no topology change (DC-17: also cells holding a structure vertex)
    if(options.frozen_cells.count(cell))return true;
    if(options.structure_vertices.empty())return false;
    const auto f=mesh.find(cell);if(f==mesh.end())return false;
    for(const auto& n:f->second.cell.v)if(options.structure_vertices.count(n.id))return true;
    return false;}
  bool Movable(Id v) const {
    if((fixed.count(v)&&!sliding.count(v)) || options.frozen_vertices.count(v))return false;
    const auto s=star.find(v);if(s==star.end() || s->second.empty() || s->second.size()>MaximumCavityCells)return false;
    for(Id id:s->second)if(options.frozen_cells.count(id))return false;  // moves keep the topology of structure cells
    return true;
  }
  static std::vector<Id> Common(std::vector<Id> x,std::vector<Id> y) {
    std::vector<Id> out;std::sort(x.begin(),x.end());std::sort(y.begin(),y.end());
    std::set_intersection(x.begin(),x.end(),y.begin(),y.end(),std::back_inserter(out));return out;
  }
  bool Adjacent(Id a,Id b) const {const auto s=star.find(a);if(s==star.end())return false;for(Id id:s->second)if(CellHas(mesh.at(id).cell,b))return true;return false;}
  // Exact interface/ball-topology certificate of a replacement (temporary identities from next_cell).
  bool Interface(const std::vector<Id>& old,std::vector<Cell>& fresh) {
    std::vector<Cell> before;before.reserve(old.size());for(Id id:old)before.push_back(mesh.at(id).cell);
    for(size_t i=0;i<fresh.size();++i)fresh[i].id=next_cell+i;
    std::string reason;bool ok=false;
    try{ok=ValidateFixedInterface(before,fresh,reason,nullptr,std::max<size_t>(MaximumCavityCells,before.size()));}catch(const std::exception&){ok=false;}
    if(!ok)++report.rejected_interface;
    return ok;
  }
  // Replace old cells by fresh ones: every physical binding of an old face that survives is carried by its face key;
  // `added` binds the boundary faces a boundary operation creates (the faces it retires disappear with their cells).
  void Commit(const std::vector<Id>& old,std::vector<Cell> fresh,Id removed=UINT64_MAX,const std::map<Face,FacetBinding>& added={}) {
    std::map<Face,FacetBinding> bindings=added;std::set<Face> oldPhysical;
    for(Id id:old) {
      const auto& row=mesh.at(id);const auto faces=OppositeFaces(row.cell);
      for(unsigned k=0;k<4;++k)if(row.physical[k].present){auto f=faces[k];std::sort(f.begin(),f.end());bindings.emplace(f,row.physical[k]);oldPhysical.insert(f);physical.erase(f);}
      for(const auto& n:row.cell.v){rejected_smoothing.erase(n.id);auto& s=star[n.id];s.erase(std::remove(s.begin(),s.end(),id),s.end());}
      mesh.erase(id);
    }
    std::set<Face> used;
    for(auto& c:fresh) {
      c.id=next_cell++;OwnedCell row;row.cell=c;row.version=1;const auto faces=OppositeFaces(c);
      for(unsigned k=0;k<4;++k){auto f=faces[k];std::sort(f.begin(),f.end());const auto b=bindings.find(f);if(b!=bindings.end()){row.physical[k]=b->second;used.insert(f);physical.insert_or_assign(f,b->second.facet);}}
      if(!mesh.emplace(c.id,row).second)throw std::logic_error("Native3D optimizer repeated a cell identity.");
      for(const auto& n:c.v){rejected_smoothing.erase(n.id);star[n.id].push_back(c.id);points[n.id]=n.p;}
    }
    for(const auto& a:added)if(!used.count(a.first))throw std::logic_error("Native3D optimizer lost a created boundary face.");
    if(added.empty())for(const auto& f:oldPhysical)if(!used.count(f))throw std::logic_error("Native3D optimizer lost a physical face binding.");
    if(removed!=UINT64_MAX){const auto s=star.find(removed);if(s!=star.end()&&!s->second.empty())throw std::logic_error("Native3D optimizer removed a used vertex.");star.erase(removed);points.erase(removed);}
    changed=true;Bound();
  }
  void RememberRejectedSmooth(Id p) {
    if(!options.cache_entries)return;
    if(rejected_smoothing.size()>=options.cache_entries)rejected_smoothing.clear();
    rejected_smoothing.insert(p);
  }
  bool EdgeRemoval(Id a,Id b,bool lengthDriven=false);
  bool FaceSwap(const Face& f);
  bool Collapse(Id p,Id q);
  bool Smooth(Id p);
  bool SmoothBoundary(Id p);
  bool CoupledBoundary();
  void AccountNested(const OptimizeReport& nested,bool selected);
  bool ShellBoundary(Id cell);
  bool TryCell(Id id,bool enrichment);
  // DC-13 (DC13_PLAN sect. 1): cone re-meshing of a star-shaped cavity from one new placed vertex
  enum class Insert { Shell, Neighbourhood, Length };
  bool ConeReplace(const std::vector<Id>& old,Point start,Insert kind,const std::pair<Id,Id>* split=nullptr,long double removed=0);
  bool ShellInsert(Id a,Id b,bool lengthDriven=false);
  bool NeighbourhoodInsert(Id cell);
  // boundary operations (no new point; every face stays inside its facet): O5 flip of a boundary edge between two faces
  // bound to the same facet, O6 contraction of a boundary vertex interior to one facet along a boundary edge
  struct BoundaryFace { Face oriented{};Id cell=0;FacetBinding binding; };
  std::vector<BoundaryFace> BoundaryFacesOf(const std::vector<Id>& cells,Id v) const {
    std::vector<BoundaryFace> out;for(Id id:cells){const auto& row=mesh.at(id);const auto faces=OppositeFaces(row.cell);
      for(unsigned k=0;k<4;++k)if(row.physical[k].present&&(v==UINT64_MAX||faces[k][0]==v||faces[k][1]==v||faces[k][2]==v))out.push_back({faces[k],id,row.physical[k]});}
    return out;
  }
  static long double Norm3(Point a,Point b){const long double x=(long double)a.x-b.x,y=(long double)a.y-b.y,z=(long double)a.z-b.z;return std::sqrt(x*x+y*y+z*z);}
  static long double Area2(Point a,Point b,Point c,long double n[3]) {
    const long double u[3]={(long double)b.x-a.x,(long double)b.y-a.y,(long double)b.z-a.z},w[3]={(long double)c.x-a.x,(long double)c.y-a.y,(long double)c.z-a.z};
    n[0]=u[1]*w[2]-u[2]*w[1];n[1]=u[2]*w[0]-u[0]*w[2];n[2]=u[0]*w[1]-u[1]*w[0];return std::sqrt(n[0]*n[0]+n[1]*n[1]+n[2]*n[2]);
  }
  // fresh boundary = old boundary - retired + created, with the created faces inside the retired faces' plane: same
  // facet, unfolded (normals along the retired ones) and the same total area (no gap or overlap)
  bool BoundaryReplacement(const std::vector<Id>& old,std::vector<Cell>& fresh,const std::vector<BoundaryFace>& retired,FacetBinding binding,std::map<Face,FacetBinding>& added) {
    std::vector<Cell> before;for(Id id:old)before.push_back(mesh.at(id).cell);
    for(size_t i=0;i<fresh.size();++i)fresh[i].id=next_cell+i;
    std::vector<Face> oldSkin,newSkin;
    try{oldSkin=Incidence(before).Boundary();newSkin=Incidence(fresh).Boundary();}catch(const std::exception&){++report.rejected_interface;return false;}
    auto canon=[](Face f){std::rotate(f.begin(),std::min_element(f.begin(),f.end()),f.end());return f;};
    std::set<Face> retiredSet,oldSet,newSet;for(const auto& r:retired)retiredSet.insert(canon(r.oriented));
    for(const auto& f:oldSkin)oldSet.insert(canon(f));for(const auto& f:newSkin)newSet.insert(canon(f));
    for(const auto& f:oldSet)if(!retiredSet.count(f)&&!newSet.count(f)){++report.rejected_interface;return false;}
    long double n0[3]={0,0,0},area0=0,area1=0;
    for(const auto& r:retired){long double n[3];area0+=Area2(points.at(r.oriented[0]),points.at(r.oriented[1]),points.at(r.oriented[2]),n);for(int i=0;i<3;++i)n0[i]+=n[i];}
    added.clear();
    for(const auto& f:newSet){if(oldSet.count(f))continue;
      Point q[3];for(int i=0;i<3;++i){bool found=false;for(const auto& c:fresh)for(const auto& v:c.v)if(v.id==f[i]){q[i]=v.p;found=true;}if(!found)return false;}
      long double n[3];const auto a=Area2(q[0],q[1],q[2],n);area1+=a;if(!(n[0]*n0[0]+n[1]*n0[1]+n[2]*n0[2]>0)){++report.rejected_interface;return false;}
      auto key=f;std::sort(key.begin(),key.end());added.emplace(key,binding);}
    if(!(std::abs(area1-area0)<=1e-10L*area0)){++report.rejected_interface;return false;}
    std::string reason;bool ok=false;
    try{ok=ValidatePrescribedInterface(before,fresh,newSkin,reason,nullptr,std::max<size_t>(MaximumCavityCells,before.size()));}catch(const std::exception&){ok=false;}
    if(!ok)++report.rejected_interface;
    return ok;
  }
  bool BoundaryFlip(Id a,Id b);
  bool BoundaryCollapse(Id p,Id q);
};
// O1: interior edge with a closed shell of n cells (3 <= n <= maximum_shell) replaced by the 2(n-2) cells of the best
// triangulation of its ring polygon (additive debt or legacy max-min dynamic programming; ring order with (a,b,r_i,r_i+1)
// positive, so (a,r_i,r_k,r_j) and (b,r_i,r_j,r_k) for i < k < j are the positive orientations).
// lengthDriven (O1L): the edge is longer than 1.8; accepted when no new edge exceeds 1.8 and the replaced cells' minimum
// score does not fall below min(old minimum, 1) (the long edge leaves the mesh without creating a final-gate failure).
bool MeshOptimizer::EdgeRemoval(Id a,Id b,bool lengthDriven) {
  if(Limited())return false;
  const auto sa=star.find(a),sb=star.find(b);if(sa==star.end()||sb==star.end())return false;
  const auto shell=Common(sa->second,sb->second);const size_t n=shell.size();
  if(n<3 || n>options.maximum_shell)return false;
  for(Id id:shell)if(Frozen(id)){++report.rejected_frozen;return false;}
  std::map<Id,std::vector<Id>> ring;
  for(Id id:shell){std::vector<Id> o;for(const auto& v:mesh.at(id).cell.v)if(v.id!=a&&v.id!=b)o.push_back(v.id);if(o.size()!=2)return false;ring[o[0]].push_back(o[1]);ring[o[1]].push_back(o[0]);}
  if(ring.size()!=n)return false;
  for(const auto& r:ring)if(r.second.size()!=2)return false;  // open (boundary) shell
  ++report.trials;
  const Point pa=points.at(a),pb=points.at(b);
  std::vector<Id> order{ring.begin()->first};
  {const Id r0=order[0];Id next=UINT64_MAX;for(Id y:ring.at(r0))if(Orientation(pa,pb,points.at(r0),points.at(y))>0)next=y;if(next==UINT64_MAX)return false;
   Id prev=r0;Id cur=next;while(cur!=r0){if(order.size()>n)return false;order.push_back(cur);const auto& nb=ring.at(cur);const Id nx=nb[0]==prev?nb[1]:nb[0];prev=cur;cur=nx;}}
  if(order.size()!=n)return false;
  for(size_t i=0;i<n;++i)if(!(Orientation(pa,pb,points.at(order[i]),points.at(order[(i+1)%n]))>0))return false;
  const bool debt=DebtMode(shell);const auto oldMin=OldMerit(shell,debt);
  long double limit=MaximumMetricEdge;
  if(!lengthDriven){try{const auto e=Estimate(pa,pb);limit=std::max<long double>(limit,e>EstimatePass?Exact(pa,pb):e);}catch(const std::exception&){}}
  const Node A{a,pa},B{b,pb};std::vector<Node> r(n);for(size_t i=0;i<n;++i)r[i]={order[i],points.at(order[i])};
  std::map<std::array<size_t,3>,long double> tri;
  auto triangle=[&](size_t i,size_t k,size_t j){const std::array<size_t,3> key{i,k,j};const auto f=tri.find(key);if(f!=tri.end())return f->second;
    const auto s=FreshMerit({Cell{0,{A,r[i],r[k],r[j]}},Cell{0,{B,r[i],r[j],r[k]}}},debt);tri.emplace(key,s);return s;};
  std::set<std::pair<size_t,size_t>> forbidden;
  auto ringEdge=[&](size_t i,size_t j){return j==i+1 || (i==0&&j==n-1);};
  for(unsigned attempt=0;attempt<4;++attempt) {
    std::vector<std::vector<long double>> best(n,std::vector<long double>(n,-INFINITY));std::vector<std::vector<size_t>> arg(n,std::vector<size_t>(n,SIZE_MAX));
    for(size_t i=0;i+1<n;++i)best[i][i+1]=debt?0:INFINITY;
    for(size_t len=2;len<n;++len)for(size_t i=0;i+len<n;++i) {
      const size_t j=i+len;
      for(size_t k=i+1;k<j;++k) {
        if((!ringEdge(i,k)&&forbidden.count({i,k})) || (!ringEdge(k,j)&&forbidden.count({k,j})))continue;
        const auto v=debt?best[i][k]+best[k][j]+triangle(i,k,j):std::min({best[i][k],best[k][j],triangle(i,k,j)});
        if(v>best[i][j]){best[i][j]=v;arg[i][j]=k;}
      }
    }
    if(!(Progress(best[0][n-1],oldMin,debt,lengthDriven))){if(best[0][n-1]==-INFINITY)++report.rejected_validity;else ++report.rejected_quality;return false;}
    std::vector<std::array<size_t,3>> used;std::vector<std::pair<size_t,size_t>> stack{{0,n-1}};
    while(!stack.empty()){const auto e=stack.back();stack.pop_back();if(e.second<=e.first+1)continue;const size_t k=arg[e.first][e.second];
      used.push_back({e.first,k,e.second});stack.push_back({e.first,k});stack.push_back({k,e.second});}
    bool ok=true;
    for(const auto& t:used)for(const auto& d:{std::make_pair(t[0],t[1]),std::make_pair(t[1],t[2]),std::make_pair(t[0],t[2])}) {
      if(ringEdge(d.first,d.second)||forbidden.count(d))continue;
      if(!Certified(r[d.first].p,r[d.second].p,limit)){forbidden.insert(d);ok=false;break;}
    }
    if(!ok){++report.rejected_edge;if(Limited())return false;continue;}
    std::vector<Cell> fresh;for(const auto& t:used){fresh.push_back(Cell{0,{A,r[t[0]],r[t[1]],r[t[2]]}});fresh.push_back(Cell{0,{B,r[t[0]],r[t[2]],r[t[1]]}});}
    if(!Progress(FreshMerit(fresh,debt),oldMin,debt,lengthDriven)){++report.rejected_quality;return false;}
    if(!Interface(shell,fresh))return false;
    Commit(shell,fresh);++(lengthDriven?report.length_removals:report.edge_removals);return true;
  }
  return false;
}
// O2: interior face (x,y,z) of two unfrozen cells with apices d, e (not yet connected) -> three cells around (d,e).
bool MeshOptimizer::FaceSwap(const Face& f) {
  if(Limited())return false;
  const auto both=Common(Common(star.at(f[0]),star.at(f[1])),star.at(f[2]));
  if(both.size()!=2)return false;
  for(Id id:both)if(Frozen(id)){++report.rejected_frozen;return false;}
  Id d=UINT64_MAX,e=UINT64_MAX;for(const auto& v:mesh.at(both[0]).cell.v)if(v.id!=f[0]&&v.id!=f[1]&&v.id!=f[2])d=v.id;
  for(const auto& v:mesh.at(both[1]).cell.v)if(v.id!=f[0]&&v.id!=f[1]&&v.id!=f[2])e=v.id;
  if(d==UINT64_MAX||e==UINT64_MAX||d==e||Adjacent(d,e))return false;
  ++report.trials;
  const Node D{d,points.at(d)},E{e,points.at(e)};std::array<Node,3> r{Node{f[0],points.at(f[0])},Node{f[1],points.at(f[1])},Node{f[2],points.at(f[2])}};
  if(!(Orientation(D.p,E.p,r[0].p,r[1].p)>0))std::swap(r[1],r[2]);
  std::vector<Cell> fresh{Cell{0,{D,E,r[0],r[1]}},Cell{0,{D,E,r[1],r[2]}},Cell{0,{D,E,r[2],r[0]}}};
  const bool debt=DebtMode(both);const auto oldMin=OldMerit(both,debt),newMin=FreshMerit(fresh,debt);
  if(newMin==-INFINITY){++report.rejected_validity;return false;}
  if(!(Progress(newMin,oldMin,debt))){++report.rejected_quality;return false;}
  if(!Certified(D.p,E.p,MaximumMetricEdge)){++report.rejected_edge;return false;}
  if(!Interface(both,fresh))return false;
  Commit(both,fresh);++report.face_swaps;return true;
}
// O3: interior vertex p contracted to its neighbour q (cells of the edge disappear, the rest take q).
bool MeshOptimizer::Collapse(Id p,Id q) {
  if(Limited()||keep.count(p)||!Movable(p)||!Adjacent(p,q))return false;
  const auto old=star.at(p);
  ++report.trials;
  const Node Q{q,points.at(q)};std::vector<Cell> fresh;std::set<Id> link;
  for(Id id:old){const auto& c=mesh.at(id).cell;for(const auto& v:c.v)if(v.id!=p)link.insert(v.id);if(CellHas(c,q))continue;Cell x=c;for(auto& v:x.v)if(v.id==p)v=Q;fresh.push_back(x);}
  if(fresh.empty())return false;
  const bool debt=DebtMode(old);const auto oldMin=OldMerit(old,debt),newMin=FreshMerit(fresh,debt);
  if(newMin==-INFINITY){++report.rejected_validity;return false;}
  if(!(Progress(newMin,oldMin,debt))){++report.rejected_quality;return false;}
  for(Id x:link){if(x==q||Adjacent(q,x))continue;if(!Certified(Q.p,points.at(x),MaximumMetricEdge)){++report.rejected_edge;return false;}}
  if(!Interface(old,fresh))return false;
  Commit(old,fresh,p);++report.collapses;return true;
}
// Physical stars move through their forward geometry bindings; artificial interfaces remain fixed.
bool MeshOptimizer::SmoothBoundary(Id p) {
  SU2NativeD9::Star d9_star;
  D9QueryScope d9_query(SU2NativeD9::Site::SmoothBoundary, options.geometry);
  ++report.boundary_stars_searched;
  const auto* state=options.geometry?options.geometry->Parameters():nullptr;
  const auto* query_geometry=state?&state->Geometry():nullptr;
  const auto query_before=query_geometry?query_geometry->GeometryStatsSnapshot():SU2NativeGeometry::MappedFacetReference::GeometryStats{};
  struct MeasureScope {
    OptimizeReport& report;const SU2NativeGeometry::MappedFacetReference* geometry;
    SU2NativeGeometry::MappedFacetReference::GeometryStats before;Clock::time_point start=Clock::now();
    ~MeasureScope(){report.boundary_seconds+=std::chrono::duration<double>(Clock::now()-start).count();
      if(geometry){const auto after=geometry->GeometryStatsSnapshot();report.boundary_upper_queries+=after.upper_calls-before.upper_calls;}}
  } measure{report,query_geometry,query_before};
  const auto validity_start=report.boundary_rejected_validity,shape_start=report.boundary_rejected_shape;
  const auto edge_start=report.boundary_rejected_edge,geometry_start=report.boundary_rejected_geometry;
  if(Limited() || !options.geometry || options.frozen_vertices.count(p))return false;
  const auto found=star.find(p);
  if(found==star.end() || found->second.empty() || found->second.size()>MaximumCavityCells)return false;
  const auto old=found->second;Patch patch;
  for(Id id:old) {
    if(options.frozen_cells.count(id))return false;
    const auto& row=mesh.at(id);patch.cells.push_back(row.cell);const auto faces=OppositeFaces(row.cell);
    for(unsigned k=0;k<4;++k)if(row.physical[k].present)patch.surface.push_back({faces[k],row.physical[k].facet});
  }
  if(patch.surface.empty())return false;
  std::set<Face> old_physical;for(const auto& f:patch.surface)old_physical.insert(Key(f.v));
  for(auto f:Incidence(patch.cells).Boundary())
    if(std::find(f.begin(),f.end(),p)!=f.end() && !old_physical.count(Key(f)))return false;
  const auto& geometry=moved_geometry?*moved_geometry:*options.geometry;
  try {
    SU2NativeD9::Measure(SU2NativeD9::Work::Export, [&] { geometry.ExportParameters(patch); });
  } catch(const std::exception&) {
    return false;
  }
  const bool debt=DebtMode(old,&patch);const auto before=OldMerit(old,debt);const auto origin=points.at(p);
  auto shape_debt=[&](const std::vector<Cell>& cells){long double sum=0;for(const auto& c:cells){const auto q=Quality(c);if(!q.Valid())return std::numeric_limits<long double>::infinity();sum+=NormalizedShapeHingeDebt(q.q,q.J);}return sum;};
  long double old_shape_debt;
  if (debt)
    old_shape_debt = -before;
  else {
    SU2NativeTiming3D::Scope old_cavity_scope(SU2NativeTiming3D::Operation::OldCavityMeasurement);
    old_shape_debt = shape_debt(patch.cells);
  }
  long double geometric_before=0;bool geometry_measured=false;
  std::vector<Point> targets;std::set<Id> neighbors;
  for(const auto& c:patch.cells)for(auto n:c.v)if(n.id!=p)neighbors.insert(n.id);
  if(geometry.Mapped()) {
    const auto binding=patch.parameters.at(p).binding;const auto& authority=geometry.Parameters()->Geometry();
    const auto* mobility=geometry.Mobility();
    if(mobility && authority.MobilityDimension(binding,*mobility)==0)return false;
    if(!mobility && binding.dimension==0 && authority.PhysicalSupport(binding))return false;
    if(!mobility && binding.dimension==1 && (!authority.ReferenceComponents() || authority.PhysicalSupport(binding))) {
      Edge support{};bool located=false;
      authority.ForFacets(binding,[&](Id facet) {
        if(located)return;const auto& f=geometry.Get(facet);
        for(unsigned k=0;k<3;++k){Edge e{f.v[k].id,f.v[(k+1)%3].id};std::sort(e.begin(),e.end());
          if(authority.EdgePoint(e,.5).feature==binding.feature){support=e;located=true;break;}}
      });
      if(!located)return false;
      Point a{},b{};
      authority.ForFacets(binding,[&](Id facet){for(auto n:geometry.Get(facet).v){if(n.id==support[0])a=n.p;if(n.id==support[1])b=n.p;}});
      // Search the forward parameter, not a chord-plane derivative of the already curved point.
      for(unsigned level=1;level<=4;++level) {
        const unsigned denominator=1u<<level;
        for(unsigned k=1;k<denominator;k+=2){const long double t=static_cast<long double>(k)/denominator;
          targets.push_back({double(a.x+t*(b.x-(long double)a.x)),double(a.y+t*(b.y-(long double)a.y)),double(a.z+t*(b.z-(long double)a.z))});}
      }
    } else if(!mobility && binding.dimension==2 && !authority.ReferenceComponents()) {
      const auto& f=geometry.Get(binding.feature);
      for(double h:{.25,.125,.0625,.03125})for(const auto d:std::array<std::array<int,2>,6>{{{{1,0}},{{-1,0}},{{0,1}},{{0,-1}},{{1,-1}},{{-1,1}}}}) {
        const long double u=binding.u+h*d[0],v=binding.v+h*d[1];if(u<=0 || v<=0 || u+v>=1)continue;
        const auto a=f.v[0].p,b=f.v[1].p,c=f.v[2].p;
        targets.push_back({double(a.x+u*(b.x-(long double)a.x)+v*(c.x-(long double)a.x)),
            double(a.y+u*(b.y-(long double)a.y)+v*(c.y-(long double)a.y)),double(a.z+u*(b.z-(long double)a.z)+v*(c.z-(long double)a.z))});
      }
    }
  }
  if(targets.empty())try {
    std::vector<std::pair<Point,Tensor>> samples;double radius=INFINITY;
    for(Id n:neighbors){samples.emplace_back(points.at(n),At(points.at(n)));radius=std::min(radius,double(Norm3(origin,points.at(n))));}
    targets.push_back(MetricMeanPoint(origin,samples));
    for(double step:{.25,.125,.0625})for(unsigned axis=0;axis<3;++axis)for(double sign:{-1.,1.}) {
      Point q=origin;if(axis==0)q.x+=sign*step*radius;else if(axis==1)q.y+=sign*step*radius;else q.z+=sign*step*radius;targets.push_back(q);
    }
  }catch(const std::exception&){return false;}
  auto* atlas_budget=geometry.AtlasReservation();
  struct CallerByteRestore {SU2NativeGeometry::AtlasBudget* budget;size_t original;~CallerByteRestore(){if(budget)budget->caller_bytes=original;}}
      caller_restore{atlas_budget,atlas_budget?atlas_budget->caller_bytes:0};
  GeometryGuidanceMemo guidance_memo;bool guidance_memo_ready=false;
  std::unique_ptr<PreparedVertexMove> prepared_move;bool preparation_attempted=false;
  std::unique_ptr<PlanarReference> projected_context;
  const PlanarReference* projected_geometry=&geometry;
  SU2NativeGeometry::CurvedAtlas prepared_atlas;bool prepared_atlas_ok=false;
  auto charge_retained_geometry=[&](const PlanarReference* candidate_context=nullptr) {
    if(!atlas_budget)return false;
    size_t bytes=caller_restore.original;
    // One new binding and coordinate-map row can be allocated before the next refresh.
    if(projected_context)bytes=transfer_memory::Add(bytes,projected_context->ParameterOverlayBytes(),512);
    if(prepared_atlas_ok)bytes=transfer_memory::Add(bytes,prepared_atlas.ResidentBytes());
    bytes=transfer_memory::Add(bytes,guidance_memo.ResidentBytes());
    if(prepared_move)bytes=transfer_memory::Add(bytes,prepared_move->ResidentBytes());
    if(candidate_context)bytes=transfer_memory::Add(bytes,candidate_context->ParameterOverlayBytes());
    atlas_budget->caller_bytes=bytes;atlas_budget->peak_bytes=std::max(atlas_budget->peak_bytes,bytes);
    return bytes<=atlas_budget->maximum_bytes;
  };
  if(geometry.Mobility()) {
    projected_context=geometry.PrivateParameters(patch);
    if(projected_context)projected_geometry=projected_context.get();
    if(!charge_retained_geometry()){++report.boundary_rejected_geometry;return false;}
    if(!projected_geometry->EntityGeometry()) {
      std::string prepare_reason;
      if(!atlas_budget || !SU2NativeGeometry::PrepareCurvedAtlas(patch,*projected_geometry,p,prepared_atlas,*atlas_budget,prepare_reason)) {
        ++report.boundary_rejected_geometry;
        return false;
      }
      prepared_atlas_ok=true;
      if(!charge_retained_geometry()){++report.boundary_rejected_geometry;return false;}
    }
  }
  Patch best;long double best_score=before;
  for(Point target_point:targets) {
    if(Limited())break;
    ++report.trials;
    ++report.boundary_candidates;
    SU2NativeD9::Candidate d9_candidate;
    Patch candidate;std::string reason;
    if(atlas_budget&&!charge_retained_geometry()){++report.boundary_rejected_geometry;break;}
    if(geometry.Mobility()) {
      // Projection and volume quality precede expensive surface reconstruction; height can only lower this score.
      long double upper=debt?0:INFINITY;
      {
        auto* budget=projected_geometry->AtlasReservation();BoundaryPoint projected;
        {
        SU2NativeD9::WorkScope d9_projection(SU2NativeD9::Work::Projection);
        if(projected_geometry->EntityGeometry()) {
          try {std::set<Id> incident;for(const auto& face:patch.surface)if(std::find(face.v.begin(),face.v.end(),p)!=face.v.end())incident.insert(face.facet);
            projected.node=projected_geometry->BindMovedPoint(p,{next_node,target_point},incident);
          }catch(const std::exception&){++report.rejected_interface;++report.boundary_rejected_geometry;continue;}
          if(!charge_retained_geometry()){++report.boundary_rejected_geometry;continue;}
        } else if(!budget || !prepared_atlas_ok ||
            !SU2NativeGeometry::ProposeAtlasBinding(prepared_atlas,p,{next_node,target_point},projected,*budget,reason)) {
          ++report.rejected_interface;++report.boundary_rejected_geometry;continue;
        }
        }
        for(auto cell:patch.cells) {
          for(auto& node:cell.v)if(node.id==p)node=projected.node;
          const auto measured=Quality(cell,false);
          if(!measured.Valid()){upper=-INFINITY;break;}
          upper=debt?upper-NormalizedShapeHingeDebt(measured.q,measured.J):std::min(upper,static_cast<long double>(measured.Score()));
        }
      }
      if(!std::isfinite(upper)){++report.rejected_validity;++report.boundary_rejected_validity;continue;}
      if(!(Progress(upper,best_score,debt))){++report.rejected_quality;++report.boundary_rejected_shape;continue;}
    }
    // Use the raw proposal again: projecting the realized surface point need not be idempotent.
    if(!preparation_attempted){preparation_attempted=true;
      try{prepared_move=PrepareVertexMove(patch,geometry);}catch(const std::exception&){++report.rejected_interface;++report.boundary_rejected_geometry;continue;}
      if(prepared_move)++report.boundary_move_contexts;
      if(atlas_budget&&!charge_retained_geometry()){++report.boundary_rejected_geometry;break;}
    }
    if(prepared_move)++report.boundary_prepared_trials;
    if(!SU2NativeD9::Measure(SU2NativeD9::Work::Move, [&] {
      return prepared_move ? MoveVertex(*prepared_move,p,{next_node,target_point},next_cell,candidate,reason) :
                             MoveVertex(patch,p,{next_node,target_point},next_cell,geometry,candidate,reason);
    })) {
      ++report.rejected_interface;
      ++report.boundary_rejected_geometry;
      continue;
    }
    const auto score=FreshMerit(candidate.cells,debt,false,&candidate);
    if(!std::isfinite(score)){++report.rejected_validity;++report.boundary_rejected_validity;continue;}
    if(!(Progress(score,best_score,debt))){++report.rejected_quality;++report.boundary_rejected_shape;continue;}
    auto candidate_parameters=geometry.PrivateParameters(candidate);const auto& candidate_geometry=candidate_parameters?*candidate_parameters:geometry;
    if(atlas_budget&&!charge_retained_geometry(candidate_parameters.get())){++report.boundary_rejected_geometry;continue;}
    FirstHeightReport height;
    if(GetShapeAdmission()==ShapeAdmission::Absolute && !CheckFirstHeight(candidate,options.wall_heights,candidate_geometry,height,reason)){++report.rejected_frozen;++report.boundary_rejected_geometry;continue;}
    bool sized=true;
    for(const auto& c:candidate.cells)for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j)
      if((c.v[i].id==next_node || c.v[j].id==next_node) && !Certified(c.v[i].p,c.v[j].p,MaximumMetricEdge))sized=false;
    if(!sized){++report.rejected_edge;++report.boundary_rejected_edge;continue;}
    if(!geometry_measured){
      if(std::any_of(patch.surface.begin(),patch.surface.end(),[&](const SurfaceFace& f){return std::find(f.v.begin(),f.v.end(),p)==f.v.end();}))
        guidance_memo_ready=guidance_memo.Prepare(patch,geometry,options.surface_tolerance);
      if(atlas_budget&&!charge_retained_geometry(candidate_parameters.get())){++report.boundary_rejected_geometry;return false;}
      ++report.boundary_guidance_calls;
      const auto guidance=SU2NativeD9::Measure(SU2NativeD9::Work::Guidance, [&] { return GeometryGuidanceExcess(patch,geometry,options.surface_tolerance,INFINITY,guidance_memo_ready?&guidance_memo:nullptr); });
      report.boundary_guidance_faces+=guidance.evaluated_faces;report.boundary_guidance_reused_faces+=guidance.reused_faces;geometric_before=guidance.excess;geometry_measured=true;
    }
    ++report.boundary_guidance_calls;
    const auto guidance=SU2NativeD9::Measure(SU2NativeD9::Work::Guidance, [&] { return GeometryGuidanceExcess(candidate,candidate_geometry,options.surface_tolerance,geometric_before,guidance_memo_ready?&guidance_memo:nullptr); });
    report.boundary_guidance_faces+=guidance.evaluated_faces;report.boundary_guidance_reused_faces+=guidance.reused_faces;report.boundary_guidance_early_rejections+=!guidance.complete;
    const auto after=guidance.excess;
    if(!guidance.complete||!std::isfinite(after)||after>geometric_before){++report.rejected_interface;++report.boundary_rejected_geometry;continue;}
    best_score=score;best=std::move(candidate);
    if(debt?best_score>=0:best_score>=1)break;
  }
  if(best.cells.empty()) {
    auto* reservation=geometry.AtlasReservation();
    if(!Limited() && std::isfinite(before) && report.boundary_candidates && report.boundary_rejected_shape>shape_start &&
        report.boundary_rejected_validity==validity_start && report.boundary_rejected_edge==edge_start &&
        report.boundary_rejected_geometry==geometry_start &&
        (!reservation || (!reservation->work_exhausted && !reservation->time_exhausted && reservation->geometry_failure.empty())))RememberRejectedSmooth(p);
    return false;
  }
  prepared_atlas={};projected_context.reset();prepared_move.reset();guidance_memo=GeometryGuidanceMemo{};
  if(atlas_budget)atlas_budget->caller_bytes=caller_restore.original;
  const auto debt_reduction=old_shape_debt-(debt?-best_score:shape_debt(best.cells));
  if(std::isfinite(old_shape_debt)&&std::isfinite(debt_reduction))report.boundary_debt_reduction+=debt_reduction;
  ++report.boundary_moves;
  std::map<Face,FacetBinding> added;for(const auto& f:best.surface)added.emplace(Key(f.v),FacetBinding{true,f.facet});
  const Id moved=next_node++;Commit(old,best.cells,p,added);
  report.parameters.erase(p);for(const auto& row:best.parameters)report.parameters.insert_or_assign(row.first,row.second);
  for(const auto& row:best.coverage.faces)report.coverage.faces.insert_or_assign(row.first,row.second);
  for(const auto& row:best.coverage.traces)report.coverage.traces.insert_or_assign(row.first,row.second);
  for(auto it=report.coverage.faces.begin();it!=report.coverage.faces.end();)if(!physical.count(Key(it->first)))it=report.coverage.faces.erase(it);else ++it;
  for(auto it=report.coverage.traces.begin();it!=report.coverage.traces.end();)if(!Adjacent(it->first[0],it->first[1]))it=report.coverage.traces.erase(it);else ++it;
  Patch overlay;overlay.parameters=report.parameters;overlay.coverage=report.coverage;
  overlay.surface=best.surface;
  auto parameters=geometry.PrivateParameters(overlay);if(parameters)moved_geometry=std::move(parameters);
  fixed.erase(p);fixed.insert(moved);if(keep.erase(p))keep.insert(moved);
  Id first=p;for(const auto& row:report.relabel)if(row.second==p){first=row.first;break;}
  report.relabel[first]=moved;++report.moves;return true;
}
bool MeshOptimizer::Smooth(Id p) {
  if(fixed.count(p) && !sliding.count(p) && options.geometry) {
    if(Limited())return false;
    if(rejected_smoothing.count(p)){++report.trials;++report.boundary_stars_reused;return false;}
    return SmoothBoundary(p);
  }
  if(Limited()||!Movable(p))return false;
  if(rejected_smoothing.count(p)){++report.trials;++report.interior_stars_reused;return false;}
  ++report.interior_stars_searched;
  const auto* state=options.geometry?options.geometry->Parameters():nullptr;
  const auto* query_geometry=state?&state->Geometry():nullptr;
  const auto query_before=query_geometry?query_geometry->GeometryStatsSnapshot():SU2NativeGeometry::MappedFacetReference::GeometryStats{};
  struct MeasureScope {
    OptimizeReport& report;const SU2NativeGeometry::MappedFacetReference* geometry;
    SU2NativeGeometry::MappedFacetReference::GeometryStats before;Clock::time_point start=Clock::now();
    ~MeasureScope(){report.interior_seconds+=std::chrono::duration<double>(Clock::now()-start).count();
      if(geometry){const auto after=geometry->GeometryStatsSnapshot();report.interior_upper_queries+=after.upper_calls-before.upper_calls;}}
  } measure{report,query_geometry,query_before};
  const auto validity_start=report.interior_rejected_validity,shape_start=report.interior_rejected_shape;
  const auto edge_start=report.interior_rejected_edge,geometry_start=report.interior_rejected_geometry;
  const auto old=star.at(p);const Point x0=points.at(p);
  auto shape_debt=[&](const std::vector<Cell>& cells){long double sum=0;for(const auto& c:cells){const auto q=Quality(c);if(!q.Valid())return std::numeric_limits<long double>::infinity();sum+=NormalizedShapeHingeDebt(q.q,q.J);}return sum;};
  std::set<Id> nbr;for(Id id:old)for(const auto& v:mesh.at(id).cell.v)if(v.id!=p)nbr.insert(v.id);
  ++report.trials;
  const bool debt=DebtMode(old);const auto oldMin=OldMerit(old,debt);
  std::vector<Cell> old_cells;for(Id id:old)old_cells.push_back(mesh.at(id).cell);
  long double old_shape_debt;
  if (debt)
    old_shape_debt = -oldMin;
  else {
    SU2NativeTiming3D::Scope old_cavity_scope(SU2NativeTiming3D::Operation::OldCavityMeasurement);
    old_shape_debt = shape_debt(old_cells);
  }
  long double oldMax=0,shortest=INFINITY;
  for(Id x:nbr){const Point px=points.at(x);try{oldMax=std::max(oldMax,Estimate(x0,px));}catch(const std::exception&){oldMax=INFINITY;}
    const long double dx=(long double)px.x-x0.x,dy=(long double)px.y-x0.y,dz=(long double)px.z-x0.z;shortest=std::min(shortest,std::sqrt(dx*dx+dy*dy+dz*dz));}
  const long double limit=std::max<long double>(MaximumMetricEdge,oldMax);
  std::vector<Point> targets;
  if(options.geometry && !options.wall_heights.empty()) {
    std::vector<Cell> cells;for(Id id:old)cells.push_back(mesh.at(id).cell);
    const auto patch=GeometryPatch(cells);
    for(const auto& f:patch.surface) {
      const auto h=options.wall_heights.find(options.geometry->Get(f.facet).marker);
      if(h==options.wall_heights.end() || std::find(f.v.begin(),f.v.end(),p)!=f.v.end())continue;
      bool apex=false;for(const auto& c:patch.cells){unsigned hits=0;for(auto n:c.v)hits+=std::find(f.v.begin(),f.v.end(),n.id)!=f.v.end();apex=apex || hits==3;}
      if(!apex)continue;
      const auto a=points.at(f.v[0]),b=points.at(f.v[1]),c=points.at(f.v[2]);long double normal[3];const auto area=Area2(a,b,c,normal);
      if(!(area>0))continue;
      const long double correction=(((long double)x0.x-a.x)*normal[0]+((long double)x0.y-a.y)*normal[1]+
          ((long double)x0.z-a.z)*normal[2])/area+h->second;
      targets.push_back({double(x0.x-correction*normal[0]/area),double(x0.y-correction*normal[1]/area),double(x0.z-correction*normal[2]/area)});
      targets.push_back({double(((long double)a.x+b.x+c.x)/3-h->second*normal[0]/area),
          double(((long double)a.y+b.y+c.y)/3-h->second*normal[1]/area),double(((long double)a.z+b.z+c.z)/3-h->second*normal[2]/area)});
    }
  }
  try{std::vector<std::pair<Point,Tensor>> samples;for(Id x:nbr)samples.push_back({points.at(x),At(points.at(x))});targets.push_back(MetricMeanPoint(x0,samples));}catch(const std::exception&){}
  try{  // damped hinge Gauss-Newton on the failing cells of the star (LinearizeMetricShape residuals, 1% interior aim)
    long double g[3]={0,0,0},H[3][3]={{0,0,0},{0,0,0},{0,0,0}};bool any=false;
    for(Id id:old){const auto& c=mesh.at(id).cell;if(Score(c)>=1.01)continue;unsigned slot=0;while(c.v[slot].id!=p)++slot;
      const auto L=LinearizeMetricShape({c.v[0].p,c.v[1].p,c.v[2].p,c.v[3].p},At(Centroid(c)));
      for(unsigned r=0;r<2;++r)if(L.residual[r]>0){any=true;const auto& d=L.derivative[r][slot];
        for(unsigned i=0;i<3;++i){g[i]+=L.residual[r]*d[i];for(unsigned j=0;j<3;++j)H[i][j]+=(long double)d[i]*d[j];}}}
    if(any) {
      const long double trace=H[0][0]+H[1][1]+H[2][2];if(!(trace>0))throw std::runtime_error("flat hinge");
      for(unsigned i=0;i<3;++i)H[i][i]+=1e-6L*trace;
      long double M[3][4];for(unsigned i=0;i<3;++i){for(unsigned j=0;j<3;++j)M[i][j]=H[i][j];M[i][3]=-g[i];}
      for(unsigned c=0;c<3;++c){unsigned r=c;for(unsigned t=c+1;t<3;++t)if(std::abs(M[t][c])>std::abs(M[r][c]))r=t;if(!(std::abs(M[r][c])>0))throw std::runtime_error("singular hinge");
        for(unsigned q=0;q<4;++q)std::swap(M[c][q],M[r][q]);for(unsigned t=0;t<3;++t)if(t!=c){const auto f=M[t][c]/M[c][c];for(unsigned q=c;q<4;++q)M[t][q]-=f*M[c][q];}}
      long double d[3];for(unsigned i=0;i<3;++i)d[i]=M[i][3]/M[i][i];
      const long double norm=std::sqrt(d[0]*d[0]+d[1]*d[1]+d[2]*d[2]),cap=.5L*shortest;
      if(norm>cap&&norm>0)for(auto& v:d)v*=cap/norm;
      if(std::isfinite(norm)&&norm>0)targets.push_back({double(x0.x+d[0]),double(x0.y+d[1]),double(x0.z+d[2])});
    }
  }catch(const std::exception&){}
  // DC-13 O4m: bounded placement over the star (approximate proposal, exact merit below), from p and each proposal
  bool placed=false;
  const auto slideIt=sliding.find(p);const bool slides=slideIt!=sliding.end();const std::array<double,3> plane=slides?slideIt->second:std::array<double,3>{0,0,0};
  auto inPlane=[&](Point t)->Point{if(!slides)return t;const auto& n=plane;const double d=(t.x-x0.x)*n[0]+(t.y-x0.y)*n[1]+(t.z-x0.z)*n[2];return {t.x-d*n[0],t.y-d*n[1],t.z-d*n[2]};};
  for(auto& t:targets)t=inPlane(t);
  {std::vector<Cell> cells;for(Id id:old)cells.push_back(mesh.at(id).cell);auto faces=CavityBoundary(cells);
   faces.erase(std::remove_if(faces.begin(),faces.end(),[&](const Face& f){return f[0]==p||f[1]==p||f[2]==p;}),faces.end());  // the link of p
   std::vector<Point> starts{x0};for(const auto& t:targets)starts.push_back(t);Placement best;
   for(const auto& st:starts){const auto pl=PlaceCone(faces,[&](Id v){return points.at(v);},[&](Point q){return At(q);},st,nullptr,std::max<size_t>(16,options.placement_budget/starts.size()),debt);
     report.placement_evaluations+=pl.evaluations;if(pl.ok&&pl.score>best.score)best=pl;}
   if(best.ok)best.x=inPlane(best.x);
   ++report.placements;if(best.ok&&!(best.x.x==x0.x&&best.x.y==x0.y&&best.x.z==x0.z)){targets.insert(targets.begin(),best.x);placed=true;}}
  Patch constraints;
  if(debt && options.geometry && !options.wall_heights.empty()) {
    std::vector<Cell> cells;for(Id id:old)cells.push_back(mesh.at(id).cell);
    constraints=GeometryPatch(cells);
  }
  struct Trial{long double score;Point x;};std::vector<Trial> trials;
  for(size_t ti=0;ti<targets.size();++ti)for(long double w:{1.L,.5L,.25L}) {const Point t=targets[ti];if(ti==0&&placed&&w!=1.L)continue;  // the placed point is tried as is
    Point x{double(x0.x+w*((long double)t.x-x0.x)),double(x0.y+w*((long double)t.y-x0.y)),double(x0.z+w*((long double)t.z-x0.z))};
    if(!constraints.cells.empty()) {
      const auto& geometry=moved_geometry?*moved_geometry:*options.geometry;
      x=ConstrainMovePoint(constraints,p,{next_node,x},options.wall_heights,geometry).p;
    }
    if(x.x==x0.x&&x.y==x0.y&&x.z==x0.z)continue;
    ++report.interior_candidates;
    const Node P{next_node,x};std::vector<Cell> fresh;for(Id id:old){Cell c=mesh.at(id).cell;for(auto& v:c.v)if(v.id==p)v=P;fresh.push_back(c);}
    const auto s=FreshMerit(fresh,debt,false);  // the trial identity next_node is reused: never memoized
    if(s==-INFINITY){++report.rejected_validity;++report.interior_rejected_validity;}
    else if(Progress(s,oldMin,debt))trials.push_back({s,x});
    else {++report.rejected_quality;++report.interior_rejected_shape;}
  }
  if(trials.empty()) {
    auto* reservation=options.geometry?options.geometry->AtlasReservation():nullptr;
    if(!Limited() && std::isfinite(oldMin) && report.interior_candidates && report.interior_rejected_shape>shape_start &&
        report.interior_rejected_validity==validity_start && report.interior_rejected_edge==edge_start &&
        report.interior_rejected_geometry==geometry_start &&
        (!reservation || (!reservation->work_exhausted && !reservation->time_exhausted && reservation->geometry_failure.empty())))RememberRejectedSmooth(p);
    return false;
  }
  std::stable_sort(trials.begin(),trials.end(),[](const Trial& u,const Trial& v){return u.score>v.score;});
  for(const auto& t:trials) {
    bool ok=true;for(Id x:nbr)if(!Certified(t.x,points.at(x),limit)){ok=false;break;}
    if(!ok){++report.rejected_edge;++report.interior_rejected_edge;continue;}
    const Node P{next_node,t.x};std::vector<Cell> fresh;for(Id id:old){Cell c=mesh.at(id).cell;for(auto& v:c.v)if(v.id==p)v=P;fresh.push_back(c);}
    std::map<Face,FacetBinding> added;
    if(slides){for(Id id:old){const auto& row=mesh.at(id);const auto faces=OppositeFaces(row.cell);  // diagnostic: bindings follow the moved skin vertex
        for(unsigned k=0;k<4;++k)if(row.physical[k].present){auto f=faces[k];if(f[0]!=p&&f[1]!=p&&f[2]!=p)continue;for(auto& x:f)if(x==p)x=P.id;std::sort(f.begin(),f.end());added.emplace(f,row.physical[k]);}}}
    else if(!Interface(old,fresh)){++report.interior_rejected_geometry;continue;}
    const auto debt_reduction=old_shape_debt-(debt?-t.score:shape_debt(fresh));
    if(std::isfinite(old_shape_debt)&&std::isfinite(debt_reduction))report.interior_debt_reduction+=debt_reduction;
    ++report.interior_moves;
    const Id moved=next_node++;Commit(old,fresh,p,added);
    if(slides){sliding.erase(p);sliding[moved]=plane;fixed.insert(moved);}
    if(keep.erase(p))keep.insert(moved);
    Id origin=p;for(const auto& r:report.relabel)if(r.second==p){origin=r.first;break;}
    report.relabel[origin]=moved;++report.moves;return true;
  }
  auto* reservation=options.geometry?options.geometry->AtlasReservation():nullptr;
  if(!Limited() && std::isfinite(oldMin) && report.interior_candidates && report.interior_rejected_shape>shape_start &&
      report.interior_rejected_validity==validity_start && report.interior_rejected_edge==edge_start &&
      report.interior_rejected_geometry==geometry_start &&
      (!reservation || (!reservation->work_exhausted && !reservation->time_exhausted && reservation->geometry_failure.empty())))RememberRejectedSmooth(p);
  return false;
}
// O5: boundary edge (a,b) between two boundary faces bound to the same facet (coplanar within 1e-12 relative); its open
// shell (ring path r_0..r_m from one face to the other) is replaced by the best triangulation of the polygon r_0..r_m
// coned to a and b, the boundary pair (a,b,r_0),(a,b,r_m) becoming (a,r_0,r_m),(b,r_0,r_m).
bool MeshOptimizer::BoundaryFlip(Id a,Id b) {
  if(Limited()||options.frozen_vertices.count(a)||options.frozen_vertices.count(b))return false;
  const auto sa=star.find(a),sb=star.find(b);if(sa==star.end()||sb==star.end())return false;
  const auto shell=Common(sa->second,sb->second);const size_t n=shell.size();
  if(n<2||n+1>options.maximum_shell)return false;
  for(Id id:shell)if(Frozen(id)){++report.rejected_frozen;return false;}
  std::vector<BoundaryFace> faces;for(const auto& f:BoundaryFacesOf(shell,UINT64_MAX)){int k=0;for(Id x:f.oriented)k+=x==a||x==b;if(k==2)faces.push_back(f);}
  if(faces.size()!=2||faces[0].binding.facet!=faces[1].binding.facet)return false;
  std::map<Id,std::vector<Id>> ring;
  for(Id id:shell){std::vector<Id> o;for(const auto& v:mesh.at(id).cell.v)if(v.id!=a&&v.id!=b)o.push_back(v.id);if(o.size()!=2)return false;ring[o[0]].push_back(o[1]);ring[o[1]].push_back(o[0]);}
  Id r0=UINT64_MAX,rm=UINT64_MAX;for(Id x:faces[0].oriented)if(x!=a&&x!=b)r0=x;for(Id x:faces[1].oriented)if(x!=a&&x!=b)rm=x;
  if(r0==UINT64_MAX||rm==UINT64_MAX||r0==rm||Adjacent(r0,rm)||ring.size()!=n+1||ring.at(r0).size()!=1||ring.at(rm).size()!=1)return false;
  std::vector<Id> order{r0};{Id prev=UINT64_MAX,cur=r0;while(cur!=rm){const auto& nb=ring.at(cur);Id nx=UINT64_MAX;for(Id y:nb)if(y!=prev)nx=y;if(nx==UINT64_MAX||order.size()>n)return false;order.push_back(nx);prev=cur;cur=nx;}}
  if(order.size()!=n+1)return false;
  Point pa=points.at(a),pb=points.at(b);
  if(!(Orientation(pa,pb,points.at(order[0]),points.at(order[1]))>0)){std::swap(a,b);std::swap(pa,pb);}
  for(size_t i=0;i+1<order.size();++i)if(!(Orientation(pa,pb,points.at(order[i]),points.at(order[i+1]))>0))return false;
  {long double scale=0;for(Point p:{pa,pb,points.at(r0),points.at(rm)})for(Point q:{pa,pb,points.at(r0),points.at(rm)})
     scale=std::max(scale,std::sqrt(((long double)p.x-q.x)*((long double)p.x-q.x)+((long double)p.y-q.y)*((long double)p.y-q.y)+((long double)p.z-q.z)*((long double)p.z-q.z)));
   if(!(std::abs(Orientation(pa,pb,points.at(r0),points.at(rm)))<=1e-12L*scale*scale*scale))return false;}
  ++report.trials;
  const bool debt=DebtMode(shell);const auto oldMin=OldMerit(shell,debt);const size_t m=order.size();
  const Node A{a,pa},B{b,pb};std::vector<Node> r(m);for(size_t i=0;i<m;++i)r[i]={order[i],points.at(order[i])};
  std::map<std::array<size_t,3>,long double> tri;
  auto triangle=[&](size_t i,size_t k,size_t j){const std::array<size_t,3> key{i,k,j};const auto f=tri.find(key);if(f!=tri.end())return f->second;
    const auto s=FreshMerit({Cell{0,{A,r[i],r[k],r[j]}},Cell{0,{B,r[i],r[j],r[k]}}},debt);tri.emplace(key,s);return s;};
  std::set<std::pair<size_t,size_t>> forbidden;auto ringEdge=[&](size_t i,size_t j){return j==i+1||(i==0&&j==m-1);};
  if(!Certified(r[0].p,r[m-1].p,MaximumMetricEdge)){++report.rejected_edge;return false;}
  for(unsigned attempt=0;attempt<4;++attempt) {
    std::vector<std::vector<long double>> best(m,std::vector<long double>(m,-INFINITY));std::vector<std::vector<size_t>> arg(m,std::vector<size_t>(m,SIZE_MAX));
    for(size_t i=0;i+1<m;++i)best[i][i+1]=debt?0:INFINITY;
    for(size_t len=2;len<m;++len)for(size_t i=0;i+len<m;++i){const size_t j=i+len;
      for(size_t k=i+1;k<j;++k){if((!ringEdge(i,k)&&forbidden.count({i,k}))||(!ringEdge(k,j)&&forbidden.count({k,j})))continue;
        const auto v=debt?best[i][k]+best[k][j]+triangle(i,k,j):std::min({best[i][k],best[k][j],triangle(i,k,j)});if(v>best[i][j]){best[i][j]=v;arg[i][j]=k;}}}
    if(!(Progress(best[0][m-1],oldMin,debt))){if(best[0][m-1]==-INFINITY)++report.rejected_validity;else ++report.rejected_quality;return false;}
    std::vector<std::array<size_t,3>> used;std::vector<std::pair<size_t,size_t>> stack{{0,m-1}};
    while(!stack.empty()){const auto e=stack.back();stack.pop_back();if(e.second<=e.first+1)continue;const size_t k=arg[e.first][e.second];
      used.push_back({e.first,k,e.second});stack.push_back({e.first,k});stack.push_back({k,e.second});}
    bool ok=true;
    for(const auto& t:used)for(const auto& d:{std::make_pair(t[0],t[1]),std::make_pair(t[1],t[2]),std::make_pair(t[0],t[2])}){
      if(ringEdge(d.first,d.second)||forbidden.count(d))continue;if(!Certified(r[d.first].p,r[d.second].p,MaximumMetricEdge)){forbidden.insert(d);ok=false;break;}}
    if(!ok){++report.rejected_edge;if(Limited())return false;continue;}
    std::vector<Cell> fresh;for(const auto& t:used){fresh.push_back(Cell{0,{A,r[t[0]],r[t[1]],r[t[2]]}});fresh.push_back(Cell{0,{B,r[t[0]],r[t[2]],r[t[1]]}});}
    if(!Progress(FreshMerit(fresh,debt),oldMin,debt)){++report.rejected_quality;return false;}
    std::map<Face,FacetBinding> added;if(!BoundaryReplacement(shell,fresh,faces,faces[0].binding,added))return false;
    Commit(shell,fresh,UINT64_MAX,added);++report.boundary_flips;return true;
  }
  return false;
}
// O6: boundary vertex p, every incident boundary face bound to one facet (p interior to it), contracted to a neighbour q
// along a boundary edge of that facet; area and orientation of the facet patch are kept.
bool MeshOptimizer::BoundaryCollapse(Id p,Id q) {
  if(Limited()||!fixed.count(p)||options.frozen_vertices.count(p)||keep.count(p)||!Adjacent(p,q))return false;
  const auto sp=star.find(p);if(sp==star.end()||sp->second.size()>MaximumCavityCells)return false;
  const auto old=sp->second;for(Id id:old)if(Frozen(id)){++report.rejected_frozen;return false;}
  const auto faces=BoundaryFacesOf(old,p);if(faces.empty())return false;
  for(const auto& f:faces)if(f.binding.facet!=faces.front().binding.facet)return false;
  bool edge=false;for(const auto& f:faces)edge=edge||f.oriented[0]==q||f.oriented[1]==q||f.oriented[2]==q;if(!edge)return false;
  // p is interior to the facet patch: its boundary faces close a fan around it (every boundary edge at p used twice)
  {std::map<Id,int> uses;for(const auto& f:faces)for(Id x:f.oriented)if(x!=p)++uses[x];for(const auto& u:uses)if(u.second!=2)return false;
   // the fan (p and its boundary ring) is planar within 1e-12 relative: the contracted faces stay in the facet's plane
   const auto& f0=faces.front().oriented;long double scale=0;for(const auto& u:uses)scale=std::max(scale,(long double)Norm3(points.at(u.first),points.at(p)));
   for(const auto& u:uses)if(!(std::abs(Orientation(points.at(f0[0]),points.at(f0[1]),points.at(f0[2]),points.at(u.first)))<=1e-12L*scale*scale*scale))return false;
   if(!(std::abs(Orientation(points.at(f0[0]),points.at(f0[1]),points.at(f0[2]),points.at(p)))<=1e-12L*scale*scale*scale))return false;}
  ++report.trials;
  const Node Q{q,points.at(q)};std::vector<Cell> fresh;std::set<Id> link;
  for(Id id:old){const auto& c=mesh.at(id).cell;for(const auto& v:c.v)if(v.id!=p)link.insert(v.id);if(CellHas(c,q))continue;Cell x=c;for(auto& v:x.v)if(v.id==p)v=Q;fresh.push_back(x);}
  if(fresh.empty())return false;
  const bool debt=DebtMode(old);const auto oldMin=OldMerit(old,debt),newMin=FreshMerit(fresh,debt);
  if(newMin==-INFINITY){++report.rejected_validity;return false;}
  if(!(Progress(newMin,oldMin,debt))){++report.rejected_quality;return false;}
  for(Id x:link){if(x==q||Adjacent(q,x))continue;if(!Certified(Q.p,points.at(x),MaximumMetricEdge)){++report.rejected_edge;return false;}}
  std::map<Face,FacetBinding> added;if(!BoundaryReplacement(old,fresh,faces,faces.front().binding,added))return false;
  Commit(old,fresh,p,added);++report.boundary_collapses;return true;
}
// DC-13: replace the unfrozen cavity `old` by the cone from one new vertex placed by the merit search (proposal with
// vertex-mean tensors), accepted on the exact checks: every cavity vertex kept, exact positivity and validity of every
// fresh cell, patch-merit progress (or nonregression for Length), ValidateFixedInterface and
// the edge guard on every new edge (limit max(1.8, removed) or, for Length, max(1.8, .75 removed)).
bool MeshOptimizer::ConeReplace(const std::vector<Id>& old,Point start,Insert kind,const std::pair<Id,Id>* split,long double removed) {
  if(Limited()||old.empty()||old.size()>MaximumCavityCells)return false;
  for(Id id:old)if(Frozen(id)){++report.rejected_frozen;return false;}
  ++report.trials;
  std::vector<Cell> cells;std::set<Id> vertices;for(Id id:old){cells.push_back(mesh.at(id).cell);for(const auto& v:cells.back().v)vertices.insert(v.id);}
  const auto faces=CavityBoundary(cells);
  const bool debt=DebtMode(old);const auto oldMin=OldMerit(old,debt);
  std::function<bool(Point)> admissible;
  if(split){const Point pa=points.at(split->first),pb=points.at(split->second);Tensor m=At(pa);const Tensor mb=At(pb);
    m.xx=(m.xx+mb.xx)/2;m.xy=(m.xy+mb.xy)/2;m.xz=(m.xz+mb.xz)/2;m.yy=(m.yy+mb.yy)/2;m.yz=(m.yz+mb.yz)/2;m.zz=(m.zz+mb.zz)/2;
    long double whole=0;try{whole=MetricNorm(pa,pb,m);}catch(const std::exception&){return false;}
    admissible=[pa,pb,m,whole](Point x){try{return MetricNorm(x,pa,m)<=.6L*whole&&MetricNorm(x,pb,m)<=.6L*whole;}catch(const std::exception&){return false;}};}
  const auto pl=PlaceCone(faces,[&](Id v){return points.at(v);},[&](Point q){return At(q);},start,admissible,options.placement_budget,debt);
  ++report.placements;report.placement_evaluations+=pl.evaluations;
  if(!pl.ok){++report.rejected_validity;return false;}
  const Node X{next_node,pl.x};std::vector<Cell> fresh;std::set<Id> kept;
  for(const auto& f:faces){fresh.push_back(Cell{0,{X,Node{f[0],points.at(f[0])},Node{f[1],points.at(f[1])},Node{f[2],points.at(f[2])}}});for(Id v:f)kept.insert(v);}
  if(kept.size()!=vertices.size()){++report.placement_refusals;return false;}  // a cavity vertex would vanish
  const auto newMin=FreshMerit(fresh,debt,false);  // trial identity next_node: never memoized
  if(newMin==-INFINITY){++report.rejected_validity;++report.placement_refusals;return false;}
  if(!(Progress(newMin,oldMin,debt,kind==Insert::Length))){++report.rejected_quality;++report.placement_refusals;return false;}
  const long double limit=kind==Insert::Length?std::max<long double>(MaximumMetricEdge,.75L*removed):std::max<long double>(MaximumMetricEdge,removed);
  for(Id v:vertices)if(!Certified(X.p,points.at(v),limit)){++report.rejected_edge;++report.placement_refusals;return false;}
  if(split) {  // O7L: both halves of the removed edge are integrated exactly and strictly shorter than it
    try{for(Id e:{split->first,split->second})if(!(Exact(X.p,points.at(e))<removed)){++report.rejected_edge;++report.placement_refusals;return false;}}
    catch(const std::exception&){++report.rejected_edge;++report.placement_refusals;return false;}}
  if(!Interface(old,fresh)){++report.placement_refusals;return false;}
  ++next_node;Commit(old,fresh);
  ++(kind==Insert::Shell?report.shell_insertions:kind==Insert::Neighbourhood?report.neighbourhood_insertions:report.length_insertions);
  return true;
}
// O7 / O7L: the shell of edge (a,b) (closed ring for O7L) re-coned from a vertex placed near the edge midpoint.
bool MeshOptimizer::ShellInsert(Id a,Id b,bool lengthDriven) {
  if(Limited()||!options.insertions)return false;
  const auto sa=star.find(a),sb=star.find(b);if(sa==star.end()||sb==star.end())return false;
  auto shell=Common(sa->second,sb->second);if(shell.size()<2||shell.size()>2*options.maximum_shell)return false;
  if(!lengthDriven){shell.erase(std::remove_if(shell.begin(),shell.end(),[&](Id id){return Frozen(id);}),shell.end());if(shell.empty())return false;}  // partial shell: the edge stays
  if(lengthDriven){std::map<Id,int> ring;for(Id id:shell)for(const auto& v:mesh.at(id).cell.v)if(v.id!=a&&v.id!=b)++ring[v.id];
    if(ring.size()!=shell.size())return false;for(const auto& r:ring)if(r.second!=2)return false;}  // closed shell only
  const Point pa=points.at(a),pb=points.at(b);
  const Point mid{double(((long double)pa.x+pb.x)/2),double(((long double)pa.y+pb.y)/2),double(((long double)pa.z+pb.z)/2)};
  long double removed=MaximumMetricEdge;try{const auto e=Estimate(pa,pb);removed=e>EstimatePass?Exact(pa,pb):e;}catch(const std::exception&){return false;}
  const std::pair<Id,Id> edge{a,b};
  return ConeReplace(shell,mid,lengthDriven?Insert::Length:Insert::Shell,lengthDriven?&edge:nullptr,removed);
}
// O8: the bad cell and its face neighbours across interior faces re-coned from a vertex placed near its centroid.
bool MeshOptimizer::NeighbourhoodInsert(Id cell) {
  if(Limited()||!options.insertions||!mesh.count(cell))return false;
  const auto& c=mesh.at(cell).cell;std::vector<Id> old{cell};
  for(auto f:OppositeFaces(c)){const auto both=Common(Common(star.at(f[0]),star.at(f[1])),star.at(f[2]));for(Id id:both)if(id!=cell&&!Frozen(id))old.push_back(id);}  // a frozen neighbour stays: its face bounds the cavity
  if(Frozen(cell))return false;
  return ConeReplace(old,Centroid(c),Insert::Neighbourhood);
}
bool MeshOptimizer::ShellBoundary(Id id) {
  D9QueryScope d9_query(SU2NativeD9::Site::ShellBoundary, options.geometry);
  if(Limited() || !options.geometry || Frozen(id))return false;
  const auto& row=mesh.at(id);std::vector<unsigned> faces;
  for(unsigned k=0;k<4;++k)if(row.physical[k].present)faces.push_back(k);
  if(faces.size()!=2)return false;
  // Opposite vertices form the new physical diagonal; its entire current ring is the dependency closure.
  const Id a=row.cell.v[faces[0]].id,b=row.cell.v[faces[1]].id;
  const auto shell=Common(star.at(a),star.at(b));
  if(shell.size()<3 || shell.size()>options.maximum_shell)return false;
  for(Id c:shell)if(Frozen(c)){++report.rejected_frozen;return false;}
  ++report.trials;std::vector<Cell> cells;for(Id c:shell)cells.push_back(mesh.at(c).cell);
  const auto old=GeometryPatch(cells);const auto& geometry=moved_geometry?*moved_geometry:*options.geometry;
  Patch fresh;std::string reason;
  if(!ShellBoundaryCell(old,id,next_cell,geometry,fresh,reason)){++report.rejected_interface;return false;}
  const bool debt=DebtMode(shell,&old);const auto score=FreshMerit(fresh.cells,debt,false,&fresh);
  if(!std::isfinite(score)){++report.rejected_validity;return false;}
  if(!(Progress(score,OldMerit(shell,debt),debt))){++report.rejected_quality;return false;}
  auto context=geometry.PrivateParameters(fresh);const auto& proposed=context?*context:geometry;
  std::map<Face,FacetBinding> bindings;bool strict_geometry=true;
  for(const auto& face:fresh.surface) {
    const auto key=Key(face.v);
    if(!physical.count(key) && options.surface_tolerance>0) {
      const std::array<Point,3> p{points.at(face.v[0]),points.at(face.v[1]),points.at(face.v[2])};
      if(!(proposed.SurfaceDeviation(face.facet,p,SU2NativeGeometry::SurfaceQueryNeed::Classify(),true)<=options.surface_tolerance)) {
        strict_geometry=false;
      }
    }
    bindings.emplace(key,FacetBinding{true,face.facet});
  }
  if(!strict_geometry) {
    if(GetShapeAdmission()!=ShapeAdmission::ValidityOnly){++report.rejected_interface;return false;}
    // As for boundary smoothing, a useful intermediate may retain non-increasing geometry debt.
    const auto before=GeometryGuidanceExcess(old,geometry,options.surface_tolerance);
    const auto after=GeometryGuidanceExcess(fresh,proposed,options.surface_tolerance,before.excess);
    if(!before.complete || !after.complete || !std::isfinite(after.excess) || after.excess>before.excess) {
      ++report.rejected_interface;return false;
    }
  }
  Commit(shell,fresh.cells,UINT64_MAX,bindings);
  for(const auto& p:fresh.parameters)report.parameters.insert_or_assign(p.first,p.second);
  for(const auto& trace:fresh.coverage.traces)report.coverage.traces.insert_or_assign(trace.first,trace.second);
  for(const auto& face:fresh.coverage.faces)report.coverage.faces.insert_or_assign(face.first,face.second);
  for(auto i=report.coverage.faces.begin();i!=report.coverage.faces.end();)if(!physical.count(Key(i->first)))i=report.coverage.faces.erase(i);else ++i;
  for(auto i=report.coverage.traces.begin();i!=report.coverage.traces.end();)if(!Adjacent(i->first[0],i->first[1]))i=report.coverage.traces.erase(i);else ++i;
  Patch overlay;overlay.parameters=report.parameters;overlay.coverage=report.coverage;overlay.surface=fresh.surface;
  auto parameters=geometry.PrivateParameters(overlay);if(parameters)moved_geometry=std::move(parameters);
  ++report.boundary_flips;return true;
}
bool MeshOptimizer::TryCell(Id id,bool enrichment) {
  const Cell c=mesh.at(id).cell;
  if(!enrichment && options.swaps) {
    if(ShellBoundary(id))return true;
    for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j){if(!mesh.count(id))return true;if(EdgeRemoval(std::min(c.v[i].id,c.v[j].id),std::max(c.v[i].id,c.v[j].id)))return true;}
    for(auto f:OppositeFaces(c)){if(!mesh.count(id))return true;std::sort(f.begin(),f.end());if(FaceSwap(f))return true;}
    for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j){if(!mesh.count(id))return true;
      if(options.boundary&&!options.geometry&&fixed.count(c.v[i].id)&&fixed.count(c.v[j].id)&&BoundaryFlip(c.v[i].id,c.v[j].id))return true;}
  }
  if(enrichment && options.insertions) {  // DC-13 O7 (longest edges first) and O8
    std::vector<std::pair<long double,std::pair<Id,Id>>> edges;
    for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j){long double l=0;try{l=Estimate(c.v[i].p,c.v[j].p);}catch(const std::exception&){}edges.push_back({-l,{c.v[i].id,c.v[j].id}});}
    std::sort(edges.begin(),edges.end());
    for(const auto& e:edges){if(!mesh.count(id))return true;if(ShellInsert(e.second.first,e.second.second))return true;}
    if(!mesh.count(id))return true;if(NeighbourhoodInsert(id))return true;
  }
  if(!enrichment && options.collapses) {
    std::vector<std::pair<long double,std::pair<Id,Id>>> edges;
    for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j){long double l=INFINITY;try{l=Estimate(c.v[i].p,c.v[j].p);}catch(const std::exception&){}edges.push_back({l,{c.v[i].id,c.v[j].id}});}
    std::sort(edges.begin(),edges.end());
    for(const auto& e:edges){if(!mesh.count(id))return true;if(Collapse(e.second.first,e.second.second)||Collapse(e.second.second,e.second.first))return true;}
    if(options.boundary&&!options.geometry)for(const auto& e:edges){if(!mesh.count(id))return true;if(BoundaryCollapse(e.second.first,e.second.second)||BoundaryCollapse(e.second.second,e.second.first))return true;}
  }
  return false;
}
void MeshOptimizer::AccountNested(const OptimizeReport& n,bool selected) {
  // Charge attempted work once; credit progress only after the complete candidate is admitted.
  if(!selected) {
    report.sweeps+=n.sweeps;report.trials+=n.trials;
    report.rejected_orientation+=n.rejected_orientation;report.rejected_interface+=n.rejected_interface;
    report.rejected_quality+=n.rejected_quality;report.rejected_edge+=n.rejected_edge;report.rejected_frozen+=n.rejected_frozen;report.rejected_validity+=n.rejected_validity;
    report.placements+=n.placements;report.placement_refusals+=n.placement_refusals;report.placement_evaluations+=n.placement_evaluations;
    report.long_edges_seen+=n.long_edges_seen;report.point_queries+=n.point_queries;report.edge_integrations+=n.edge_integrations;report.edge_surrogates+=n.edge_surrogates;
    report.boundary_stars_searched+=n.boundary_stars_searched;report.boundary_stars_reused+=n.boundary_stars_reused;report.boundary_candidates+=n.boundary_candidates;
    report.boundary_rejected_validity+=n.boundary_rejected_validity;report.boundary_rejected_shape+=n.boundary_rejected_shape;
    report.boundary_rejected_edge+=n.boundary_rejected_edge;report.boundary_rejected_geometry+=n.boundary_rejected_geometry;
    report.boundary_guidance_calls+=n.boundary_guidance_calls;report.boundary_upper_queries+=n.boundary_upper_queries;
    report.boundary_move_contexts+=n.boundary_move_contexts;report.boundary_prepared_trials+=n.boundary_prepared_trials;
    report.boundary_guidance_faces+=n.boundary_guidance_faces;report.boundary_guidance_reused_faces+=n.boundary_guidance_reused_faces;report.boundary_guidance_early_rejections+=n.boundary_guidance_early_rejections;report.boundary_seconds+=n.boundary_seconds;
    report.interior_stars_searched+=n.interior_stars_searched;report.interior_stars_reused+=n.interior_stars_reused;report.interior_candidates+=n.interior_candidates;
    report.interior_rejected_validity+=n.interior_rejected_validity;report.interior_rejected_shape+=n.interior_rejected_shape;
    report.interior_rejected_edge+=n.interior_rejected_edge;report.interior_rejected_geometry+=n.interior_rejected_geometry;
    report.interior_guidance_calls+=n.interior_guidance_calls;report.interior_upper_queries+=n.interior_upper_queries;report.interior_seconds+=n.interior_seconds;
  } else {
    report.edge_removals+=n.edge_removals;report.face_swaps+=n.face_swaps;report.collapses+=n.collapses;report.moves+=n.moves;
    report.boundary_flips+=n.boundary_flips;report.boundary_collapses+=n.boundary_collapses;report.length_removals+=n.length_removals;
    report.shell_insertions+=n.shell_insertions;report.neighbourhood_insertions+=n.neighbourhood_insertions;report.length_insertions+=n.length_insertions;
    report.boundary_moves+=n.boundary_moves;report.boundary_debt_reduction+=n.boundary_debt_reduction;
    report.interior_moves+=n.interior_moves;report.interior_debt_reduction+=n.interior_debt_reduction;
  }
}
bool MeshOptimizer::CoupledBoundary() {
  D9QueryScope d9_query(SU2NativeD9::Site::CoupledBoundary, options.geometry);
  if(!coupled || Limited() || !options.geometry || !options.swaps || !options.insertions ||
      GetShapeAdmission()!=ShapeAdmission::ValidityOnly || mesh.size()>MaximumCavityCells ||
      options.maximum_work-report.trials<3 || report.sweeps>=options.maximum_sweeps || next_node>=UINT64_MAX-1 ||
      next_cell>=UINT64_MAX-MaximumReplacementCells)return false;
  std::vector<std::pair<long double,Id>> candidates;
  for(const auto& row:mesh)if(!Frozen(row.first) &&
      std::count_if(row.second.physical.begin(),row.second.physical.end(),[](const auto& f){return f.present;})==2 &&
      RowScore(row.first,row.second.cell)<1)candidates.push_back({RowPriority(row.first,row.second.cell),row.first});
  if(candidates.empty())return false;
  std::sort(candidates.begin(),candidates.end());const auto& core=mesh.at(candidates.front().second);
  std::vector<unsigned> faces;for(unsigned k=0;k<4;++k)if(core.physical[k].present)faces.push_back(k);
  const Id a=core.cell.v[faces[0]].id,b=core.cell.v[faces[1]].id;
  const auto shell=Common(star.at(a),star.at(b));if(shell.size()<3 || shell.size()>options.maximum_shell)return false;
  for(Id id:shell)if(Frozen(id))return false;
  const auto& geometry=moved_geometry?*moved_geometry:*options.geometry;
  auto* budget=geometry.AtlasReservation();if(!budget)return false;
  struct Restore {SU2NativeGeometry::AtlasBudget& budget;size_t caller;~Restore(){budget.caller_bytes=caller;}} restore{*budget,budget->caller_bytes};
  const auto live=transfer_memory::Add(budget->caller_bytes,transfer_memory::Mul(2*MaximumReplacementCells,8192),geometry.ParameterOverlayBytes());
  if(live==SIZE_MAX || live>budget->maximum_bytes)throw std::length_error("Coupled boundary candidate exceeds storage admission.");
  budget->caller_bytes=live;budget->peak_bytes=std::max(budget->peak_bytes,live);
  std::vector<Id> all_ids;std::vector<Cell> all_cells,ring;
  for(const auto& row:mesh){all_ids.push_back(row.first);all_cells.push_back(row.second.cell);}
  for(Id id:shell)ring.push_back(mesh.at(id).cell);
  const auto original=GeometryPatch(all_cells),old=GeometryPatch(ring);Patch exposed,refined;std::string reason;
  ++report.trials;if(!ShellBoundaryCell(old,core.cell.id,next_cell,geometry,exposed,reason)){++report.rejected_interface;return false;}
  if(Limited())return false;
  const auto pa=points.at(a),pb=points.at(b);
  const Node point{next_node,{double(((long double)pa.x+pb.x)/2),double(((long double)pa.y+pb.y)/2),double(((long double)pa.z+pb.z)/2)}};
  auto exposed_context=geometry.PrivateParameters(exposed);const auto& exposed_geometry=exposed_context?*exposed_context:geometry;
  ++report.trials;if(!SplitEdge(exposed,{a,b},point,next_cell,exposed_geometry,refined,reason)){++report.rejected_interface;return false;}
  if(next_cell>UINT64_MAX-refined.cells.size())return false;
  Owned pending=mesh;for(Id id:shell)pending.erase(id);
  std::map<Face,Id> bindings;for(const auto& face:refined.surface)bindings.emplace(Key(face.v),face.facet);
  for(const auto& cell:refined.cells){OwnedCell row;row.cell=cell;row.version=1;const auto skin=OppositeFaces(cell);
    for(unsigned k=0;k<4;++k){const auto found=bindings.find(Key(skin[k]));if(found!=bindings.end())row.physical[k]={true,found->second};}
    if(!pending.emplace(cell.id,row).second)throw std::logic_error("Coupled boundary candidate repeats a cell identity.");}
  if(pending.size()>MaximumReplacementCells)return false;
  auto patch=[&](const Owned& rows) {
    Patch result;result.parameters=original.parameters;result.coverage=original.coverage;
    for(const auto& row:refined.parameters)result.parameters.insert_or_assign(row.first,row.second);
    for(const auto& row:refined.coverage.faces)result.coverage.faces.insert_or_assign(row.first,row.second);
    for(const auto& row:refined.coverage.traces)result.coverage.traces.insert_or_assign(row.first,row.second);
    for(const auto& row:rows){result.cells.push_back(row.second.cell);const auto skin=OppositeFaces(row.second.cell);
      for(unsigned k=0;k<4;++k)if(row.second.physical[k].present)result.surface.push_back({skin[k],row.second.physical[k].facet});}
    RetainPhysicalCoverage(result);return result;
  };
  auto initial=patch(pending);auto context=geometry.PrivateParameters(initial);if(!context)return false;
  OptimizeOptions nested_options=options;nested_options.geometry=context.get();nested_options.keep_vertices=keep;nested_options.diagnostic_sliding=sliding;
  nested_options.maximum_work=options.maximum_work-report.trials;
  nested_options.maximum_sweeps=options.maximum_sweeps-report.sweeps;
  if(options.maximum_seconds>0){nested_options.maximum_seconds=options.maximum_seconds-std::chrono::duration<double>(Clock::now()-started).count();if(nested_options.maximum_seconds<=0)return false;}
  Id node=next_node+1,cell=next_cell+refined.cells.size();OptimizeReport nested_report;
  std::set<Id> final_keep;std::map<Id,std::array<double,3>> final_sliding;
  {
    MeshOptimizer nested(pending,target,node,cell,nested_options,nested_report);nested.coupled=false;
    nested.Run();final_keep=std::move(nested.keep);final_sliding=std::move(nested.sliding);
  }
  if(nested_report.trials>nested_options.maximum_work || nested_report.sweeps>nested_options.maximum_sweeps ||
      node<next_node+1 || cell<next_cell+refined.cells.size() || node==UINT64_MAX || cell==UINT64_MAX)
    throw std::logic_error("Coupled boundary candidate exceeded work/identity reservation.");
  AccountNested(nested_report,false);
  if(options.maximum_seconds>0 && std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds){limited=true;return false;}
  if(pending.size()>MaximumReplacementCells)return false;
  auto candidate=patch(pending);
  for(const auto& row:nested_report.parameters)candidate.parameters.insert_or_assign(row.first,row.second);
  for(const auto& row:nested_report.coverage.faces)candidate.coverage.faces.insert_or_assign(row.first,row.second);
  for(const auto& row:nested_report.coverage.traces)candidate.coverage.traces.insert_or_assign(row.first,row.second);
  RetainPhysicalCoverage(candidate);
  const bool debt=DebtMode(all_ids,&original);const auto before=OldMerit(all_ids,debt),after=FreshMerit(candidate.cells,debt,false,&candidate);
  if(!Progress(after,before,debt)){++report.rejected_quality;return false;}
  auto counts=[&](const std::vector<Cell>& cells){std::array<size_t,2> result{};for(const auto& c:cells){const auto q=Quality(c,false);
    if(!q.Valid())throw std::invalid_argument("Coupled boundary candidate has invalid quality.");result[0]+=q.q<MinimumMeanRatio;result[1]+=q.J<MinimumScaledJacobian;}return result;};
  std::array<size_t, 2> old_bad;
  {
    SU2NativeTiming3D::Scope old_cavity_scope(SU2NativeTiming3D::Operation::OldCavityMeasurement);
    old_bad = counts(original.cells);
  }
  const auto new_bad=counts(candidate.cells);
  if(new_bad[0]>old_bad[0] || new_bad[1]>old_bad[1] || new_bad==old_bad){++report.rejected_quality;return false;}
  for(const auto& c:candidate.cells)for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j)
    if((!points.count(c.v[i].id)||!points.count(c.v[j].id)||!Adjacent(c.v[i].id,c.v[j].id)) &&
        !Certified(c.v[i].p,c.v[j].p,MaximumMetricEdge)){++report.rejected_edge;return false;}
  auto final_context=geometry.PrivateParameters(candidate);if(!final_context)return false;
  const auto old_geometry=GeometryGuidanceExcess(original,geometry,options.surface_tolerance);
  const auto new_geometry=GeometryGuidanceExcess(candidate,*final_context,options.surface_tolerance,old_geometry.excess);
  if(!old_geometry.complete || !new_geometry.complete || !std::isfinite(new_geometry.excess) || new_geometry.excess>old_geometry.excess){++report.rejected_interface;return false;}
  std::set<Face> old_physical;for(const auto& face:original.surface)old_physical.insert(Key(face.v));std::map<Face,Face> skin;
  for(const auto& face:Incidence(original.cells).Boundary())if(!old_physical.count(Key(face)))skin.emplace(Key(face),face);
  for(auto face:candidate.surface){std::rotate(face.v.begin(),std::min_element(face.v.begin(),face.v.end()),face.v.end());skin.emplace(Key(face.v),face.v);}
  std::vector<Face> prescribed;for(const auto& face:skin)prescribed.push_back(face.second);
  if(!ValidatePrescribedInterface(original.cells,candidate.cells,prescribed,reason)){report.stop=reason;++report.rejected_interface;return false;}
  if(options.maximum_seconds>0 && std::chrono::duration<double>(Clock::now()-started).count()>=options.maximum_seconds){limited=true;return false;}
  mesh.swap(pending);next_node=node;next_cell=cell;Index();keep=std::move(final_keep);sliding=std::move(final_sliding);
  report.parameters=std::move(candidate.parameters);report.coverage=std::move(candidate.coverage);
  for(const auto& row:nested_report.relabel){Id origin=row.first;for(const auto& prior:report.relabel)if(prior.second==row.first){origin=prior.first;break;}report.relabel[origin]=row.second;}
  moved_geometry=std::move(final_context);AccountNested(nested_report,true);++report.shell_insertions;++report.boundary_flips;
  changed=true;rejected_smoothing.clear();Bound();return true;
}
bool MeshOptimizer::Run() {
  SU2NativeTiming3D::PhaseScope quality_phase(SU2NativeTiming3D::Phase::Quality);
  SU2NativeTiming3D::Scope optimization_timer(SU2NativeTiming3D::Operation::QualityOptimization);
  Index();
  auto census=[&](size_t& bad,double& minimum){bad=0;minimum=INFINITY;for(const auto& row:mesh){if(options.frozen_cells.count(row.first))continue;const double s=RowScore(row.first,row.second.cell);minimum=std::min(minimum,s);bad+=s<1;}if(!std::isfinite(minimum))minimum=1;};
  census(report.bad_before,report.minimum_before);
  while(report.sweeps<options.maximum_sweeps) {
    ++report.sweeps;
    size_t accepted=0;
    const std::array<bool,3> enabled{options.smoothing,options.swaps||options.collapses,options.insertions};
    for(unsigned stage=0;stage<enabled.size();++stage) {
      stage_work_end=options.maximum_work;
      if(!enabled[stage] || Limited())continue;
      const size_t remaining=std::count(enabled.begin()+stage,enabled.end(),true);
      // A phase refusal is temporary: reserve work for every later enabled phase, including enrichment.
      stage_work_end=report.trials+(options.maximum_work-report.trials)/remaining;
      std::vector<std::pair<long double,Id>> bad;
      for(const auto& row:mesh){if(Limited())break;if(options.frozen_cells.count(row.first))continue;
        const double s=RowScore(row.first,row.second.cell);if(s<1)bad.emplace_back(RowPriority(row.first,row.second.cell),row.first);}
      std::sort(bad.begin(),bad.end());
      if(stage==0) {
        std::set<Id> seen;std::vector<Id> vertices;
        for(const auto& row:bad)for(const auto& v:mesh.at(row.second).cell.v)if(seen.insert(v.id).second)vertices.push_back(v.id);
        for(Id v:vertices){if(Limited())break;const auto s=star.find(v);if(s==star.end() || s->second.empty())continue;
          if(MinScore(s->second)<1 && Smooth(v))++accepted;}
      } else {
        for(const auto& row:bad){if(Limited())break;if(!mesh.count(row.second))continue;
          if(RowScore(row.second,mesh.at(row.second).cell)<1 && TryCell(row.second,stage==2))++accepted;}
        // Length repair follows the same topology/enrichment ordering as quality repair.
        if((stage==1?options.swaps:options.insertions)&&!Limited()) {
          std::vector<std::pair<long double,std::pair<Id,Id>>> longs;std::set<std::pair<Id,Id>> seen;
          for(const auto& row:mesh){if(Limited())break;if(Frozen(row.first))continue;const auto& c=row.second.cell;
            for(unsigned i=0;i<4;++i)for(unsigned j=i+1;j<4;++j){const auto e=std::minmax(c.v[i].id,c.v[j].id);if(!seen.insert(e).second)continue;
              try{if(Estimate(c.v[i].p,c.v[j].p)<=1.6L)continue;const auto l=Exact(c.v[i].p,c.v[j].p);
                if(l>MaximumMetricEdge)longs.push_back({-l,e});}catch(const std::exception&){}}}
          std::sort(longs.begin(),longs.end());report.long_edges_seen+=longs.size();
          for(const auto& e:longs){if(Limited())break;if(!Adjacent(e.second.first,e.second.second))continue;
            if(stage==1?EdgeRemoval(e.second.first,e.second.second,true):ShellInsert(e.second.first,e.second.second,true))++accepted;}
        }
      }
    }
    stage_work_end=options.maximum_work;
    if(Limited()){report.stop="limit";break;}
    if(!accepted){const bool combined=CoupledBoundary();census(report.bad_after,report.minimum_after);
      if(combined || report.stop.empty())report.stop=report.bad_after?(combined?"coupled progress":"no progress"):"complete";break;}
  }
  if(report.stop.empty())report.stop="sweep cap";
  census(report.bad_after,report.minimum_after);
  report.seconds=std::chrono::duration<double>(Clock::now()-started).count();
  return changed;
}
}  // namespace
bool OptimizeMetricMesh(Owned& mesh,const RegionMetric& target,Id& next_node,Id& next_cell,const OptimizeOptions& options,OptimizeReport& report) {
  auto* reservation=options.geometry?options.geometry->AtlasReservation():nullptr;
  if(options.geometry && options.geometry->Mapped() && (options.geometry->Mobility()||!options.geometry->Parameters()->Coverage().faces.empty()||!options.geometry->Parameters()->Coverage().traces.empty()) && !reservation) {
    report.stop="atlas reservation missing";return false;
  }
  const auto before=reservation?reservation->work:0;MeshOptimizer optimizer(mesh,target,next_node,next_cell,options,report);
  const bool changed=optimizer.Run();if(reservation){report.atlas_work=reservation->work-before;report.atlas_peak_bytes=reservation->peak_bytes;}return changed;
}
bool PlaceConeInsertion(const std::vector<Cell>& cavity,Point start,Id node,Id first_cell,const RegionMetric& target,
                        std::vector<Cell>& fresh,double& score,const Edge* split_edge,double split_ratio,size_t budget,
                        Id replaced,const std::function<bool(Point)>& region) {
  fresh.clear();score=-INFINITY;if(cavity.empty())return false;
  std::map<Id,Point> points;for(const auto& c:cavity)for(const auto& v:c.v)points[v.id]=v.p;
  std::map<std::array<double,3>,Tensor> memo;
  auto at=[&](Point p){const std::array<double,3> k{p.x,p.y,p.z};const auto f=memo.find(k);if(f!=memo.end())return f->second;const auto m=target.point(p);memo.emplace(k,m);return m;};
  const auto faces=CavityBoundary(cavity);
  std::function<bool(Point)> admissible;
  if(split_edge) {
    const auto fa=points.find((*split_edge)[0]),fb=points.find((*split_edge)[1]);if(fa==points.end()||fb==points.end())return false;
    const Point pa=fa->second,pb=fb->second;Tensor m=at(pa);const Tensor mb=at(pb);
    m.xx=(m.xx+mb.xx)/2;m.xy=(m.xy+mb.xy)/2;m.xz=(m.xz+mb.xz)/2;m.yy=(m.yy+mb.yy)/2;m.yz=(m.yz+mb.yz)/2;m.zz=(m.zz+mb.zz)/2;
    long double whole=0;try{whole=MetricNorm(pa,pb,m);}catch(const std::exception&){return false;}
    const long double limit=split_ratio*whole;
    admissible=[pa,pb,m,limit](Point x){try{return MetricNorm(x,pa,m)<=limit&&MetricNorm(x,pb,m)<=limit;}catch(const std::exception&){return false;}};
  }
  if(region){auto split=admissible;admissible=[split,&region](Point x){return (!split||split(x))&&region(x);};}
  const auto pl=PlaceCone(faces,[&](Id v){return points.at(v);},at,start,admissible,budget);
  if(!pl.ok)return false;
  const Node X{node,pl.x};std::set<Id> kept;
  for(size_t i=0;i<faces.size();++i){const auto& f=faces[i];fresh.push_back(Cell{first_cell+i,{X,Node{f[0],points.at(f[0])},Node{f[1],points.at(f[1])},Node{f[2],points.at(f[2])}}});for(Id v:f)kept.insert(v);}
  if(kept.size()+(points.count(replaced)&&!kept.count(replaced)?1:0)!=points.size()){fresh.clear();return false;}  // a cavity vertex would vanish
  double low=INFINITY;
  for(const auto& c:fresh) {
    if(!(Orientation(c.v[0].p,c.v[1].p,c.v[2].p,c.v[3].p)>0)){fresh.clear();return false;}
    MetricMeasures m;try{m=Measure({c.v[0].p,c.v[1].p,c.v[2].p,c.v[3].p},at(Centroid(c)));}catch(const std::exception&){fresh.clear();return false;}
    if(!std::isfinite(m.mean_ratio) || !std::isfinite(m.minimum_scaled_jacobian)){fresh.clear();return false;}
    low=std::min(low,std::min(m.mean_ratio/MinimumMeanRatio,m.minimum_scaled_jacobian/MinimumScaledJacobian));
  }
  score=low;return true;
}
EngineResult RefineOptimize(World& world,const Owned& accepted,const std::vector<DonorCell>& original,const PlanarReference& geometry,
                            MetricComposition composition,EngineOptions options,OptimizeOptions optimize,RefineOptimizeReport* report,size_t maximum_rounds) {
  struct Restore{ShapeAdmission admission=GetShapeAdmission();~Restore(){SetShapeAdmission(admission);}} restore;
  RefineOptimizeReport local;auto& rep=report?*report:local;rep=RefineOptimizeReport{};
  if(world.size!=1) {
    auto r=Refine(world,accepted,original,geometry,std::move(composition),options);
    r.reason="Native3D RefineOptimize is serial only; plain Refine under the caller's shape admission. "+r.reason;return r;
  }
  SetShapeAdmission(ShapeAdmission::ValidityOnly);
  const auto started=Clock::now();auto elapsed=[&]{return std::chrono::duration<double>(Clock::now()-started).count();};
  Owned current=accepted;std::shared_ptr<const PlanarReference> held;const PlanarReference* geo=&geometry;
  EngineResult last;bool optimizedLast=false;
  for(size_t round=0;round<maximum_rounds;++round) {
    EngineOptions o=options;
    if(options.maximum_seconds>0){const double left=options.maximum_seconds-elapsed();if(left<=0)break;o.maximum_seconds=std::max(1.,.5*left);}
    const auto r0=Clock::now();
    last=Refine(world,current,original,*geo,composition,o);optimizedLast=false;
    rep.refine_seconds+=std::chrono::duration<double>(Clock::now()-r0).count();++rep.rounds;
    rep.stops.push_back(EngineStopName(last.stats.stop));rep.cells.push_back(last.cells.size());
    if(last.valid || last.cells.empty())return last;
    if(last.reference){held=last.reference;geo=held.get();}
    Owned cells=last.cells;Id nextNode=1,nextCell=1;
    OptimizeOptions opt=optimize;
    if(geo->Mapped())opt.boundary=false;  // DC-13: boundary faces change only through the parameter publication of Refine
    opt.diagnostic_sliding.clear();  // the TEST-ONLY sliding diagnostic is never applied in production
    for(const auto& row:cells) {
      nextCell=std::max(nextCell,row.first+1);for(const auto& n:row.second.cell.v)nextNode=std::max(nextNode,n.id+1);
      for(unsigned k=0;k<4;++k)if(row.second.physical[k].present && options.wall_heights.count(geo->Get(row.second.physical[k].facet).marker)) {
        opt.frozen_cells.insert(row.first);for(const auto& n:row.second.cell.v)opt.frozen_vertices.insert(n.id);}
    }
    if(options.maximum_seconds>0){const double left=options.maximum_seconds-elapsed();if(left<=0)break;opt.maximum_seconds=opt.maximum_seconds>0?std::min(opt.maximum_seconds,left):left;}
    const auto o0=Clock::now();OptimizeReport orep;bool moved=false;
    DonorImport source(world,false);std::string why;
    if(!source.Build(original,why)){last.reason="Native3D RefineOptimize original source: "+why+"; "+last.reason;return last;}
    {RegionFieldService service(world,source,*geo,composition,options.edge_breakpoints,false,options.memory_ceiling,0);
     service.Run([&](const RegionMetric& target){moved=OptimizeMetricMesh(cells,target,nextNode,nextCell,opt,orep);});}
    rep.optimize_seconds+=std::chrono::duration<double>(Clock::now()-o0).count();rep.optimize.push_back(orep);
    // a budget-limited Refine round that still changed the mesh continues even when the optimizer finds nothing to do
    const bool refining=(last.stats.stop==EngineStop::TimeBudget||last.stats.stop==EngineStop::WorkBudget||last.stats.stop==EngineStop::RoundBudget)&&
                        (last.cells.size()!=current.size()||last.stats.accepted>0);
    if(!moved&&!refining){last.reason="Native3D RefineOptimize: the optimizer changed nothing after Refine round "+std::to_string(round)+"; "+last.reason;return last;}
    current=std::move(cells);optimizedLast=true;
  }
  if(optimizedLast){last.cells=current;last.valid=false;}
  last.reason="Native3D RefineOptimize stopped at its round/time budget; "+last.reason;return last;
}
}  // namespace SU2Native3D
