  auto observe_progress=[&](const char* stage) {
    stats.job_peak_rss_lower = transfer_memory::Add(JobPeakRSS3D(world.comm), options.idle_peak_rss_bytes);
    CLocalFailure memory_failure;
    if (options.job_memory_limit && stats.job_peak_rss_lower > options.job_memory_limit)
      memory_failure.Set(3, 0, "Native3D whole-job process peak RSS exceeds memory budget.");
    const auto memory_vote = world.elect(memory_failure);
    if (memory_vote.any) {
      result.valid = result.surface_prepared = false;
      stats.stop = EngineStop::MemoryBudget;
      result.reason = memory_vote.message;
      return false;
    }
    if(options.timings && (std::strcmp(stage, "length_collapse_exit") == 0 ||
                            std::strcmp(stage, "construction_entry") == 0 || std::strcmp(stage, "exit") == 0))
      SU2NativeTiming3D::Session::Checkpoint(stage);
    if(surface_target) {
      CLocalFailure failure;
      try{context.census.RefreshSurfaceCensus(context);}catch(const std::exception& e){failure.Set(2,0,e.what());}
      const auto elected=world.elect(failure);
      if(elected.any){result.valid=result.surface_prepared=false;result.reason=elected.message;return false;}
    }
    if(phase==Phase::Improvement) {
      SU2NativeTiming3D::Scope progress_timer(SU2NativeTiming3D::Operation::Census);
      const auto census=selection.Progress(working.size());
      const bool complete=!world.maximum(!census.census_complete||!census.shape_complete||!census.geometry_complete);
      if(complete){EngineReports::EmitFixedMetricDrift(context, stage);emit_quality_census(stage,census);}
    }
    if(options.timings && (std::string(stage)!="window" || phase==Phase::Improvement)) {
      SU2NativeTiming3D::Scope output_scope(SU2NativeTiming3D::Operation::Output);
      const auto p=selection.Progress(working.size());const auto* state=geometry.Parameters();
      const auto cache=geometry_authority?geometry_authority->GeometryStatsSnapshot():SU2NativeGeometry::MappedFacetReference::GeometryStats{};
      const auto authority=geometry_authority?geometry_authority->ResidentBytes():0;
      std::cout<<"NATIVE3D_STORAGE rank="<<world.rank<<" stage="<<stage
          <<" authority_plus_memo_bytes="<<(authority>=cache.prepared_limit?authority-cache.prepared_limit:authority)
          <<" prepared_reserved_bytes="<<cache.prepared_limit<<" facet_live_bytes="<<cache.facet_bytes<<" scope_live_bytes="<<cache.scope_bytes
          <<" private_cells_bytes="<<MapBytes(working)<<" selection_bytes="<<selection.Bytes()<<" directory_bytes="<<directory->ResidentBytes()
          <<" metric_source_bytes="<<source.ResidentBytes()<<" parameter_bytes="<<(private_parameters?private_parameters->ResidentBytes():0)
          <<" caller_reservation_bytes="<<options.caller_bytes<<" native_peak_bytes="<<stats.maximum_work_bytes<<'\n';
      size_t face_pieces=0,trace_pieces=0,limbs=0;
      auto ratio=[&](const SU2NativeGeometry::ExactRatio& r){limbs=std::max({limbs,r.numerator.size(),r.denominator.size()});};
      auto bary=[&](const SU2NativeGeometry::ExactBary& b){ratio(b.u);ratio(b.v);};
      if(state) {
        for(const auto& row:state->Coverage().faces)for(const auto& piece:row.second.pieces){
          ++face_pieces;for(const auto& b:piece.reference)bary(b);for(const auto& b:piece.active)bary(b);}
        for(const auto& row:state->Coverage().traces)for(const auto& piece:row.second.pieces){
          ++trace_pieces;bary(piece.first);bary(piece.last);ratio(piece.end);}
      }
      const auto g=geometry_authority?geometry_authority->GeometryStatsSnapshot():SU2NativeGeometry::MappedFacetReference::GeometryStats{};
      std::cout<<std::setprecision(17)<<"NATIVE3D_STAGE rank="<<world.rank<<" stage="<<stage
          <<" job_peak_rss_lower="<<stats.job_peak_rss_lower
          <<" phase="<<(phase==Phase::Construction?"construction":"improvement")<<" cells="<<p.owned_cells
          <<" measured="<<p.measured_cells<<" cache_consistent="<<p.cache_consistent
          <<" census_complete="<<p.census_complete<<" shape_complete="<<p.shape_complete
          <<" geometry_complete="<<p.geometry_complete<<" q_measured="<<p.q_measured_cells<<" j_measured="<<p.j_measured_cells
          <<" q_bad="<<p.q_bad_cells<<" j_bad="<<p.j_bad_cells<<" size_bad="<<p.size_bad_cells
          <<" geometry_bad="<<p.geometry_bad_cells<<" q_debt="<<p.q_hinge_squared<<" j_debt="<<p.j_hinge_squared
          <<" size_debt="<<p.size_hinge_squared<<" geometry_debt="<<p.geometry_excess_squared
          <<" distinct_facets="<<g.distinct_facets<<" distinct_scope_keys="<<g.distinct_scope_keys
          <<" prepared_facet_builds="<<g.prepared_facet_builds<<" prepared_facet_mean_bytes="<<g.prepared_facet_mean_bytes
          <<" associations="<<(state?state->Records().size():0)<<" working_faces="<<(state?state->Surface().size():0)
          <<" face_pieces="<<face_pieces<<" trace_pieces="<<trace_pieces<<" maximum_ratio_limbs="<<limbs
          <<" atlas_work="<<atlas_budget.work<<" atlas_bytes="<<atlas_budget.peak_bytes<<" global_work="<<stats.global_work
          <<" rounds="<<stats.rounds<<" batch_rounds="<<stats.batch_rounds
          <<" collapse_corrections="<<stats.collapse_corrections<<" collapse_correction_cells="<<stats.collapse_correction_cells
          <<" collapse_correction_work="<<stats.collapse_correction_work<<" collapse_correction_seconds="<<stats.collapse_correction_seconds
          <<" batch_candidates="<<stats.batch_candidates<<" batch_reserved="<<stats.batch_reserved
          <<" quality_progress="<<stats.quality_progress<<" accepted="<<stats.accepted
          <<" updated_cells="<<stats.updated_cells<<" update_seconds="<<stats.update_seconds
          <<" surface_measurement_skipped="<<stats.surface_measurement_skipped
          <<" surface_required_handoffs="<<stats.surface_required_handoffs
          <<" surface_demand_required="<<stats.surface_demand_required_cells<<" surface_demand_measured="<<stats.surface_demand_measured_cells
          <<" surface_demand_complete="<<stats.surface_demand_census_complete<<" surface_geometry_complete="<<stats.surface_demand_geometry_complete
          <<" seed_cell_classes="<<stats.seed_cell_classes[0]<<','<<stats.seed_cell_classes[1]<<','<<stats.seed_cell_classes[2]
          <<" updated_cell_classes="<<stats.updated_cell_classes[0]<<','<<stats.updated_cell_classes[1]<<','<<stats.updated_cell_classes[2]
          <<" geometry_trials="<<stats.geometry_trials<<" geometry_rejected="<<stats.geometry_rejected
          <<" guidance_trials="<<stats.geometry_guidance_trials<<" guidance_rejected="<<stats.geometry_guidance_rejected
          <<" guidance_faces="<<stats.geometry_guidance_faces<<" guidance_early_rejected="<<stats.geometry_guidance_early_rejections
          <<" guidance_seconds="<<stats.geometry_guidance_seconds
          <<" collective_calls="<<world.collective_calls-tracked_calls_begin<<" collective_seconds="<<world.collective_seconds-tracked_seconds_begin
          <<" election_calls="<<world.election_collective_calls-election_calls_begin<<" election_seconds="<<world.election_collective_seconds-election_seconds_begin
          <<" direct_calls="<<g.direct_calls-geometry_begin.direct_calls<<" direct_exceptions="<<g.direct_exceptions-geometry_begin.direct_exceptions
          <<" direct_work="<<g.direct_work-geometry_begin.direct_work<<" direct_seconds="<<g.direct_seconds-geometry_begin.direct_seconds
          <<" upper_calls="<<g.upper_calls-geometry_begin.upper_calls<<" union_exceptions="<<g.union_exceptions-geometry_begin.union_exceptions
          <<" upper_refusals="<<g.upper_refusals-geometry_begin.upper_refusals<<" upper_work="<<g.upper_work-geometry_begin.upper_work
          <<" upper_refinements="<<g.upper_refinements-geometry_begin.upper_refinements
          <<" upper_deferred_bounds="<<g.upper_deferred_bounds-geometry_begin.upper_deferred_bounds
          <<" classification_calls="<<g.classification_calls-geometry_begin.classification_calls
          <<" classification_work="<<g.classification_work-geometry_begin.classification_work
          <<" magnitude_calls="<<g.magnitude_calls-geometry_begin.magnitude_calls
          <<" magnitude_work="<<g.magnitude_work-geometry_begin.magnitude_work
          <<" limit_calls="<<g.limit_calls-geometry_begin.limit_calls
          <<" limit_work="<<g.limit_work-geometry_begin.limit_work
          <<" upper_seconds="<<g.upper_seconds-geometry_begin.upper_seconds<<" full_calls="<<g.full_calls-geometry_begin.full_calls
          <<" full_work="<<g.full_work-geometry_begin.full_work<<" full_seconds="<<g.full_seconds-geometry_begin.full_seconds
          <<" facet_hits="<<g.facet_hits-geometry_begin.facet_hits<<" facet_misses="<<g.facet_misses-geometry_begin.facet_misses
          <<" facet_resolutions="<<g.facet_resolutions
          <<" scope_hits="<<g.scope_hits-geometry_begin.scope_hits<<" scope_misses="<<g.scope_misses-geometry_begin.scope_misses
          <<" scope_attempts="<<g.scope_attempts-geometry_begin.scope_attempts
          <<" scope_builds="<<g.scope_builds-geometry_begin.scope_builds<<" scope_build_work="<<g.scope_build_work-geometry_begin.scope_build_work
          <<" scope_build_seconds="<<g.scope_build_seconds-geometry_begin.scope_build_seconds
          <<" support_calls="<<g.support_calls-geometry_begin.support_calls<<" support_facets="<<g.support_facets-geometry_begin.support_facets
          <<" support_seconds="<<g.support_seconds-geometry_begin.support_seconds
          <<" facet_build_work="<<g.facet_build_work-geometry_begin.facet_build_work<<" facet_build_seconds="<<g.facet_build_seconds-geometry_begin.facet_build_seconds
          <<" piece_selection_work="<<g.piece_selection_work-geometry_begin.piece_selection_work<<" piece_selection_seconds="<<g.piece_selection_seconds-geometry_begin.piece_selection_seconds
          <<" traversal_work="<<g.traversal_work-geometry_begin.traversal_work<<" traversal_seconds="<<g.traversal_seconds-geometry_begin.traversal_seconds
          <<" selected_pieces="<<g.selected_pieces-geometry_begin.selected_pieces<<" support_pieces="<<g.support_pieces-geometry_begin.support_pieces
          <<" smooth_boundary_stars="<<stats.boundary_smoothing_stars<<" smooth_boundary_reused="<<stats.boundary_smoothing_reused
          <<" smooth_boundary_candidates="<<stats.boundary_smoothing_candidates<<" smooth_boundary_rejects="<<stats.boundary_smoothing_validity_rejects<<','<<stats.boundary_smoothing_shape_rejects<<','<<stats.boundary_smoothing_edge_rejects<<','<<stats.boundary_smoothing_geometry_rejects
          <<" smooth_boundary_guidance="<<stats.boundary_smoothing_guidance_calls<<" smooth_boundary_upper_queries="<<stats.boundary_smoothing_upper_queries
          <<" smooth_boundary_move_contexts="<<stats.boundary_smoothing_move_contexts<<" smooth_boundary_prepared_trials="<<stats.boundary_smoothing_prepared_trials
          <<" smooth_boundary_guidance_reused_faces="<<stats.boundary_smoothing_guidance_reused_faces<<" smooth_boundary_guidance_faces="<<stats.boundary_smoothing_guidance_faces<<" smooth_boundary_guidance_early_rejected="<<stats.boundary_smoothing_guidance_early_rejections
          <<" smooth_boundary_moves="<<stats.boundary_smoothing_moves<<" smooth_boundary_debt_reduction="<<double(stats.boundary_smoothing_debt_reduction)
          <<" smooth_boundary_seconds="<<stats.boundary_smoothing_seconds
          <<" smooth_interior_stars="<<stats.interior_smoothing_stars<<" smooth_interior_reused="<<stats.interior_smoothing_reused
          <<" smooth_interior_candidates="<<stats.interior_smoothing_candidates<<" smooth_interior_rejects="<<stats.interior_smoothing_validity_rejects<<','<<stats.interior_smoothing_shape_rejects<<','<<stats.interior_smoothing_edge_rejects<<','<<stats.interior_smoothing_geometry_rejects
          <<" smooth_interior_guidance="<<stats.interior_smoothing_guidance_calls<<" smooth_interior_upper_queries="<<stats.interior_smoothing_upper_queries
          <<" smooth_interior_moves="<<stats.interior_smoothing_moves<<" smooth_interior_debt_reduction="<<double(stats.interior_smoothing_debt_reduction)
          <<" smooth_interior_seconds="<<stats.interior_smoothing_seconds
          <<" retention_refusals="<<g.retention_refusals-geometry_begin.retention_refusals<<" prepared_bytes="<<g.prepared_bytes<<" prepared_limit="<<g.prepared_limit<<" facet_bytes="<<g.facet_bytes<<" scope_bytes="<<g.scope_bytes
          <<" facet_entries="<<g.facet_entries<<" scope_entries="<<g.scope_entries<<" cache_evictions="<<g.evictions<<" cache_evicted_bytes="<<g.evicted_bytes
          <<" memo_direct_hits="<<g.memo_direct_hits-geometry_begin.memo_direct_hits<<" memo_direct_misses="<<g.memo_direct_misses-geometry_begin.memo_direct_misses
          <<" memo_union_hits="<<g.memo_union_hits-geometry_begin.memo_union_hits<<" memo_union_misses="<<g.memo_union_misses-geometry_begin.memo_union_misses
          <<" memo_stores="<<g.memo_stores-geometry_begin.memo_stores<<" memo_evictions="<<g.memo_evictions-geometry_begin.memo_evictions
          <<" memo_evicted_bytes="<<g.memo_evicted_bytes-geometry_begin.memo_evicted_bytes<<" memo_retention_refusals="<<g.memo_retention_refusals-geometry_begin.memo_retention_refusals
          <<" memo_maintenance_work="<<g.memo_maintenance_work-geometry_begin.memo_maintenance_work
          <<" memo_bytes="<<g.memo_bytes<<" memo_limit="<<g.memo_limit<<" memo_direct_entries="<<g.memo_direct_entries<<" memo_union_entries="<<g.memo_union_entries
          <<" length_splits="<<stats.length_splits<<" length_collapses="<<stats.length_collapses
          <<" split_passes="<<stats.length_split_passes<<" collapse_passes="<<stats.length_collapse_passes<<" quality_stages="<<stats.quality_stages
          <<" split_generation="<<stats.split_generation<<" split_lane="<<stats.split_lane
          <<" surface_rounds="<<stats.surface_rounds<<" interior_rounds="<<stats.interior_rounds
          <<" surface_seconds="<<stats.surface_seconds<<" interior_seconds="<<stats.interior_seconds
          <<" surface_conflicts="<<stats.surface_conflicts<<" interior_conflicts="<<stats.interior_conflicts
          <<" interior_boundary_discoveries="<<stats.interior_boundary_discoveries
          <<" unique_long_surface="<<stats.unique_long_surface<<" unique_long_interior="<<stats.unique_long_interior
          <<" unique_edge_debt="<<stats.unique_edge_debt<<" maximum_edge="<<stats.maximum_edge
          <<" edge_census_round="<<edge_census_round<<" edge_census_current="<<(edge_census_round==stats.rounds)
          <<" edge_histogram="<<stats.edge_histogram[0]<<','<<stats.edge_histogram[1]<<','<<stats.edge_histogram[2]
          <<" child_parent_max="<<stats.maximum_child_parent_ratio
          <<" child_ratio_measured="<<stats.child_ratio_measured
          <<" elapsed="<<std::chrono::duration<double>(Clock::now()-started).count()<<std::endl;
      if(std::string(stage)=="length_split_exit")for(const auto& edge:edge_progress.top)
        std::cout<<"NATIVE3D_EDGE rank="<<world.rank<<" generation="<<stats.split_generation
            <<" a="<<edge.edge[0]<<" b="<<edge.edge[1]<<" length="<<edge.length<<" surface="<<edge.surface
            <<" age="<<edge.age<<" disposition="<<edge.disposition<<" disposition_round="<<edge.disposition_round<<'\n';
    }
    if(!observe_stage || !stage_storage_admitted || stage_observer_failed)return !stage_observer_failed;
    CLocalFailure failure;
    if(options.stage_observer)try {
      const auto progress=selection.Progress(working.size());
      options.stage_observer({stage,phase,stats.rounds,result.valid,progress.complete,progress,stats,result.reason,
          working,original,geometry,composition,options.edge_breakpoints,options.wall_heights,options.region_walls,
          options.surface_tolerance,options.maximum_seconds,std::chrono::duration<double>(Clock::now()-started).count(),
          options.maximum_rounds,options.maximum_work,options.memory_ceiling,options.caller_bytes,options.stage_observer_bytes,
          [&](Id id,CellDiagnostic& out){const auto row=working.find(id);return row!=working.end()&&selection.Diagnose(row->second,out);},
          &last_rejection,&diagnostic_rejections,world.rank,world.size});
    }catch(const std::exception& e){failure.Set(2,0,e.what());}
    const auto elected=world.elect(failure);
    if(elected.any) {
      stage_observer_failed=true;result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;
      result.reason+=" Stage progress observer failed: "+elected.message;
      return false;
    }
    return true;
  };
