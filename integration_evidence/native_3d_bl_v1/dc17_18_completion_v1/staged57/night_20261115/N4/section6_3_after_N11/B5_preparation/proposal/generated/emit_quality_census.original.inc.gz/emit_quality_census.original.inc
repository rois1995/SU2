  auto emit_quality_census=[&](const char* stage,const StageProgress& p) {
    const auto began=Clock::now();
    const double elapsed=std::chrono::duration<double>(began-started).count();
    const double tracked_collective=world.collective_seconds+world.election_collective_seconds;
    const uint64_t construction_edits=stats.length_splits+stats.length_collapses;
    if(!quality_census_started) {
      previous_quality=stats.quality;previous_quality_census=p;previous_quality_elapsed=elapsed;
      previous_quality_collective=tracked_collective;previous_quality_construction=construction_edits;
      previous_quality_ownership=stats.ownership_changes;quality_census_started=true;
    }
    std::array<uint64_t,2> q_location{},j_location{};
    std::array<uint64_t,3> q_features{},j_features{};
    std::array<uint64_t,6> q_hist{},j_hist{},geometry_hist{};
    std::array<uint64_t,8> geometry_types{};
    uint64_t bad_total=0,bad_short09=0,bad_short05=0,stuck_shape=0,stuck_required=0,missing_features=0,blocked_features=0;
    auto miss_bin=[](long double value){return !std::isfinite(value)?5u:value<.01L?0u:value<.1L?1u:value<.25L?2u:value<.5L?3u:4u;};
    for(const auto& item:selection.cells) {
      const auto& row=item.second;const auto& d=row.debt;
      const bool bad=d.q_bad||d.j_bad;
      const unsigned feature=row.feature_known?unsigned(row.near_feature):2u;
      if(d.q_bad){++q_location[row.surface];++q_features[feature];++q_hist[miss_bin(std::sqrt(d.q))];}
      if(d.j_bad){++j_location[row.surface];++j_features[feature];++j_hist[miss_bin(std::sqrt(d.j))];}
      if(bad) {
        ++bad_total;bool short09=false,short05=false;
        for(const auto& edge:row.edges) {
          const auto length=selection.edges.at(edge).measure.length;short09=short09||length<.9L;short05=short05||length<.5L;
        }
        bad_short09+=short09;bad_short05+=short05;
      }
      if(row.geometry_invalid) {
        ++geometry_hist.at(row.geometry_excess_bin);
        if(!row.geometry_types)++geometry_types[7];
        for(unsigned type=0;type<7;++type)if(row.geometry_types&(1u<<type))++geometry_types[type];
      }
      const auto repairs=selection.cell_repairs.find(item.first);
      if(repairs==selection.cell_repairs.end()||repairs->second.empty()) {missing_features+=bad;continue;}
      bool blocked=true;
      for(const auto& key:repairs->second) {
        const auto demand=selection.repair_users.find(key);
        if(demand==selection.repair_users.end()||!demand->second.users){missing_features+=bad;blocked=false;break;}
        if(!demand->second.blocked){blocked=false;break;}
      }
      stuck_required+=blocked;stuck_shape+=blocked&&bad;
    }
    for(const auto& feature:selection.repair_users)blocked_features+=feature.second.users&&feature.second.blocked;
    stats.quality.diagnostic_seconds+=std::chrono::duration<double>(Clock::now()-began).count();
    const auto& q=stats.quality;const auto& old=previous_quality;
    const double seconds=elapsed-previous_quality_elapsed;
    if(options.timings) {
      std::cout<<std::setprecision(17)<<"NATIVE3D_QUALITY rank="<<world.rank<<" stage="<<stage<<" census="<<quality_census_serial
          <<" complete=1 round="<<stats.rounds<<" elapsed="<<elapsed<<" window_seconds="<<seconds
          <<" busy_seconds="<<q.busy_seconds-old.busy_seconds<<" join_call_seconds="<<q.join_wait_seconds-old.join_wait_seconds
          <<" private_work_used="<<q.private_work_used-old.private_work_used
          <<" tracked_collective_call_seconds="<<tracked_collective-previous_quality_collective
          <<" diagnostic_seconds="<<q.diagnostic_seconds-old.diagnostic_seconds
          <<" commits="<<q.commits-old.commits<<" commits_total="<<q.commits
          <<" private_tracked_collectives="<<q.private_tracked_collectives-old.private_tracked_collectives
          <<" owned_q_removed="<<int64_t(previous_quality_census.q_bad_cells)-int64_t(p.q_bad_cells)
          <<" owned_j_removed="<<int64_t(previous_quality_census.j_bad_cells)-int64_t(p.j_bad_cells)
          <<" owned_debt_removed="<<double(previous_quality_census.q_hinge_squared+previous_quality_census.j_hinge_squared-p.q_hinge_squared-p.j_hinge_squared)
          <<" q_removed="<<q.q_removed-old.q_removed<<" q_created="<<q.q_created-old.q_created
          <<" j_removed="<<q.j_removed-old.j_removed<<" j_created="<<q.j_created-old.j_created
          <<" q_retired="<<q.q_retired-old.q_retired<<" q_introduced="<<q.q_introduced-old.q_introduced
          <<" j_retired="<<q.j_retired-old.j_retired<<" j_introduced="<<q.j_introduced-old.j_introduced
          <<" unmeasured_churn="<<q.unmeasured_churn-old.unmeasured_churn
          <<" construction_edits="<<construction_edits-previous_quality_construction
          <<" ownership_changes="<<stats.ownership_changes-previous_quality_ownership
          <<" queue="<<selection.repair_queue.size()<<" blocked_features="<<blocked_features
          <<" stuck_shape="<<stuck_shape<<" stuck_required="<<stuck_required<<" missing_features="<<missing_features<<'\n';
      auto histogram=[&](const auto& values){for(size_t i=0;i<values.size();++i){if(i)std::cout<<',';std::cout<<values[i];}};
      std::cout<<"NATIVE3D_QUALITY_LOCATION rank="<<world.rank<<" census="<<quality_census_serial
          <<" q_surface="<<q_location[1]<<" q_interior="<<q_location[0]
          <<" j_surface="<<j_location[1]<<" j_interior="<<j_location[0]
          <<" q_feature="<<q_features[1]<<" q_no_feature="<<q_features[0]<<" q_feature_unknown="<<q_features[2]
          <<" j_feature="<<j_features[1]<<" j_no_feature="<<j_features[0]<<" j_feature_unknown="<<j_features[2]
          <<" bad_union="<<bad_total<<" short09="<<bad_short09<<" short05="<<bad_short05
          <<" short09_share="<<(bad_total?double(bad_short09)/bad_total:0.)<<" short05_share="<<(bad_total?double(bad_short05)/bad_total:0.)
          <<" q_miss_hist=";histogram(q_hist);std::cout<<" j_miss_hist=";histogram(j_hist);
      std::cout<<" geometry_excess_hist=";histogram(geometry_hist);std::cout<<" geometry_authority_types=";histogram(geometry_types);std::cout<<'\n';
      for(unsigned kind=0;kind<3;++kind) {
        const auto& now=q.ladder[kind];const auto& prior=old.ladder[kind];
        std::cout<<"NATIVE3D_QUALITY_LADDER rank="<<world.rank<<" census="<<quality_census_serial<<" kind="<<kind
            <<" trials="<<now.trials-prior.trials<<" certified="<<now.certified-prior.certified<<" commits="<<now.published-prior.published
            <<" optimizer_work="<<now.work-prior.work<<" seconds="<<now.seconds-prior.seconds
            <<" debt_removed="<<double(now.debt_removed-prior.debt_removed)<<" q_removed="<<now.q_removed-prior.q_removed
            <<" j_removed="<<now.j_removed-prior.j_removed<<" rejected=";
        for(size_t reason=0;reason<now.rejected.size();++reason){if(reason)std::cout<<',';std::cout<<now.rejected[reason]-prior.rejected[reason];}
        std::cout<<'\n';
      }
    }
    previous_quality=stats.quality;previous_quality_census=p;previous_quality_elapsed=elapsed;
    previous_quality_collective=tracked_collective;previous_quality_construction=construction_edits;
    previous_quality_ownership=stats.ownership_changes;++quality_census_serial;
  };
