  auto finish=[&]() {
    // Directory stages can refuse shared work and return directly here without an engine vote.
    const auto prior_reason=result.reason;const auto prior_stop=stats.stop;
    if(!context.exchange.Vote(context, CLocalFailure{})) {
      result.valid=result.surface_prepared=false;
      if(prior_stop==EngineStop::WorkBudget && !prior_reason.empty())result.reason=prior_reason;
      else if(!prior_reason.empty() && prior_reason!=result.reason)result.reason+=" Prior failure: "+prior_reason;
    }
    if(region_active && options.timings)stats.reconstruction_seconds+=std::chrono::duration<double>(Clock::now()-region_started).count();
    region_active=false;
    if(layer_active && options.timings)stats.layer_seconds+=std::chrono::duration<double>(Clock::now()-layer_started).count();
    layer_active=false;
    if((result.valid||result.surface_prepared) && geometry.EntityGeometry()) {
      std::optional<SU2NativeTiming3D::PhaseScope> proof_phase;
      std::optional<SU2NativeTiming3D::Scope> proof_scope;
      if (options.timings) {
        proof_phase.emplace(SU2NativeTiming3D::Phase::FinalProof);
        proof_scope.emplace(SU2NativeTiming3D::Operation::Certification);
      }
      CLocalFailure geometryFailure;
      try {
        D9QueryScope d9_query(SU2NativeD9::Site::Finish, &geometry);
        ProveOwnedSurface(world,working,geometry,atlas_budget,stats);
      }
      catch(const std::exception& e){geometryFailure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, geometryFailure)){result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;}
    }
    if(result.surface_prepared && !geometry.EntityGeometry()) {
      std::optional<SU2NativeTiming3D::PhaseScope> proof_phase;
      std::optional<SU2NativeTiming3D::Scope> proof_scope;
      if (options.timings) {
        proof_phase.emplace(SU2NativeTiming3D::Phase::FinalProof);
        proof_scope.emplace(SU2NativeTiming3D::Operation::Certification);
      }
      CLocalFailure geometryFailure;
      try {for(const auto& row:working) {
        const auto patch=GeometryPatch(Imported{{row.second},true,{}},&geometry);
        for(const auto& face:patch.surface) {
          std::array<Point,3> triangle{};
          for(unsigned k=0;k<3;++k)for(const auto& node:row.second.cell.v)if(node.id==face.v[k])triangle[k]=node.p;
          if(geometry.SurfaceDeviation(face.facet,triangle,SU2NativeGeometry::SurfaceQueryNeed::Classify())>options.surface_tolerance)
            geometryFailure.Set(1,face.facet,"Prepared surface does not meet the prescribed geometry tolerance.");
        }
      }}catch(const std::exception& e){geometryFailure.Set(2,0,e.what());}
      if(!context.exchange.Vote(context, geometryFailure)){result.surface_prepared=false;stats.stop=EngineStop::Failure;}
    }
    if((result.valid||result.surface_prepared) && !options.wall_heights.empty()) {
      std::optional<SU2NativeTiming3D::PhaseScope> proof_phase;
      std::optional<SU2NativeTiming3D::Scope> proof_scope;
      if (options.timings) {
        proof_phase.emplace(SU2NativeTiming3D::Phase::FinalProof);
        proof_scope.emplace(SU2NativeTiming3D::Operation::Certification);
      }
      CLocalFailure heightFailure;
      for(const auto& row:working) {
        std::string reason;
        if(!EngineTrial::HeightCheck(context, GeometryPatch(Imported{{row.second},true,{}}, &geometry),reason,bool(surface_target)))heightFailure.Set(1,row.first,reason);
      }
      if(!context.exchange.Vote(context, heightFailure)){result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;}
    }
    result.rebuilt_domain=result.valid && region_rebuilt;
    if (stats.stop==EngineStop::None) stats.stop=result.valid||result.surface_prepared ? EngineStop::Complete : EngineStop::Failure;
    if(observe_state) {
      CLocalFailure observed;
      if(!result.valid&&!result.surface_prepared && options.rejected_state)try {options.rejected_state(working,geometry,result.reason);}
      catch(const std::exception& e){observed.Set(2,0,e.what());}
      const auto elected=world.elect(observed);
      if(elected.any) {
        result.valid=result.surface_prepared=false;stats.stop=EngineStop::Failure;
        result.reason+=" Rejected-state diagnostic failed: "+elected.message;
      }
    }
    stats.final_owned_cells=working.size();
    stats.cached_measured_cells=selection.cells.size();
    stats.cached_invalid_cells=selection.invalid;
    stats.remaining_edges=selection.queue.size()+selection.surface_queue.size()+selection.geometry_queue.size();
    stats.remaining_repairs=selection.repair_queue.size();
    stats.tracked_bytes=world.bytes_sent-tracked_bytes_begin;
    stats.tracked_calls=world.collective_calls-tracked_calls_begin;
    stats.tracked_collective_seconds=world.collective_seconds-tracked_seconds_begin;
    const auto saved_directory=retired_directory;
    context.exchange.RetireDirectory(directory->Statistics());
    if(checkpoint.directory)context.exchange.RetireDirectory(checkpoint.directory->Statistics());
    const auto all_directory=retired_directory;retired_directory=saved_directory;
    stats.collision_seconds=all_directory.collision_seconds;
    stats.collision_builds=all_directory.collision_builds;
    stats.collision_candidates=all_directory.collision_candidates;
    stats.collision_checks=all_directory.collision_checks;
    stats.directory_elections=all_directory.elections;
    stats.directory_election_seconds=all_directory.election_seconds;
    stats.parameter_agreement_seconds=all_directory.parameter_agreement_seconds;
    stats.parameter_publication_seconds=all_directory.parameter_publication_seconds;
    stats.parameter_edits=all_directory.parameter_edits;stats.parameter_faces=all_directory.parameter_faces;
    stats.parameter_payload_bytes=all_directory.parameter_payload_bytes;
    stats.changed_star_scans=all_directory.change_scanned;
    stats.changed_vertices_sent=all_directory.change_sent;
    stats.changed_vertices_received=all_directory.change_received;
    stats.change_notification_seconds=all_directory.change_seconds;
    stats.maximum_work_bytes=std::max(stats.maximum_work_bytes,all_directory.maximum_work_bytes);
    const auto& donor = source.Statistics();
    stats.donor_candidates = donor.index_candidates; stats.donor_filtered = donor.filtered; stats.donor_box_filtered = donor.box_filtered;
    stats.donor_payloads = donor.payloads; stats.donor_reused = donor.reused_candidates; stats.donor_maximum_patch = donor.maximum_patch;
    stats.donor_search_seconds = donor.search_seconds; stats.donor_filter_seconds = donor.filter_seconds;
    stats.metric_support_cells=donor.metric_sample_cells;stats.metric_support_edges=donor.metric_edge_queries;stats.metric_support_skipped=donor.metric_edge_skipped;stats.metric_support_duplicates=donor.metric_edge_duplicates;
    stats.maximum_work_bytes = std::max(stats.maximum_work_bytes, donor.maximum_work_bytes);
    stats.atlas_work=atlas_budget.work-atlas_work_initial;stats.atlas_peak_bytes=atlas_budget.peak_bytes;
    stats.maximum_work_bytes=std::max(stats.maximum_work_bytes,atlas_budget.peak_bytes);
    result.parameters=private_parameters;result.reference=private_geometry;
    if(curved && !result.valid && !selection.cells.empty()) {
      size_t metric_bad=0,geometry_bad=0;
      for(const auto& row:selection.cells){metric_bad+=!row.second.target_valid;geometry_bad+=row.second.geometry_invalid;}
      result.reason+=" Local cached demands: geometry_cells="+std::to_string(geometry_bad)+
          ", metric_or_height_cells="+std::to_string(metric_bad)+", geometry_edges="+std::to_string(selection.geometry_queue.size())+
          ", metric_edges="+std::to_string(selection.queue.size())+".";
    }
    if (!result.valid && !last_rejection.empty()) result.reason += " Last local rejection: " + last_rejection;
    if (options.timings) {
      stats.process_cpu_seconds=double(std::clock()-started_cpu)/CLOCKS_PER_SEC;
      stats.total_seconds=std::chrono::duration<double>(Clock::now()-started).count();
      const double phases=stats.initialization_seconds+stats.seed_seconds+stats.selection_seconds+
          stats.dependency_seconds+stats.reservation_seconds+stats.donor_seconds+stats.reconstruction_seconds+
          stats.metric_seconds+stats.routing_seconds+stats.publication_seconds+stats.update_seconds+stats.completion_seconds+stats.collision_seconds;
      stats.other_seconds=stats.total_seconds-phases-stats.layer_seconds;
    }
    PrintWallLawCensus(working, geometry, options.surface_tolerance, world.rank, "exit", options.timings);
    observe_progress("exit");
    wall_counters.Print(world.rank, {stats.geometry_trials, stats.geometry_rejected, stats.geometry_guidance_trials,
                                     stats.geometry_guidance_rejected, stats.accepted, stats.metric_trials,
                                     stats.proposed, stats.attempted});
    lane_counters.Print(world.rank);
    stats.tracked_bytes=world.bytes_sent-tracked_bytes_begin;
    stats.tracked_calls=world.collective_calls-tracked_calls_begin;
    stats.tracked_collective_seconds=world.collective_seconds-tracked_seconds_begin;
    if(options.timings) {
      const auto total=std::chrono::duration<double>(Clock::now()-started).count();
      stats.other_seconds+=total-stats.total_seconds;stats.total_seconds=total;
      stats.process_cpu_seconds=double(std::clock()-started_cpu)/CLOCKS_PER_SEC;
    }
    result.rebuilt_domain=result.valid && region_rebuilt;
    result.cells.swap(working);
    return std::move(result);
  };
